#!/bin/bash
# data 文件目录 以脚本位置为定位

SOURCE=$0 # $0 is the shell name， maybe absolute path, relative path or symbolic link
while [ -h "$SOURCE" ]; do # resolve $SOURCE until the file is no longer a symlink
  SCRIPT_DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"
  SOURCE="$(readlink "$SOURCE")"
  [[ $SOURCE != /* ]] && SOURCE="$SCRIPT_DIR/$SOURCE" # if $SOURCE was a relative symlink, we need to resolve it relative to the path where the symlink file was located
done
SCRIPT_DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"  # script absolute path
#引入配置
source "${SCRIPT_DIR}"/../../conf/config.sh

data_dir="${SCRIPT_DIR}"/../../data

field_sql=$1

data_sql=$2

cat  << EOF > "${data_dir}"/impala_create_table_sql
create table if not exists ${database_name}.users (
${field_sql}
)
STORED AS PARQUET
LOCATION "hdfs://${source_hdfs_cache_path}/${database_name}/user/sensors_user" ;
EOF


cat  << EOF > "${data_dir}"/impala_load_data_sql
insert overwrite table ${database_name}.users
/*SA_BEGIN(${project})*/
${data_sql}
/*SA_END*/;
EOF


impala-shell -s "${impala_machine_server_name}" -i"${impala_machine_host}" -f "${data_dir}"/impala_create_table_sql

impala-shell -s "${impala_machine_server_name}" -i"${impala_machine_host}" -f "${data_dir}"/impala_load_data_sql
