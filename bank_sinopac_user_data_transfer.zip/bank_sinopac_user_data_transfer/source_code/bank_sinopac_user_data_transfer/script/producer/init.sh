#!/bin/bash

SOURCE=$0 # $0 is the shell name， maybe absolute path, relative path or symbolic link
while [ -h "$SOURCE" ]; do # resolve $SOURCE until the file is no longer a symlink
  SCRIPT_DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"
  SOURCE="$(readlink "$SOURCE")"
  [[ $SOURCE != /* ]] && SOURCE="$SCRIPT_DIR/$SOURCE" # if $SOURCE was a relative symlink, we need to resolve it relative to the path where the symlink file was located
done
SCRIPT_DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"  # script absolute path
#引入配置
source "${SCRIPT_DIR}"/../../conf/config.sh

hadoop fs -test -e "${source_hdfs_cache_path}"

if [ $? -eq 0 ]; then
    hdfs dfs -mkdir -p "${source_hdfs_cache_path}"/"${database_name}"/user/sensors_user
    hdfs dfs -chmod -R 777 "${source_hdfs_cache_path}"/"${database_name}"/user/sensors_user
    hdfs dfs -chmod -R 777 "${source_hdfs_cache_path}"
    hdfs dfs -chown -R sensors:sensors "${source_hdfs_cache_path}"
fi

mkdir -p "${source_local_cache_path}"/sensors_user_flag

kinit -k -t "${source_kinit_kt}" "${source_kinit_user}"
