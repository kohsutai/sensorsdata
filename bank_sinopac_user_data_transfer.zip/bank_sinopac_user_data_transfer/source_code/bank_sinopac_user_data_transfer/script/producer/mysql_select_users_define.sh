#!/bin/bash
# data 文件目录 以脚本位置为定位

SOURCE=$0 # $0 is the shell name， maybe absolute path, relative path or symbolic link
while [ -h "$SOURCE" ]; do # resolve $SOURCE until the file is no longer a symlink
  SCRIPT_DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"
  SOURCE="$(readlink "$SOURCE")"
  [[ $SOURCE != /* ]] && SOURCE="$SCRIPT_DIR/$SOURCE" # if $SOURCE was a relative symlink, we need to resolve it relative to the path where the symlink file was located
done
SCRIPT_DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"  # script absolute path
#引入配置
source "${SCRIPT_DIR}"/../../conf/config.sh

data_dir="${SCRIPT_DIR}"/../../data

# 连接数据库去除表头查询
result=`sa_mysql -N << EOF
use metadata;
select CONCAT_WS(',',name,data_type,'') from property_define where project_id = (select id from project where name = '$project') and is_in_use = 1 and table_type = 1;
quit
EOF`

# 将结果写入文本
echo "$result" > "${data_dir}"/users_define
