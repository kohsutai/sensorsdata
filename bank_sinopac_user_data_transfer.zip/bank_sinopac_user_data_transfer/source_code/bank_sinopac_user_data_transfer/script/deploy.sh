#!/bin/bash
# data 文件目录 以脚本位置为定位
SOURCE=$0 # $0 is the shell name， maybe absolute path, relative path or symbolic link
while [ -h "$SOURCE" ]; do # resolve $SOURCE until the file is no longer a symlink
  SCRIPT_DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"
  SOURCE="$(readlink "$SOURCE")"
  [[ $SOURCE != /* ]] && SOURCE="$SCRIPT_DIR/$SOURCE" # if $SOURCE was a relative symlink, we need to resolve it relative to the path where the symlink file was located
done
SCRIPT_DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"  # script absolute path
CODE_ROOT_DIR="$(dirname "${SCRIPT_DIR}")"
PROGRAM_DIR="$(dirname "${CODE_ROOT_DIR}")"

BIN_PATH="${CODE_ROOT_DIR}"/bin

CONF_PATH="${CODE_ROOT_DIR}"/conf/producer_cron_job.conf

YML_PATH="${CODE_ROOT_DIR}"/conf/producer_cron_job.yml

START_SCRIPT=run.sh

CRONTAB_CONF_FILE=${SCRIPT_DIR}/crontab_conf

CONFIG="${CODE_ROOT_DIR}"/conf/configuration.conf
HOST_SERVER=$(awk -F '=' '/\['server'\]/{a=1}a==1&&$1~/'host_server'/{print $2;exit}' "${CONFIG}")

function log_info() {
  DATE=`date "+%Y-%m-%d %H:%M:%s"`
  echo -e "\033[32m $DATE [INFO]: $1 \033[0m"
}

function log_err() {
  DATE=`date "+%Y-%m-%d %H:%M:%s"`
  echo -e "\033[31m $DATE [ERROR]: $1 \033[0m"
}

function usage() {
  log_info ""
  log_info "  sh deploy.sh producer   在producer端部署（分发、注册Scheduler）"
  log_info "  sh deploy.sh consumer   在consumer端部署（配置crontab）"
  log_info ""
  exit 2
}

function producer() {
  log_info "producer deploy"
  if [ $(whoami) != "sa_cluster" ]; then
    log_err "请使用 sa_cluster 执行该脚本"
    exit 1
  fi
  #修改脚本的属主
  update_owner
  scp_script
  submit_scheduler_job
  log_info "deploy end"
}


function update_owner() {
  log_info "開始修改腳本的屬主"
  sudo chown -R sa_cluster "${CODE_ROOT_DIR}"
  log_info "完成修改腳本的屬主"
}

function scp_script() {
  ARRAY=(${HOST_SERVER//,/ })
  for HOST in ${ARRAY[@]}; do
    log_info "開始傳輸 dataTransfer 腳本到 $HOST 主機"
    CUR_HOST=$(hostname)

    if [[ ${CUR_HOST} == $HOST ]]; then
      log_info "當前主機為 ${CUR_HOST}, 無需傳輸腳本"
      continue
    fi
    # 创建etl目录
    ssh sa_cluster@$HOST "if [ ! -d ${PROGRAM_DIR} ];then mkdir -p ${PROGRAM_DIR}; fi"
    scp -r "${CODE_ROOT_DIR}" sa_cluster@$HOST:"${PROGRAM_DIR}" >/dev/null 2>&1
    log_info "完成傳輸 已傳輸到 $HOST 主機"
  done
}

# 設置 scheduler 任務
function submit_scheduler_job() {
  log_info "開始設置 scheduler 調度任務"
  if spadmin scheduler show_conf | grep ETL_users_transfer; then
    log_info "已存在相同 scheduler 調度任務,即將更新調度任務"
    spadmin scheduler alter_conf -n ETL_users_transfer -f "${CONF_PATH}"
    log_info "完成更新調度任務"
  else
    append_sa_scheduler_conf
    # 1.17 前版本命令
    #spadmin scheduler add_conf -f "${CONF_PATH}"
    # 1.17及以上版本命令
    #spadmin scheduler deploy -p sa --add_and_delete_only
    if spadmin scheduler deploy -p sa --add_and_delete_only; then
      log_info "設置 scheduler 調度任務成功"
    else
      log_info "設置 scheduler 調度任務失敗"
    fi
  fi
}

# 設置 scheduler config
function append_sa_scheduler_conf() {
  log_info "備份 sa scheduler配置文件"
  cp ${SENSORS_ANALYTICS_HOME}/scheduler_job/cron_job.yml "${CODE_ROOT_DIR}"/conf/sa_cron_job_conf_bak
  result=$(grep ETL_users_transfer ${SENSORS_ANALYTICS_HOME}/scheduler_job/cron_job.yml)
  if [ -n "$result" ];then
        log_info "任務已存在"
    else
        log_info "開始追加寫入ETL_users_transfer任務配置"
        cat "${YML_PATH}" >> ${SENSORS_ANALYTICS_HOME}/scheduler_job/cron_job.yml
        log_info "寫入完成"
    fi
}


function consumer() {
  log_info "consumer deploy"
  creat_conf
  add_crontab
  sleep 2
  delete_conf
  log_info "deploy end"
}

function creat_conf() {
  crontab -l > "${CRONTAB_CONF_FILE}"
}

function add_crontab() {
  if [ -f "${CRONTAB_CONF_FILE}" ]; then
    cron='0 4 * * * '
    com='/bin/sh '"${BIN_PATH}"/"${START_SCRIPT}"' consumer'
    result=$(grep "${com}" "${CRONTAB_CONF_FILE}")
    if [ -n "$result" ];then
        log_info "crontab text exists"
    else
        log_info "start write crontab text"
        echo "${cron}${com}" >> "${CRONTAB_CONF_FILE}"
        crontab "${CRONTAB_CONF_FILE}"
        log_info "write crontab text end"
    fi
  fi
}


function  delete_conf() {
  if [ -f "${CRONTAB_CONF_FILE}" ]; then
    rm "${CRONTAB_CONF_FILE}" -f;
  fi
}

case "$1" in
  producer )
    producer
    ;;
  consumer )
    consumer
    ;;
  * )
    usage
    ;;
esac
