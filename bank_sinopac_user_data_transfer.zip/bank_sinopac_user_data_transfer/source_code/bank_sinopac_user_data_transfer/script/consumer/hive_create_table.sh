#!/bin/bash

SOURCE=$0 # $0 is the shell name， maybe absolute path, relative path or symbolic link
while [ -h "$SOURCE" ]; do # resolve $SOURCE until the file is no longer a symlink
  SCRIPT_DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"
  SOURCE="$(readlink "$SOURCE")"
  [[ $SOURCE != /* ]] && SOURCE="$SCRIPT_DIR/$SOURCE" # if $SOURCE was a relative symlink, we need to resolve it relative to the path where the symlink file was located
done
SCRIPT_DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"  # script absolute path
#引入配置
source "${SCRIPT_DIR}"/../../conf/config.sh

data_dir="${SCRIPT_DIR}"/../../data

if [ ! -d "${data_dir}" ]; then
  data_dir="${SCRIPT_DIR}"
fi

field_sql=$1

cat  << EOF > "${data_dir}"/hive_create_table_sql
SET hive.create.as.external.legacy=true;
create table if not exists ${database_name}.users (
${field_sql}
)
STORED AS PARQUET
LOCATION "hdfs://${target_hdfs_cache_path}/${database_name}/user/sensors_user" ;
EOF

hive -f "${data_dir}"/hive_create_table_sql
