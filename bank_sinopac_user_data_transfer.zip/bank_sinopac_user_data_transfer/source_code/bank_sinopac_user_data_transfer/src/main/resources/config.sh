#!/bin/sh

export source_hdfs_cache_path=/sa/etl/etl_sa/uetl_sa

export target_hdfs_cache_path=/uetl_sa/etl/etl_sa/etl_sa

export source_local_cache_path=/data/tmp/user

export target_local_cache_path=/data/tmp/user

export database_name=uetl_sa

export source_kinit_kt=/data/keytabs/sensors.keytab

export source_kinit_user=sensors@ITRD.RD

export target_kinit_kt=/data/keytabs/etl_sa.keytab

export target_kinit_user=etl_sa@ITRD.RD

export project=default

export impala_machine_host=hybrid01

export impala_machine_server_name=uimpalas

export hive_trust_user=sensors

export hive_machine_host=10.11.89.72







