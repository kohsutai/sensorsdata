package com.sensorsdata.etl.service.impl.etl;

import com.sensorsdata.etl.enums.ServerTypeEnum;
import com.sensorsdata.etl.service.ETLService;
import com.sensorsdata.etl.service.LoadService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

@Service(value = "consumer_etl_server_impl")
@Slf4j
public class ConsumerETLServiceImpl implements ETLService {
    @Autowired
    private ApplicationContext applicationContext;


    @Override
    public void etlExcuse(String beginDate,String endDate) {
        log.info("------------------------------------------load data,date:{}~{}------------------------------------------",beginDate,endDate);
        LoadService loadService = (LoadService)applicationContext.getBean(ServerTypeEnum.LOCAL_LOAD.getName());
        loadService.dataLoad(beginDate,endDate);
    }

}
