package com.sensorsdata.etl.service.impl.etl;

import com.sensorsdata.etl.service.ETLService;
import com.sensorsdata.etl.service.ExtractService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service(value = "producer_etl_server_impl")
@Slf4j
public class ProducerETLServiceImpl implements ETLService {

    @Autowired
    ExtractService extractService;


    @Override
    public void etlExcuse(String beginDate,String endDate) {
        log.info("------------------------------------------extract data,date:{}~{}------------------------------------------",beginDate,endDate);
        extractService.dataExtract(beginDate,endDate);
    }

}
