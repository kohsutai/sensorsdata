package com.sensorsdata.etl.service.impl.load;

import com.sensorsdata.etl.enums.ShellNameEnum;
import com.sensorsdata.etl.module.vo.UserDefineVO;
import com.sensorsdata.etl.service.LoadService;
import com.sensorsdata.etl.utils.BaseFileUtil;
import com.sensorsdata.etl.utils.FileHandleUtil;
import com.sensorsdata.etl.utils.SQLUtil;
import com.sensorsdata.etl.utils.ShellCommandUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service(value = "local_load_server_impl")
@Slf4j
public class LocalLoadServiceImpl implements LoadService {

    @Value("#{${extract.fieldTypeMap}}")
    private Map<String, String> fieldTypeMap;

    @Value("#{${extract.presetFieldMap}}")
    private Map<String, String> presetFieldMap;

    @Override
    public void dataLoad(String beginDate,String endDate) {

        String shellDir = BaseFileUtil.getConsumerShellDir();
        log.info("------------------------------------------init------------------------------------------");
        ShellCommandUtil.execShell(shellDir+ ShellNameEnum.INIT.getName());

        log.info("------------------------------------------cp define file------------------------------------------");
        ShellCommandUtil.execShell(shellDir+ ShellNameEnum.CP_USER_DEFINE_FILE.getName());

        log.info("------------------------------------------check flag file------------------------------------------");
        String flag = beginDate + "-" + endDate;
        List<String> flagFileContent = ShellCommandUtil.execShell(shellDir+ ShellNameEnum.CHECK_FLAG.getName());
        String flagFile = flagFileContent.isEmpty()?"":flagFileContent.get(0);
        log.info("date flag:{},flag file:{}",flag,flagFile);
        if(!flag.equals(flagFile)){
            log.error("flag file mismatching");
            return;
        }

        log.info("------------------------------------------drop users table------------------------------------------");
        ShellCommandUtil.execShell(shellDir+ ShellNameEnum.HIVE_DROP_USERS_TABLE.getName());

        log.info("------------------------------------------create table------------------------------------------");
        List<UserDefineVO> userDefineList = FileHandleUtil.getUserDefineList(presetFieldMap);
        String createSql = SQLUtil.jointCreateSql(userDefineList,fieldTypeMap);
        log.info("------------------------------------------create sql:{}------------------------------------------",createSql);
        ShellCommandUtil.execShell(shellDir+ ShellNameEnum.HIVE_CREATE.getName(),createSql);

        log.info("------------------------------------------push data------------------------------------------");
        ShellCommandUtil.execShell(shellDir+ ShellNameEnum.PUT_DATA.getName());

        log.info("------------------------------------------hive mask------------------------------------------");
        ShellCommandUtil.execShell(shellDir+ ShellNameEnum.HIVE_MASK.getName());

        log.info("------------------------------------------delete cache file------------------------------------------");
        ShellCommandUtil.execShell(shellDir+ ShellNameEnum.DELETE_CACHE.getName());

    }
}
