package com.sensorsdata.etl.enums;

public enum ServerTypeEnum {
    ETL("etl","etl_etl_server_impl","etl全流程"),
    PRODUCER("producer","producer_etl_server_impl","生成数据文件"),
    CONSUMER("consumer","consumer_etl_server_impl","消费数据文件"),

    LOCAL_LOAD("local_load","local_load_server_impl","在本机落盘数据"),
    SSH_LOAD("ssh_load","ssh_load_server_impl","控制远端机器落盘数据");

    private String code;
    private String name;
    private String describe;

    ServerTypeEnum(String code, String name, String describe) {
        this.code = code;
        this.name = name;
        this.describe = describe;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescribe() {
        return describe;
    }

    public void setDescribe(String cname) {
        this.describe = cname;
    }

    public static String getNameByCode(String code){
        for (ServerTypeEnum eventEnum : ServerTypeEnum.values()) {
            if (eventEnum.code.equals(code)){
                return eventEnum.getName();
            }
        }
        return null;
    }
}
