package com.sensorsdata.etl;

import com.sensorsdata.etl.enums.ServerTypeEnum;
import com.sensorsdata.etl.service.ETLService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Component
@Slf4j
public class EtlApplicationRunner implements ApplicationRunner {

    @Autowired
    private ApplicationContext applicationContext;

    @Override
    public void run(ApplicationArguments args) throws Exception {

        DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyyMMdd");
        String date = df.format(LocalDate.now().minusDays(1L));

        String type = args.getOptionValues("serverType").get(0);
        String serverBeanName = ServerTypeEnum.getNameByCode(type);
        if(serverBeanName == null){
            log.error("etl type illegal");
            return;
        }

        ETLService etlService = (ETLService)applicationContext.getBean(serverBeanName);
        etlService.etlExcuse(date,date);
    }
}
