package com.sensorsdata.etl.service.impl.extract;

import com.sensorsdata.etl.enums.ShellNameEnum;
import com.sensorsdata.etl.module.vo.UserDefineVO;
import com.sensorsdata.etl.service.ExtractService;
import com.sensorsdata.etl.utils.BaseFileUtil;
import com.sensorsdata.etl.utils.FileHandleUtil;
import com.sensorsdata.etl.utils.SQLUtil;
import com.sensorsdata.etl.utils.ShellCommandUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@Slf4j
public class ExtractServiceImpl implements ExtractService {

    @Value("${extract.tableName}")
    private String tableName;

    @Value("#{${extract.fieldTypeMap}}")
    private Map<String, String> fieldTypeMap;

    @Value("#{${extract.presetFieldMap}}")
    private Map<String, String> presetFieldMap;

    @Override
    public void dataExtract(String beginDate,String endDate) {
        String shellDir = BaseFileUtil.getProducerShellDir();
        log.info("------------------------------------------init------------------------------------------");
        ShellCommandUtil.execShell(shellDir+ ShellNameEnum.INIT.getName());

        log.info("------------------------------------------select user define------------------------------------------");
        ShellCommandUtil.execShell(shellDir+ ShellNameEnum.MYSQL_SELECT_USERS_DEFINE.getName());
        List<UserDefineVO> userDefineList = FileHandleUtil.getUserDefineList(presetFieldMap);
        log.info("------------------------------------------create table load data------------------------------------------");
        String createSql = SQLUtil.jointCreateSql(userDefineList,fieldTypeMap);
        String loadSql = SQLUtil.jointLoadSql(tableName,userDefineList.stream().map(UserDefineVO::getName).collect(Collectors.toList()));
        log.info("------------------------------------------create sql:{}------------------------------------------",createSql);
        log.info("------------------------------------------load sql:{}------------------------------------------",loadSql);
        ShellCommandUtil.execShell(shellDir+ ShellNameEnum.IMPALA_CREATE_LOAD.getName(),createSql,loadSql);

        log.info("------------------------------------------pull data file------------------------------------------");
        ShellCommandUtil.execShell(shellDir+ ShellNameEnum.GET_DATA.getName());

        log.info("------------------------------------------scp data------------------------------------------");
        ShellCommandUtil.execShell(shellDir+ ShellNameEnum.SCP_DATA.getName());

        String flag = beginDate + "-" + endDate;
        log.info("------------------------------------------scp flag {}------------------------------------------",flag);
        ShellCommandUtil.execShell(shellDir+ ShellNameEnum.SCP_FLAG.getName(),flag);

        log.info("------------------------------------------scp define file------------------------------------------");
        ShellCommandUtil.execShell(shellDir+ ShellNameEnum.SCP_USER_DEFINE_FILE.getName());

        log.info("------------------------------------------drop temp table------------------------------------------");
        ShellCommandUtil.execShell(shellDir+ ShellNameEnum.IMPALA_DROP_TMP_TABLE.getName());

        log.info("------------------------------------------delete cache file------------------------------------------");
        ShellCommandUtil.execShell(shellDir+ ShellNameEnum.DELETE_CACHE.getName());

    }



}
