package com.sensorsdata.etl.utils;

import lombok.extern.slf4j.Slf4j;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public class DBUtil {

    public static List<Map<String,Object>> execMariaSql(String url,String username,String password,String sql,String... params){
        List<Map<String,Object>> list = new ArrayList<>();
        try(Connection conn = getMariaConnect(url,username,password);PreparedStatement preparedStatement = conn.prepareStatement(sql)){
            if(params != null && params.length > 0){
                setParam(preparedStatement,params);
            }
            try(ResultSet resultSet = preparedStatement.executeQuery()){
                ResultSetMetaData md = resultSet.getMetaData();//获取键名
                int columnCount = md.getColumnCount();//获取列的数量
                while (resultSet.next()) {
                    Map<String,Object> rowData = new HashMap<>();//声明Map
                    for (int i = 1; i <= columnCount; i++) {
                        rowData.put(md.getColumnName(i), resultSet.getObject(i));//获取键名及值
                    }
                    list.add(rowData);
                }
            }
        }catch (Exception e){
            log.error("execMariaSql error",e);
        }
        return list;
    }

    private static Connection getMariaConnect(String url,String username,String password) throws SQLException{
        return DriverManager.getConnection(url, username, password);
    }

    private static void setParam(PreparedStatement preparedStatement,String... params) throws SQLException{
        int i = 1;
        for(String param : params){
            preparedStatement.setString(i,param);
            i++;
        }
    }
}
