package com.sensorsdata.etl.service.impl.load;

import com.sensorsdata.etl.enums.ShellNameEnum;
import com.sensorsdata.etl.module.vo.UserDefineVO;
import com.sensorsdata.etl.service.LoadService;
import com.sensorsdata.etl.utils.BaseFileUtil;
import com.sensorsdata.etl.utils.FileHandleUtil;
import com.sensorsdata.etl.utils.SQLUtil;
import com.sensorsdata.etl.utils.ShellCommandUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service(value = "ssh_load_server_impl")
@Slf4j
public class SSHLoadServiceImpl implements LoadService {

    @Value("#{${extract.fieldTypeMap}}")
    private Map<String, String> fieldTypeMap;

    @Value("#{${extract.presetFieldMap}}")
    private Map<String, String> presetFieldMap;

    @Override
    public void dataLoad(String beginDate,String endDate) {
        String shellDir = BaseFileUtil.getProducerShellDir();
        log.info("------------------------------------------scp script file------------------------------------------");
        ShellCommandUtil.execShell(shellDir+ ShellNameEnum.SCP_SCRIPT.getName());

        log.info("------------------------------------------init------------------------------------------");
        ShellCommandUtil.execShell(shellDir+ ShellNameEnum.SSH_EXECUTE.getName(),ShellNameEnum.INIT.getName());

        log.info("------------------------------------------check flag file------------------------------------------");
        String flag = beginDate + "-" + endDate;
        String flagFile = ShellCommandUtil.execShell(shellDir+ ShellNameEnum.SSH_EXECUTE.getName(),ShellNameEnum.CHECK_FLAG.getName()).stream().filter(t->!t.isEmpty()).findFirst().orElse("");
        log.info("date flag:{},flag file:{}",flag,flagFile);
        if(!flag.equals(flagFile)){
            log.error("flag file mismatching");
            return;
        }

        log.info("------------------------------------------drop users table------------------------------------------");
        ShellCommandUtil.execShell(shellDir+ ShellNameEnum.SSH_EXECUTE.getName(),ShellNameEnum.HIVE_DROP_USERS_TABLE.getName());

        log.info("------------------------------------------create table------------------------------------------");
        List<UserDefineVO> userDefineList = FileHandleUtil.getUserDefineList(presetFieldMap);
        String createSql = SQLUtil.jointCreateSql(userDefineList,fieldTypeMap);
        log.info("------------------------------------------create sql:{}------------------------------------------",createSql);
        ShellCommandUtil.execShell(shellDir+ ShellNameEnum.SSH_EXECUTE.getName(),ShellNameEnum.HIVE_CREATE.getName(),createSql);

        log.info("------------------------------------------push data------------------------------------------");
        ShellCommandUtil.execShell(shellDir+ ShellNameEnum.SSH_EXECUTE.getName(),ShellNameEnum.PUT_DATA.getName());

        log.info("------------------------------------------hive mask------------------------------------------");
        ShellCommandUtil.execShell(shellDir+ ShellNameEnum.SSH_EXECUTE.getName(),ShellNameEnum.HIVE_MASK.getName());

        log.info("------------------------------------------delete cache file------------------------------------------");
        ShellCommandUtil.execShell(shellDir+ ShellNameEnum.SSH_EXECUTE.getName(),ShellNameEnum.DELETE_CACHE.getName());
    }
}
