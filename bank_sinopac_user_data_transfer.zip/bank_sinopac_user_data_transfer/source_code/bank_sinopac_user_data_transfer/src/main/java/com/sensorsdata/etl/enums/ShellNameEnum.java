package com.sensorsdata.etl.enums;

public enum ShellNameEnum {
    INIT("init","init.sh","初始化环境"),
    DELETE_CACHE("delete_cache","delete_cache_data_file.sh","删除缓存数据文件"),
    GET_DATA("get_data","get_data_to_local.sh","从hdfs拉取数据文件到本地"),
    PUT_DATA("put_data","put_data_to_hdfs.sh","从本地上传数据文件到hdfs"),
    IMPALA_CREATE_LOAD("impala_create_load","impala_create_table_load_data.sh","impala建表并载入数据"),
    IMPALA_DROP_TMP_TABLE("impala_drop_tmp_table","impala_drop_tmp_table.sh","impala删除临时表"),
    MYSQL_SELECT_USERS_DEFINE("mysql_select_users_define","mysql_select_users_define.sh","在mysql中查询users表结构"),
    HIVE_CREATE("hive_create","hive_create_table.sh","hive建表"),
    HIVE_MASK("hive_mask","hive_mask_table.sh","hive刷新分区"),
    HIVE_DROP_USERS_TABLE("hive_drop_users_table","hive_drop_users_table.sh","hive删除前次users表"),
    CHECK_FLAG("check_flag","check_flag_file.sh","读取标识文件"),
    CP_USER_DEFINE_FILE("cp_user_define_file","cp_user_define_file.sh","复制用户表定义文件"),
    SCP_DATA("scp_data","scp_data_file.sh","传输数据文件"),
    SCP_FLAG("scp_flag","scp_flag_file.sh","传输标识文件"),
    SCP_USER_DEFINE_FILE("scp_user_define_file","scp_user_define_file.sh","传输用户表定义文件（用于建表）"),
    SCP_SCRIPT("scp_script","scp_script_file.sh","传输脚本文件"),
    SSH_EXECUTE("ssh_execute","ssh_execute_command.sh","ssh执行脚本");

    private String code;
    private String name;
    private String describe;

    ShellNameEnum(String code, String name, String describe) {
        this.code = code;
        this.name = name;
        this.describe = describe;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescribe() {
        return describe;
    }

    public void setDescribe(String cname) {
        this.describe = cname;
    }

    public static String getNameByCode(String code){
        for (ShellNameEnum eventEnum : ShellNameEnum.values()) {
            if (eventEnum.code.equals(code)){
                return eventEnum.getName();
            }
        }
        return null;
    }
}
