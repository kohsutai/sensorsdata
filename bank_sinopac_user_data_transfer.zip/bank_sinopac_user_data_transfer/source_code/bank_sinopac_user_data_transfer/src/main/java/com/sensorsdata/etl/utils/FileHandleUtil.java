package com.sensorsdata.etl.utils;

import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;
import com.sensorsdata.etl.exception.FileParseException;
import com.sensorsdata.etl.module.vo.UserDefineVO;
import lombok.extern.slf4j.Slf4j;

import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Slf4j
public class FileHandleUtil {
    FileHandleUtil(){}

    public static List<UserDefineVO> getUserDefineList(Map<String,String> presetFieldMap){
        List<UserDefineVO> result = new ArrayList<>();
        if(presetFieldMap != null){
            presetFieldMap.forEach((key,value)->{
                UserDefineVO vo = new UserDefineVO();
                vo.setName(key);
                vo.setType(value);
                result.add(vo);
            });
        }
        result.addAll(getUserDefineListFromCsv());
        return result;
    }

    private static List<UserDefineVO> getUserDefineListFromCsv(){
        String dataDir = BaseFileUtil.getDataDir();
        try(InputStream resourceAsStream = new FileInputStream(dataDir + "users_define"); InputStreamReader reader = new InputStreamReader(resourceAsStream, StandardCharsets.UTF_8)){
            // 不需要标题行，列的顺序通过CsvBindByPosition注解的position属性指定
            CsvToBean<UserDefineVO> csvToBean = new CsvToBeanBuilder<UserDefineVO>(reader)
                    .withType(UserDefineVO.class)
                    .build();
            return csvToBean.parse();
        }catch (Exception e){
            log.error("parse user define file error", e);
            throw new FileParseException();
        }
    }
}
