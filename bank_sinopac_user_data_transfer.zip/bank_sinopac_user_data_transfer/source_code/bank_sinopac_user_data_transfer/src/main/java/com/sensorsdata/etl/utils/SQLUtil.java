package com.sensorsdata.etl.utils;

import com.sensorsdata.etl.module.vo.UserDefineVO;
import lombok.extern.slf4j.Slf4j;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

@Slf4j
public class SQLUtil {
    private SQLUtil(){}

    public static String jointCreateSql(List<UserDefineVO> fieldList, Map<String, String> fieldTypeMap){
        StringBuilder sql = new StringBuilder();
        Iterator<UserDefineVO> iterator = fieldList.iterator();
        while (iterator.hasNext()){
            UserDefineVO vo = iterator.next();
            String type = fieldTypeMap.get(vo.getType());

            sql.append("`");
            sql.append(vo.getName().replace("$","dollar_"));
            sql.append("` ");
            sql.append(type);

            if(iterator.hasNext()){
                sql.append(",");
            }
        }
        return sql.toString();
    }

    public static String jointLoadSql(String tableName,List<String> fieldNameList){
        StringBuilder sql = new StringBuilder("select ");
        Iterator<String> iterator = fieldNameList.iterator();
        while (iterator.hasNext()){
            String fieldName = iterator.next();
            sql.append("`");
            sql.append(fieldName);
            sql.append("`");
            if(iterator.hasNext()){
                sql.append(",");
            }
        }
        sql.append(" from ");
        sql.append(tableName);
        return sql.toString();
    }
}
