package com.sensorsdata.etl.module.vo;

import com.opencsv.bean.CsvBindByPosition;
import lombok.Data;

@Data
public class UserDefineVO {
    @CsvBindByPosition(position = 0)
    public String name;

    @CsvBindByPosition(position = 1)
    public String type;
}
