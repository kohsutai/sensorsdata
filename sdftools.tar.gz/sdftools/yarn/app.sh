#!/bin/bash

# $Name:         app.sh
# $Version:      v1.0
# $Function:     分析 event_merge 去重数
# $Author:       liuxiaopeng
# $Create Date:  2022年04月26日20:18:00
# $Description:  分析event_merge 去重数
#######################################################
# Shell Env
SHELL_NAME=`basename $0`
SHELL_DIR="/tmp"
SHELL_LOG="${SHELL_DIR}/${SHELL_NAME}.log"
LOCK_FILE="/tmp/${SHELL_NAME}.lock"

# mains
#Write Log
shell_log(){
    LOG_INFO=$1
        echo "$(date "+%Y-%m-%d") $(date "+%H:%M:%S") : ${SHELL_NAME} : ${LOG_INFO}" >> ${SHELL_LOG}
        }

red_color(){
    CONTENT=$1
        echo -e "\033[31m $CONTENT \033[0m"
        }
green_color(){
    CONTENT=$1
        echo -e "\033[32m $CONTENT \033[0m"
        }

while read line
do
    appId=`echo $line |awk '{print $1}'`
    jobId=`echo $appId|sed 's#application#job#g'`
    appInfo=`yarn application -status $appId`
    appStartTime=$(date -d @`echo $appInfo|awk -F 'Start-Time : ' '{print $2}'|awk '{print $1}'|cut -b1-10`)
    appStopTime=$(date -d @`echo $appInfo|awk -F 'Finish-Time : ' '{print $2}'|awk '{print $1}'|cut -b1-10`)
    appStatus=`echo $appInfo|awk -F 'Log Aggregation Status : ' '{print $2}'|awk '{print $1}'`
    distinctCount=`hadoop job -status $jobId|grep duplicated_count|awk -F '=' '{print $2}'`
    shell_log "任务ID：$appId 开始时间：$appStartTime 完成时间：$appStopTime 任务状态：$appStatus 去重数：$distinctCount"
done < a
