# encoding: utf-8

# @File    : get_yml_data.py
# @Date    : 2024年04月02日17:10:35
# @Author  : from op-tools
# @Desc:   : 根据 yml 文件生成数据

import yaml
from yaml.loader import SafeLoader

class GetYmlData:
    def __init__(self, *, yaml_file_path: str = ""):
        self.yaml_file_path = yaml_file_path

    def load_yaml(self):
        with open(self.yaml_file_path) as f:
            data = yaml.load(f, Loader=SafeLoader)
            return data
