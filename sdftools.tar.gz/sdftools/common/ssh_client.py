# encoding: utf-8

# @File    : ssh_client.py
# @Date    : 2022/4/20 21:23
# @Author  : wangfei@sensorsdata.cn
# @Desc:

import os
import sys
import json
import datetime
import paramiko
from hyperion_client.deploy_topo import DeployTopo

# scout path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))


RUNTIME_DIR = "/tmp"

lst_hostname = DeployTopo().get_all_host_list()

try:
    from hyperion_client.node_info import NodeInfo
    ssh_port = NodeInfo().get_node_ssh_port(hostname=line_hostname)
except Exception:
    ssh_port = 22
class DatetimeSerializer(json.JSONEncoder):
    """
    实现 date 和 datetime 类型的 JSON 序列化，以符合 SensorsAnalytics 的要求。
    """

    def default(self, obj):
        if isinstance(obj, datetime.datetime):
            head_fmt = "%Y-%m-%d %H:%M:%S"
            return "{main_part}.{ms_part}".format(
                main_part=obj.strftime(head_fmt),
                ms_part=int(obj.microsecond / 1000))
        elif isinstance(obj, datetime.date):
            fmt = '%Y-%m-%d'
            return obj.strftime(fmt)
        return json.JSONEncoder.default(self, obj)


def dict_to_json(item, indent=2):
    """
    Desc: convert dict to json with 2 indents
    Args:
        item: dict item
        indent: indent

    Returns: json
    """
    json_results = json.dumps(item, indent=indent, cls=DatetimeSerializer, ensure_ascii=False)

    return json_results

username = os.environ.get('USER')
class SSHClient(object):
    def __init__(self,hostname, port=ssh_port, username=username, password=None, key_filename=None,
        encoding='utf8', timeout=21, debug=False,
        logger=None,):
        self.run_user = os.environ.get('USER')
        self._logger = logger
        self.runtime_dir = "{}/runtime".format(RUNTIME_DIR)
        self.encoding = encoding
        self.params = {
            'hostname': hostname,
            'port': port,
            'username': username,
            'password': password,
            'key_filename': key_filename,
            'timeout': timeout,
        }

        if debug:
            logger_dir = os.path.join(self.runtime_dir, 'paramiko-debug')
            if not os.path.exists(logger_dir):
                os.makedirs(logger_dir, exist_ok=True)
            paramiko.util.log_to_file('{}/{}.log'.format(logger_dir, hostname))

        self.client = paramiko.SSHClient()
        self.client.load_system_host_keys()
        self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self.is_connected = False

    def __del__(self):
        try:
            self.client.close()
        except Exception as e:
            print(e, file=sys.stderr)

    def logger(self, msg, level='debug'):
        """
        Desc: no exception logger
        Args:
            msg: message to log
            level: log level

        Returns: None

        """

        if self._logger:
            getattr(self._logger, level.lower())(msg)
        else:
            this_time = datetime.datetime.now().strftime("%Y-%m-%d %X.%f")
            print('{} {} {}'.format(this_time, level.upper(), msg))

    def get_ssh_params(self):
        return self.params

    def check_paramiko(self, cmd='echo "Hello Panda"'):
        """
        Desc: check paramiko by run command on remote host
        Args:
            cmd: system command

        Returns: (True/False, command_result)

        """

        res = self.run_cmd(cmd)
        if res['ret'] == 0:
            return True, res
        else:
            return False, res

    def connect(self):
        if self.is_connected:
            return True

        try:
            self.client.connect(**self.params)
            self.is_connected = True
        except Exception as e:
            msg = '[{}] login [{}].{} failed'.format(
                self.run_user,
                self.params['hostname'],
                dict_to_json(self.params, indent=None)
            )

            self.logger('{}\n{}'.format(msg, str(e)), level='error')
            raise Exception(msg)

    def invoke_shell(self):
        self.connect()

        return self.client.invoke_shell(term='Xterm')

    def get_transport(self):
        self.connect()

        return self.client.get_transport()

    def run_cmd(self, cmd, timeout=300):
        self.connect()
        stdin_fd, stdout_fd, stderr_fd = self.client.exec_command(cmd, timeout=timeout, get_pty=True)
        ret = stdout_fd.channel.recv_exit_status()
        stdout, stderr = stdout_fd.read().decode(self.encoding), stderr_fd.read().decode(self.encoding)

        return {'host': self.params['hostname'], 'cmd': cmd, 'ret': ret, 'stdout': stdout, 'stderr': stderr}

    def copy_from_local(self, local_file, remote_file, timeout=600):
        self.connect()
        try:
            sftp = paramiko.SFTPClient.from_transport(self.client.get_transport())
            sftp.get_channel().settimeout(timeout)
            sftp.put(local_file, remote_file)
            sftp.close()

        except FileNotFoundError:
            raise Exception('copy [{}] to [{}].[{}] failed, check parent dirs'.format(
                local_file, self.params['hostname'], remote_file
            ))

    def copy_from_remote(self, remote_file, local_file, timeout=600):
        self.connect()
        try:
            sftp = paramiko.SFTPClient.from_transport(self.client.get_transport())
            sftp.get_channel().settimeout(timeout)
            sftp.get(remote_file, local_file)
            sftp.close()

        except FileNotFoundError:
            raise Exception('copy [{}].[{}] to [{}] failed, check parent dirs'.format(
                self.params['hostname'], remote_file, local_file
            ))

#cmd = "ls"
#for hostname in lst_hostname:
#    ssh_client = SSHClient(hostname=hostname,port=ssh_port)
#    res = ssh_client.run_cmd(cmd)
#    print(res)

