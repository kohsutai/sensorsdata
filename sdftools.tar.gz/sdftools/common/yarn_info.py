# encoding: utf-8

# @File    : yarn_info.py
# @Date    : 2022年07月15日16:13:41
# @Author  : liuxiaopeng
# @Desc:

import json
import os
from date_tools import nyrsfm
import xml.etree.ElementTree as ET
from urllib.request import urlopen
from hyperion_client.config_manager import ConfigManager
from hyperion_client.deploy_info import DeployInfo
from date_tools import miao
import utils.sa_kerberos
from check_services import is_ge_sp2_1_version
from sdf_utils import sdf_major_version


# 请求对应 url 然后返回 json 格式
def req_get_json(url):
    return json.loads(urlopen(url).read().decode('utf-8'))

# 获取 yarn 管理地址
def get_yarn_rm_address():
    # 单机不做处理,集群才执行
    rm_hostnames=[]
    if not DeployInfo().get_simplified_cluster():
        conf_dict = {}
        file_path = "/etc/hadoop/conf/yarn-site.xml"
        if is_ge_sp2_1_version():
            from hyperion_guidance.mothership_connector import MothershipConnector
            connector = MothershipConnector().get_instance()
            rm_addresses = connector.get_role_deploy_nodes("yarn", "resourcemanager")
            rm_hostnames = [x + ':8088' for x in rm_addresses]
            return rm_hostnames
        else:
            try:
                tree = ET.parse(file_path)
                for prop in tree.getroot().findall('property'):
                    key = prop.find('name').text
                    value = prop.find('value').text
                    conf_dict[key] = value
                for key in conf_dict.keys():
                    if "yarn.resourcemanager.webapp.address" in key or "yarn.resourcemanager.webapp.address."  in key:
                            yarn_resourcemanager_webapp_address = conf_dict[key]
                            rm_hostnames.append(yarn_resourcemanager_webapp_address)
                return list(set(rm_hostnames))
            except Exception:
                # print(e)
                return False
    else:
        return False
    

def is_double_backup_or_active():
    yarn_rm_address=get_yarn_rm_address()
    if yarn_rm_address:
        double_status_count = 0
        for rm_hostname in yarn_rm_address:
            base_url = "http://" + rm_hostname
            url = base_url + "/ws/v1/cluster/info"
            try:
                if "ACTIVE" == req_get_json(url=url)["clusterInfo"]["haState"]:
                    double_status_count += 1
            except Exception:
                pass       
        if double_status_count != 1:
            return True
        else:
            return False
    else:
        return False



def get_yarn_resourcemanager_webapp_address():
    yarn_rm_address = get_yarn_rm_address()
    if yarn_rm_address:
        for rm_hostname in yarn_rm_address:
            base_url = "http://" + rm_hostname
            url = base_url + "/ws/v1/cluster/info"
            # print("sp version: %s yarn 资源管理接口地址：%s" %(is_ge_sp2_1_version(),url))
            try:
                if "ACTIVE" == req_get_json(url=url)["clusterInfo"]["haState"]:
                    return base_url
                    break
            except Exception:
                return False
    else:
        return False

# print(get_yarn_resourcemanager_webapp_address_res)
def yarn_clusterMetrics():
    """
    通过 yarn 接口获取 yarn clusterMetrics 信息
    """
    get_yarn_resourcemanager_webapp_address_res = get_yarn_resourcemanager_webapp_address()
    if get_yarn_resourcemanager_webapp_address_res:
        metrics_url = get_yarn_resourcemanager_webapp_address_res + "/ws/v1/cluster/metrics"
        metrics_res = req_get_json(url=metrics_url)
        res = metrics_res["clusterMetrics"]
        return res
    else:
        return 0   
    
def yarn_clusterMetrics_key(key):
    """
    获取 yarn clusterMetrics 子信息
    """
    yarn_clusterMetrics_res = yarn_clusterMetrics()
    if yarn_clusterMetrics_res:
        res = yarn_clusterMetrics_res[key]
        return res
    else:
        return 0


# 判断 yarn 资源池是否被占满
def containersPending_num():
    res = yarn_clusterMetrics_key(key="containersPending")
    return res
# def containersPending_num():
#     get_yarn_resourcemanager_webapp_address_res = get_yarn_resourcemanager_webapp_address()
#     if get_yarn_resourcemanager_webapp_address_res:
#         metrics_url = get_yarn_resourcemanager_webapp_address_res + "/ws/v1/cluster/metrics"
#         metrics_res = req_get_json(url=metrics_url)
#         containersPending_num = metrics_res["clusterMetrics"]["containersPending"]
#         return containersPending_num
#     else:
#         return 0

# 判断 yarn unhealthyNodes 个数
def unhealthyNodes_num():
    res = yarn_clusterMetrics_key(key="unhealthyNodes")
    return res
# def unhealthyNodes_num():
#     get_yarn_resourcemanager_webapp_address_res = get_yarn_resourcemanager_webapp_address()
#     if get_yarn_resourcemanager_webapp_address_res:
#         metrics_url = get_yarn_resourcemanager_webapp_address_res + "/ws/v1/cluster/metrics"
#         metrics_res = req_get_json(url=metrics_url)
#         unhealthyNodes_num = metrics_res["clusterMetrics"]["unhealthyNodes"]
#         return unhealthyNodes_num
#     else:
#         return 0

def yarn_totalMB():
    res = yarn_clusterMetrics_key(key="totalMB")
    return res

def yarn_totalVirtualCores():
    res = yarn_clusterMetrics_key(key="totalVirtualCores")
    return res



# 处理 yarn application 函数，整合 application 任务信息，找到最新一次失败的 application 信息
def handle_yarn_apps_info(apps_res,app_name):
    count = 0
    msg = {}
    app_finish_time_list = []
    try:
        for app in apps_res["apps"]["app"]:
            if app_name in app["name"]:
                app_finish_time_list.append(app["finishedTime"])
                count += 1
        if len(app_finish_time_list) == 0:
            msg["app_name"] = app_name
            msg["count"] = 0
            msg["max_finish_time"] = 0
            msg["appid"]=0
            msg["startedtime"]=0
        else:
            day_ago_app_finishtime_max = max(app_finish_time_list)
            msg["app_name"] = app_name
            msg["count"] = count
            msg["max_finish_time"] = day_ago_app_finishtime_max
            for app1 in apps_res["apps"]["app"]:
                if app_name in app1["name"]:
                    if day_ago_app_finishtime_max == app1["finishedTime"]:
                        appid = app1["id"]
                        appname = app1["name"]
                        msg["appid"] = appid
                        msg["appname"] = appname
                        msg["startedtime"] = app1["startedTime"]
    except Exception:
        msg["app_name"] = app_name
        msg["count"] = 0
        msg["max_finish_time"] = 0
        msg["appid"]=0
        msg["startedtime"] = 0
    return msg

# 整合 killed failed succeeded 任务信息，并将需要的 application 任务日志输出到文件，供下游日志检索使用
def get_yarn_apps():
    get_yarn_resourcemanager_webapp_address_res = get_yarn_resourcemanager_webapp_address()
    res = get_yarn_resourcemanager_webapp_address_res
    sdf_major_version1 = sdf_major_version()
    if res:
        yarn_info = {}
        yarn_info_data = {"Yarn_info":{}}
        containersPending = containersPending_num()
        unhealthyNodes = unhealthyNodes_num()
        if containersPending > 0:
            yarn_info_data["Yarn_info"]["ERROR Yarn"] = "yarn 资源池满，vcore pending : %s，需要看看是不是正常的任务占用的，如果实在没法调整 yarn 资源了，sdf 2.4.0.5072+ 可以调整参数：parquet_converter_reduce_slowstart_completedmaps = 0.85 默认 0.05，会降低些资源占用，重启 dl 生效" %containersPending
            yarn_info.update(yarn_info_data)
        if unhealthyNodes > 0:
            yarn_info_data["Yarn_info"]["ERROR Yarn unhealthyNodes"] = "yarn 集群存在不健康节点数量为: %s，检查下 yarn 状态，是否存在磁盘满或者负载高情况，都可能导致 nodemanager 服务异常" %unhealthyNodes
            yarn_info.update(yarn_info_data)  
        # 获取 kafka topic 信息，用户定位是什么类型的 mr 任务
        kafka_client_conf = ConfigManager().get_client_conf("sp", "kafka")
        event_topic_name = "SDW_EVENT_INSERT"
        profile_topic_name = "SDW_MUTABLE"
        remapping_topic_name = "SDW_EVENT_UPDATE"
        if sdf_major_version1:
            event_topic_name = "SDW_EVENT_INSERT" if  sdf_major_version1 == "3.0" else kafka_client_conf["topic_name"]
            profile_topic_name = "SDW_MUTABLE" if sdf_major_version1 == "3.0"  else kafka_client_conf["profile_topic_name"]
        event_kc_mr_log = "event_kc_mr.log"
        item_topic_name = kafka_client_conf["item_topic_name"]
        item_kc_mr_log = "item_kc_mr.log"
        profile_kc_mr_log = "profile_kc_mr.log"

        try:
            if sdf_major_version1:
                remapping_topic_name = "SDW_EVENT_UPDATE" if sdf_major_version1 == "3.0" else kafka_client_conf["sdf_remapping_topic_name"]
        except Exception:
            remapping_topic_name = "sdf_remapping_topic"
        try:
            sdf_id_mapping_v3_command_topic_name = kafka_client_conf["sdf_id_mapping_v3_command_topic_name"]
        except Exception:
            sdf_id_mapping_v3_command_topic_name = "sdf_id_mapping_v3_command_topic"
        sdw_input_topic_name = "SDW_INPUT_TOPIC"
        sdw_input_topic_name_log = "sdw_input.log"
        command_mr_log = "command_mr.log"
        remapping_mr_log = "remapping_mr.log"
        event_merge_name = "merge"
        merge_mr_log = "merge_mr.log"
        event_distinct_name = "distinct"
        distinct_mr_log = "distinct_mr.log"
        event_delete_name = "delete"
        delete_mr_log = "delete_mr.log"
        k2p_name = "KuduToParquet"
        k2p_mr_log = "k2p_mr.log"
        distcp_name = "DistCpJob"
        distcp_log = "distcp_mr.log"
        mutable_name = "mutable"
        mutable_mr_log ="mutable_mr.log"
        device_id_remapping_mr_log = "device_id_remapping_mr.log"
        device_id_remapping_name = "device_id_remapping"
        touch_log_cmd = ">/tmp/sdflogs/%s >/tmp/sdflogs/%s >/tmp/sdflogs/%s >/tmp/sdflogs/%s >/tmp/sdflogs/%s >/tmp/sdflogs/%s >/tmp/sdflogs/%s >/tmp/sdflogs/%s >/tmp/sdflogs/%s  >/tmp/sdflogs/%s >/tmp/sdflogs/%s >/tmp/sdflogs/%s >/tmp/sdflogs/%s"  %(event_kc_mr_log,item_kc_mr_log,profile_kc_mr_log,k2p_mr_log,merge_mr_log,distinct_mr_log,delete_mr_log,remapping_mr_log,command_mr_log,distcp_log,mutable_mr_log,device_id_remapping_mr_log,sdw_input_topic_name_log)
        os.popen(touch_log_cmd).readlines()
        jobs_list = [event_topic_name + ":" + event_kc_mr_log,item_topic_name + ":" + item_kc_mr_log,profile_topic_name + ":" + profile_kc_mr_log,event_merge_name  + ":" + merge_mr_log,event_distinct_name  + ":" + distinct_mr_log,event_delete_name  + ":" + delete_mr_log ,k2p_name  + ":" + k2p_mr_log,remapping_topic_name  + ":" + remapping_mr_log,sdf_id_mapping_v3_command_topic_name  + ":" + command_mr_log,distcp_name + ":" + distcp_log,mutable_name + ":" + mutable_mr_log,device_id_remapping_name + ":" + device_id_remapping_mr_log,sdw_input_topic_name + ":"+ sdw_input_topic_name_log]

        # 只查找最近一天的 apps
        day_ago_ms = (miao() - 86400)*1000
        app_uri = "/ws/v1/cluster/apps?startedTimeBegin=%s" %(day_ago_ms)
        yarn_apps_url = res + app_uri
        print(yarn_apps_url)
        res1 = req_get_json(url=yarn_apps_url)
        apps = res1.get("apps")

        # 先对结果进行判断，是否存在结果集，不存在，说明最近一天没有 apps 任务提交到 yarn ，可能 kc 一直有问题，这里做了一层处理，不存在结果集，添加个默认的 key app

        if not apps:
            res1 = {"apps": {"app": []}}

        yarn_apps_failed_res = {"apps":{"app":[]}}
        yarn_apps_killed_res = {"apps":{"app":[]}}
        if len(res1["apps"]["app"]) > 0:
            for app in res1["apps"]["app"]:
                if app.get("finalStatus") == "FAILED" or ( app.get("finalStatus") == "SUCCEEDED" and "-stream" in app.get("name") ):
                    yarn_apps_failed_res["apps"]["app"].append(app)
                elif app.get("finalStatus") == "KILLED":
                    yarn_apps_killed_res["apps"]["app"].append(app)
                else:
                    pass
        
        day_ago_apps_count = len(res1["apps"]["app"])
        day_ago_apps_failed_count = len(yarn_apps_failed_res["apps"]["app"])
        day_ago_apps_killed_count = len(yarn_apps_killed_res["apps"]["app"])
        yarn_info_data["Yarn_info"]["Apps_info"]="total_apps:%s,failed_apps:%s,killed_apps:%s" %(day_ago_apps_count,day_ago_apps_failed_count,day_ago_apps_killed_count)
        yarn_info.update(yarn_info_data)
        # 分析每个 job 的信息，并将最新的失败任务日志输出到文件
        for job_name_info in jobs_list:
            job_name = job_name_info.split(':')[0]
            log_name_tmp = job_name_info.split(':')[1]
            failed_job_res = handle_yarn_apps_info(yarn_apps_failed_res,job_name)
            killed_job_res = handle_yarn_apps_info(yarn_apps_killed_res,job_name)
            failed_job_count = failed_job_res["count"]
            killed_job_count = killed_job_res["count"]
            last_failed_appid = failed_job_res["appid"]
            last_finished_failed_time = nyrsfm(failed_job_res["max_finish_time"]/1000)
            last_started_time = nyrsfm(failed_job_res["startedtime"]/1000)
            if failed_job_count > 0 or killed_job_count >0:
                yarn_info_data["Yarn_info"][job_name] = "failed_count:%s,killed_count:%s,last_failed_appid:%s,last_failed_started_time:%s,last_failed_finished_time:%s" %(failed_job_count,killed_job_count,last_failed_appid,last_started_time,last_finished_failed_time)
                yarn_info.update(yarn_info_data)
            if failed_job_count > 0:
                if job_name in failed_job_res["appname"]:
                    log_name = log_name_tmp
                    
                keytab = utils.sa_kerberos.getKeytab()
                princname = utils.sa_kerberos.getPrincipalName("yarn")
                # mr 日志最多取 50M 防止解析过慢
                if princname != "":
                    get_failed_mr_log_cmd = '''kinit -kt %s %s; yarn logs -applicationId %s --size -5242880 &>/tmp/sdflogs/%s ''' %(keytab,princname,last_failed_appid,log_name)
                else:
                    get_failed_mr_log_cmd = '''yarn logs -applicationId %s --size -5242880 &>/tmp/sdflogs/%s ''' %(last_failed_appid,log_name)
                # mr 任务失败太快的情况，日志还没准备好呢，会导致拉取日志为空，需要 time.sleep(5) 等一会儿可解决，先不加该逻辑
                # time.sleep(5)
                os.popen(get_failed_mr_log_cmd).readlines()
        return yarn_info
    else:
        return False

if __name__ == '__main__':
    print(containersPending_num())
    print(unhealthyNodes_num())
    print(yarn_totalMB())
    print(yarn_totalVirtualCores())

