# encoding: utf-8

# @File    : check_services.py
# @Date    : 2022年07月14日09:43:20
# @Author  : liuxiaopeng
# @Desc:  获取各种服务状态信息

import os
import socket
import prettytable
import re
import json
import urllib.parse
import urllib.request
import urllib.error
from utils import config_manager
import utils.product_major_dependency
from colored_logging import get_logger
logger = get_logger(__name__)
from get_mem_cpu_disk_info import ntp_info
from hyperion_client.deploy_topo import DeployTopo
from hyperion_client.deploy_info import DeployInfo
from hyperion_client.config_manager import ConfigManager
from hyperion_utils.shell_utils import check_output
from hdfs_info import check_nn_status
import utils.sa_utils
from distutils.version import LooseVersion
from check_kafka import check_kafka



def check_hdfs_safe_mode():
    try:
        cmd = """sudo -u hdfs hdfs dfsadmin -report|grep 'Safe mode is ON'"""
        res = os.popen(cmd).readlines()
        if "Safe mode is ON" in res[0]:
            return True
        else:
            return False
    except Exception as e:
        error_msg = "Exception:{}".format(e)
        return False
    

# 检查 kudu 是否均衡
def get_average(records):
    """
    平均值
    """
    return sum(records) / len(records)


def get_variance(records):
    """
    方差 反映一个数据集的离散程度
    """
    average = get_average(records)
    return sum([(x - average) ** 2 for x in records]) / len(records)


def check_ntp():
    """
    检查主机时钟是否同步，节点越多越不精确，for 循环执行 cmd 命令，会有损耗
    """
    ntp_check_info = {}
    if ntp_info():
        ntp_list = ntp_info()
        # print(ntp_list)
        # print(get_variance(ntp_list))
        if get_variance(ntp_list) > 21:
            ntp_check_info["code"]="200"
            ntp_check_info["Ntp_status"] = ntp_list
            ntp_check_info["Ntp_ERROR"] = "主机之间时钟可能不同步，偏差超过 20s，建议检查下时钟服务"
        return ntp_check_info
    else:
        return False


def check_version(current_version, target_version):
    """
    检查版本是否满足
    """
    current_version_list = current_version.split('.')
    target_version_list = target_version.split('.')
    for i in range(len(current_version_list)):
        if int(current_version_list[i]) > int(target_version_list[i]):
            return True
        elif int(current_version_list[i]) < int(target_version_list[i]):
            return False
    return False


def get_sm_version():
    if is_ge_sp2_0_version():
        sm_version =  DeployTopo().get_product_full_version("sm")
    else:
        sm_version = utils.product_major_dependency.get_full_version("sm")
    return sm_version


def check_sm_version():
    """
    检查 sm 的版本，版本小于 2.0.12734 或者 2.1.0.113 需要升级下，解决 /proc/*/smaps_rollup 慢的问题，导致 skv 每隔30s请求慢的>问题
    """
    sm_version = get_sm_version()
    if len(sm_version.split('.')) == 3:
        if not check_version(sm_version,target_version="2.0.12733"):
            return True
    else:
        if not check_version(sm_version,target_version="2.1.0.112"):
            return True
    return False


def get_sp_version():
    """
    获取 sp 版本，sp2.1 后 接口和命令都变了
    """
    sp_version = DeployTopo().get_product_major_version("sp")
    return sp_version


def is_ge_sp2_1_version():
    if LooseVersion(get_sp_version()) >= LooseVersion("2.1.0"):
        return True


def is_ge_sp2_0_version():
    if LooseVersion(get_sp_version()) >= LooseVersion("2.0.0"):
        return True


def get_conf_key_value(key,product="sdf",namespace="data_loader",default_value="false"):
    """
    获取配置
    :param product: 产品线名称
    :param namespace: 命名空间/模块名称
    :param key: 查询的 key
    :param default_value:  查不到配置时使用默认值
    :return: 查询 key 的值
    """
    if is_ge_sp2_1_version():
        cmd = 'sbpadmin business_config -a get -p {} -n {} -k {} -t json'.format(product, namespace, key)
        res = json.loads(check_output(cmd=cmd, print_fun=lambda x: None, timeout=60))
        value = res['value']
        if value is None or value.strip().lower() == 'null':
            value = default_value
    else:
        conf_dict = ConfigManager().get_server_conf(product, namespace)
        value = conf_dict.get(key, default_value)
    return value


def get_enable_chain1():
    try:
        enable_chain = get_conf_key_value(key="enable_chain",product="sdg",namespace="web",default_value=False)
        if enable_chain == "false":
            return False
    except Exception as e:
        return False
    return enable_chain


def get_kafka_cluster_acks_config():
    kafka_cluster_acks_config = get_conf_key_value(key="kafka_cluster_acks_config",namespace="extractor",default_value=-1)
    return kafka_cluster_acks_config


def optimizable_items():
    """
    调优项
    """
    optimizable_items_info = {"Optimizable_items":{}}

    if check_sm_version():
        sm_version = get_sm_version()
        sm_bug_version = "2.0.12734" if len(sm_version.split('.')) == 3 else  "2.1.0.113"
        optimizable_items_info["Optimizable_items"]["ERROR_optimiz_sm"] = "环境 sm 版本：%s 小于 %s ，建议升级 sm 到最新版本，解决 /proc/*/smaps_rollup 慢的问题，大内存情况下可能导致 skv 每隔 30s 请求慢" %(sm_version,sm_bug_version)
    if get_enable_chain1():
        optimizable_items_info["Optimizable_items"]["ERROR_enable_chain"] = "注意！！！环境开启了干路化"
    if not check_nn_status():
        optimizable_items_info["Optimizable_items"]["ERROR_nn_status"] = "请检查下 nn 状态，可能双备了！！！"
    if int(get_kafka_cluster_acks_config()) == 1:
        optimizable_items_info["Optimizable_items"]["ERROR_kafka_acks_config"] = "环境 ex 配置了 kafka_cluster_acks_config 为 1，kafka client 默认不开重试，所以切主后，只能依赖 ex 自身的重启机制了，会导致 ex 不重试直接挂掉，建议将该参数去除，重启 ex 生效"
    if not check_kafka() and not DeployInfo().get_simplified_cluster():
            optimizable_items_info["Optimizable_items"]["ERROR Kafka status"] = "Kafka 状态异常，混部的环境可忽略，查看状态：kafka-topics --zookeeper `cat ~/conf/sensors_data.property |grep zookeeper.connect|awk -F '=' '{print $NF}'` --topic event_topic --describe"
    return optimizable_items_info
        

### 获取 impala session 信息
def _default_pretty_table(line_iter):
    '''把二位数组变成pretty table 默认左对齐'''
    pt = prettytable.PrettyTable(field_names=next(line_iter))
    pt.align = 'l'
    for line in line_iter:
        pt.add_row(line)
    return pt


def _format_iter(cols, records):
    '''返回打印记录的表格'''
    yield cols
    for record in records:
        yield [record[c] for c in cols]


def request_impala_web(backend, path, params={}, port=25000):
    url = "http://" + backend + ":" + str(port) + "/" + path + "?" + urllib.parse.urlencode(params) + "&json"
    try:
        content = json.loads(urllib.request.urlopen(url, timeout = 10).read())
    except urllib.error.URLError as e:
        raise Exception("fail to connect to impala host : %s, reason : %s" % (backend, str(e.reason)))
    except socket.timeout:
        raise Exception("connection timeout on impala host : %s" % backend)
    return content
    

def show_total_session_info():
    """
    获取 impala session 连接信息
    """   
    impala_client_conf = config_manager.get_impala_client_conf()
    hive_url_host = impala_client_conf['hive_url_list'][0]
    m = re.match(r'jdbc:hive2://(.*?):\d+/', hive_url_host)
    impala_bootstrap_backend = m.group(1)
    backends = request_impala_web(impala_bootstrap_backend, 'backends', {})['backends']
    total_session_info = []
    impala_hosts = []
    # 多实例的环境会存在 backend 的 host 相同，但端口号不同
    for backend in backends:
        impala_host = backend['address'].split(':')[0]
        if impala_host in impala_hosts:
            continue
        session_info = {}
        impala_hosts.append(impala_host)
        session_info['host'] = impala_host
        # 获取 connection limit
        connection_limit = 0
        json_varz = request_impala_web(impala_host, 'varz')
        for flag in json_varz['flags']:
            if flag['name'] == 'fe_service_threads':
                connection_limit = int(flag['current'])
                break
        if connection_limit == 0:
            raise Exception("failed to get fe_service_threads on impala host : %s" % impala_host)
        session_info['connection_limit'] = connection_limit

        # 获取正在使用的连接数
        try:
            json_metrics = request_impala_web(impala_host, 'jsonmetrics')
            connection_in_use = json_metrics["impala.thrift-server.hiveserver2-frontend.connections-in-use"]
            session_info['connection_in_use'] = connection_in_use
        except Exception:
            connection_in_use = 0
            session_info['connection_in_use'] = connection_in_use

        # 获取 session
        try:
            json_sessions = request_impala_web(impala_host, 'sessions')
            session_total = json_sessions['num_sessions']
            session_info['session_total'] = session_total
        except Exception:
            session_total = 0
            session_info['session_total'] = session_total

        # 判断是否连接满
        connection_full = True if connection_in_use >= connection_limit else False
        session_info['connection_full'] = connection_full
        total_session_info.append(session_info)
    cols =  ['host', 'connection_limit', 'connection_in_use', 'session_total', 'connection_full']
    for session_info in total_session_info:
        if session_info["connection_full"] == True:
            logger.info('show total session info:\n%s' % _default_pretty_table(_format_iter(cols, total_session_info)))
            return True
    return False        


if __name__ == '__main__':
   show_total_session_info()