# encoding: utf-8

# @File    : unit_conversion.py
# @Date    : 2024年04月18日10:28:00
# @Author  : liuxiaopeng
# @des     : 单位转换脚本

def convert_to_byte_unit(num):
    """
    byte 单位自动转换
    """
    units = ['MB', 'GB', 'TB']
    unit_index = 0
    while num >= 1024 and unit_index < len(units) - 1:
        num /= 1024
        unit_index += 1
    return f'{num:.2f} {units[unit_index]}'

def convert_to_mb_unit(num):
    """
    mb 单位自动转换
    """
    units = ['MB', 'GB', 'TB']
    unit_index = 0
    while num >= 1024 and unit_index < len(units) - 1:
        num /= 1024
        unit_index += 1
    return f'{num:.2f} {units[unit_index]}'