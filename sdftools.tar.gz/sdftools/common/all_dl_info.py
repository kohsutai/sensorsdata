# encoding: utf-8

# @File    : all_dl_info.py
# @Date    : 2022年06月25日16:32:58
# @Author  : liuxiaopeng
# @Desc:  dl 的所有信息

import json
import os
from hyperion_client.config_manager import ConfigManager
import utils.sa_utils
import utils.product_major_dependency
from hyperion_client.deploy_info import DeployInfo
from hyperion_utils.shell_utils import check_output
from check_services import check_hdfs_safe_mode
from yarn_info import get_yarn_apps
from hdfs_info import check_nn_status
from check_services import check_ntp
from check_services import show_total_session_info
from check_services import is_ge_sp2_1_version
from all_kudu_info import KuduInfo
from get_prom_data import get_avg_import_rate
from check_kafka import check_kafka
from distutils.version import LooseVersion
from sdf_utils import sdf_major_version,get_sdf_full_version


sdf_major_version_res = sdf_major_version()
get_sdf_full_version_res = get_sdf_full_version()

def is_sdf_bug_version():
    if sdf_major_version_res == "2.4":
        if LooseVersion("2.4.0.4650") <= LooseVersion(get_sdf_full_version_res) < LooseVersion("2.4.0.4762"):
            return True 
    elif sdf_major_version_res == "2.3":
        if LooseVersion("2.3.1.4143") <= LooseVersion(get_sdf_full_version_res) < LooseVersion("2.3.1.4163"):
            return True
    else:
        return False


def get_sdftools_version():
    version_info = "0.1.45.dev20241016173240"
    return version_info


def get_dl_conf(key,product="sdf",namespace="data_loader",default_value="false"):
    """
    获取配置
    :param product: 产品线名称
    :param namespace: 命名空间/模块名称
    :param key: 查询的 key
    :param default_value:  查不到配置时使用默认值
    :return: 查询 key 的值
    """
    if is_ge_sp2_1_version():
        cmd = 'sbpadmin business_config -a get -p {} -n {} -k {} -t json'.format(product, namespace, key)
        res = json.loads(check_output(cmd=cmd, print_fun=lambda x: None, timeout=60))
        value = res['value']
        if value is None or value.strip().lower() == 'null':
            value = default_value
    else:
        conf_dict = ConfigManager().get_server_conf(product, namespace)
        value = conf_dict.get(key, default_value)
    return value



def enable_weak_uniform():
    sdf_major_version1 = sdf_major_version_res
    if sdf_major_version1 == "2.4" or sdf_major_version1 == "3.0":
        get_project_num_sql = "select count(1) as id3 from metadata.project_id_mapping where id_mapping_version = 'v3.0'"
    else:
        get_project_num_sql = "select count(1) as id3 from project_id_mapping where id_mapping_version = 'v3.0'"
    get_enable_weak_uniform = get_dl_conf(key="enable_weak_uniform")
    try:    
        get_project_num_sql_res = utils.sa_utils.SAMysql.query(get_project_num_sql)
        id3_count = get_project_num_sql_res[0]["id3"]
    except Exception:
        id3_count = 0

    if  id3_count > 0 and get_enable_weak_uniform == "false":
        return True
    return False


def check_small_files_info():
    if sdf_major_version_res == "3.0" or not sdf_major_version_res:
        return False
    else:
        get_small_files_info_sql = "select count(1) as small_files_cnt from metadata.sdf_data_loader_storage_health_level where health_level=4"
        get_small_files_info_sql_res = utils.sa_utils.SAMysql.query(get_small_files_info_sql)
        if get_small_files_info_sql_res[0]["small_files_cnt"] > 0:
            return True
        else:
            return False


def get_dl_loader_mode():
    loader_mode_value = get_dl_conf(key="loader_mode")
    loader_mode = "batch" if "batch" in loader_mode_value else "stream"
    return loader_mode


def get_enable_kc():
    enable_kc = get_dl_conf(key="enable_kafka_consumer",default_value=True)
    if enable_kc == "false":
        return False
    return enable_kc


def get_kudu_to_parquet_running_concurrent():
    k2p_concurrent = get_dl_conf(key="kudu_to_parquet_running_concurrent")
    return k2p_concurrent
 

def get_enable_chain():
    try:
        enable_chain = get_dl_conf(key="enable_chain",product="sdg",namespace="web",default_value=False)
        if enable_chain == "false":
            return False
    except Exception as e:
        return False
    return enable_chain

def get_skip_pre_set_group_sync():
    try:
        skip_pre_set_group_sync = get_dl_conf(key="get_skip_pre_set_group_sync",product="sps",namespace="web",default_value=False)
        if skip_pre_set_group_sync == "false":
            return False
    except Exception as e:
        return False
    return skip_pre_set_group_sync 


def get_one_mapper_config():
    one_mapper_config = get_dl_conf(key="one_mapper_read_event_kafka_partitions",default_value=False)
    return one_mapper_config


def get_event_avg_import_rate():
    expr = """sum(rate(data_flow_data_load_count{data_type="event"}[5m]))"""
    return get_avg_import_rate(expr=expr)


def get_profile_avg_import_rate():
    expr = """sum(rate(data_flow_data_load_count{data_type="profile"}[5m]))"""
    return get_avg_import_rate(expr=expr)

def get_project_count():
    # project 表，sp2.1 版本，历史的旧版本sca升级上去的就有project,最新的sca版本安装的可能就没有变成了 sbp_project
    get_project_num_sql = "select count(1) as count from metadata.project where status = 1"
    get_project_num_sql1 = "select count(1) as count from metadata.sbp_project where status = 1"
    try:
        get_project_num_sql_res = utils.sa_utils.SAMysql.query(get_project_num_sql)
    except Exception :
        get_project_num_sql_res = utils.sa_utils.SAMysql.query(get_project_num_sql1)
    project_count = get_project_num_sql_res[0]["count"]
    return project_count

def k2p_running_set():
    loader_mode = get_dl_loader_mode() 
    sdf_major_version1 = sdf_major_version_res
    optimizable_items_info = {}
    project_count = get_project_count()
    if loader_mode == "stream" and project_count >= 5 and get_kudu_to_parquet_running_concurrent() == "false" and sdf_major_version1 != "3.0":
        k2p_running_concurrent = 1
        if project_count >= 5 and project_count < 15:
            k2p_running_concurrent = 2
        elif project_count >= 15 and project_count < 30:
            k2p_running_concurrent = 5
        elif project_count >= 30 and project_count < 50:
            k2p_running_concurrent = 10
        else:
            k2p_running_concurrent = 4
        set_kudu_to_parquet_running_concurrent_cmd = "sbpadmin business_config -a set -p sdf -n data_loader  -k kudu_to_parquet_running_concurrent -v %s" %k2p_running_concurrent if is_ge_sp2_1_version() else "spadmin config set server -p sdf -m data_loader  -n kudu_to_parquet_running_concurrent -v %s" %k2p_running_concurrent
        optimizable_items_info["desc"]="客户项目个数：%s，stream 模式，建议添加优化参数：kudu_to_parquet_running_concurrent 默认无限制; 项目越多可适当调大，使用场景：客户资源少，数据量小，项目多（5+）的场景，同时跑 k2p 挤占 yarn 资源，导致导入异常版本： sdf 2.2.12786 / sdf 2.3.1.137" %(project_count)
        optimizable_items_info["cmd"]=f"{set_kudu_to_parquet_running_concurrent_cmd}"
        return optimizable_items_info
    else:
        return False
    

def optimizable_items():
    loader_mode = get_dl_loader_mode() 
    optimizable_items_info = {"Optimizable_items":{}}
    sdf_major_version1 = sdf_major_version_res
    k2p_running_set_res = k2p_running_set()
    if k2p_running_set_res:
        desc = k2p_running_set_res["desc"]
        cmd = k2p_running_set_res["cmd"]
        optimizable_items_info["Optimizable_items"]["ERROR_optimiz_k2p"]=f"{desc},{cmd}"

    if enable_weak_uniform():
        set_enable_weak_uniform_cmd = "sbpadmin business_config -a set -p sdf -n data_loader  -k enable_weak_uniform -v true" if is_ge_sp2_1_version() else "spadmin config set server -p sdf -m data_loader  -n enable_weak_uniform -v true"
        optimizable_items_info["Optimizable_items"]["ERROR_optimiz_id3"] = "环境开启了 id3 但是没配置 enable_weak_uniform，会导致用户属性不更新的问题，是个 bug，设置命令：%s ，并重启 dl，只对新数据有效！" %set_enable_weak_uniform_cmd
    event_avg_import_rate = get_event_avg_import_rate()
    profile_avg_import_rate = get_profile_avg_import_rate()
    if loader_mode == "stream" and not get_one_mapper_config() and not DeployInfo().get_simplified_cluster() and sdf_major_version1 != "3.0" and event_avg_import_rate and profile_avg_import_rate:
        if event_avg_import_rate < 5000 and profile_avg_import_rate < 1000:
            set_one_mapper_cmd = "sbpadmin business_config -a set -p sdf -n data_loader -k one_mapper_read_event_kafka_partitions -v 2 ; sbpadmin business_config -a set -p sdf -n data_loader -k one_mapper_read_profile_kafka_partitions -v 3" if is_ge_sp2_1_version() else "spadmin config set server -m data_loader -p sdf -n one_mapper_read_event_kafka_partitions -v 2 ; spadmin config set server -m data_loader -p sdf -n one_mapper_read_profile_kafka_partitions -v 3 "
            optimizable_items_info["Optimizable_items"]["ERROR_optimiz_one_mapper"] = "优化项：最近 7 天事件平均导入 qps：%s ，用户平均导入 qps：%s 数据量小，sdf 2.3.1+ 版本，可执行以下命令来节省 cpu、内存资源：%s 重启 dl 生效，要观察半个小时是否正常" %(event_avg_import_rate,profile_avg_import_rate,set_one_mapper_cmd)

    return optimizable_items_info


def is_upgrade_in_local():
    """
    针对 sdf 3.0 版本，判断是不是原地升级升上来的
    原地升级：表都在 metadata 库
    新部署的：表在 sdf_db 了
    """
    cmd = """ metadb_cli -uroot -e "show databases;" """
    res = False
    try:
        cmd_res = os.popen(cmd).readlines()
        for line in cmd_res:
            if "sdf_db" in line:
                res = True
    except Exception:
        res = False
    return res 



def dl_info():
    dl_info_data = {"Dataloader_info":{}}
    local_version =  get_sdf_full_version_res
    sdf_major_version1 = sdf_major_version_res
    if sdf_major_version1 == "3.0" or not sdf_major_version1:
        pass
    else:
        get_txn_num_sql = "select count(1) as txn_num from metadata.loader_txn_log where is_finished = 0"
        get_column_num_sql = "select count(1) as column_num from metadata.property_define where view_column_name is null"
        get_txn_num_sql_res = utils.sa_utils.SAMysql.query(get_txn_num_sql)
        get_column_num_sql_res = utils.sa_utils.SAMysql.query(get_column_num_sql)
        if get_txn_num_sql_res[0]["txn_num"] > 0:
            dl_info_data["Dataloader_info"]["ERROR Txn num"] = "未完成的事务操作数量：" + str(get_txn_num_sql_res[0]["txn_num"]) + "，查看方式：sa_mysql -e 'select id, start_time, operator_name, txn_desc, current_op_id from loader_txn_log where is_finished = 0;',pm worker 异常导致，可以看看 pm 的报错，或者 jstack 看看卡在哪里了"
        if get_column_num_sql_res[0]["column_num"] > 0:
            dl_info_data["Dataloader_info"]["ERROR Column num"] = "未完成的加列操作数量：" + str(get_column_num_sql_res[0]["column_num"]) + "，查看方式：sa_mysql -e 'select count(1) from property_define where view_column_name is null',pm worker 异常导致，可以看看 pm 的报错，若没有明显报错， jstack 看看卡哪里了"
    if KuduInfo().health_check():
        pass
    else:
        dl_info_data["Dataloader_info"]["ERROR Kudu"] = "Kudu 状态异常"
    kudu_tablets_balance_res = KuduInfo().check_kudu_tablets_balance()
    if  kudu_tablets_balance_res:
        dl_info_data["Dataloader_info"]["ERROR Kudu tablets status"] = "Kudu 数据不均衡，需按下方提示执行均衡命令"
        dl_info_data["Dataloader_info"]["Kudu_tablets_info"] = "%s" %(kudu_tablets_balance_res["Tablets_status"])
        dl_info_data["Dataloader_info"]["Kudu_tablets_balance_cmd"] = kudu_tablets_balance_res["Balance_cmd"]   
    kudu_res = KuduInfo().check_kudu_leader_balance()
    if  kudu_res:
        dl_info_data["Dataloader_info"]["ERROR Kudu status"] = "Kudu leader 不均衡，需按下方提示执行均衡命令"
        dl_info_data["Dataloader_info"]["Kudu_leader_info"] = "%s" %(kudu_res["Leader_status"])
        dl_info_data["Dataloader_info"]["Kudu_leader_cmd"] = kudu_res["Balance_cmd"]
    if check_small_files_info():
        dl_info_data["Dataloader_info"]["ERROR small files"] = "环境存在小文件问题，可按文档：https://doc.sensorsdata.cn/pages/viewpage.action?pageId=408691542 处理下"
    if check_hdfs_safe_mode():
        dl_info_data["Dataloader_info"]["ERROR Hdfs"] = "Hdfs 安全模式，请检查，sudo -u hdfs hdfs dfsadmin -report;查明为啥进入安全模式了，临时恢复：sudo -u hdfs hdfs dfsadmin -safemode leave；然后重启ex"
    dl_info_data["Dataloader_info"]["SDF version"] = local_version
    dl_info_data["Dataloader_info"]["Loader mode"] = get_dl_loader_mode()
    if is_sdf_bug_version():
        dl_info_data["Dataloader_info"]["SDF ERROR version"] = f"存在越删越多的 bug，推 sdf 小版本升级到最新即可"
    enable_kc = get_enable_kc()
    if not enable_kc:
        dl_info_data["Dataloader_info"]["ERROR enable_kafka_consumer"] = "环境该位置为：%s，会导致 kc 服务异常，无法启动，不导入，需改为 true，然后重启 dl" %enable_kc
    check_ntp_res = check_ntp()
    if get_enable_chain():
        dl_info_data["Dataloader_info"]["ERROR enable_chain"] = "注意！！！环境开启了干路化"
    if check_ntp_res:
        dl_info_data["Dataloader_info"]["ERROR ntp status"] = check_ntp_res["Ntp_ERROR"]
        dl_info_data["Dataloader_info"]["Ntp info"] = "%s" %(check_ntp_res["Ntp_status"])
    if show_total_session_info():
        dl_info_data["Dataloader_info"]["ERROR impala status"] = "有节点 session 连接数满了"
    if not check_nn_status():
        dl_info_data["Dataloader_info"]["ERROR nn status"] = "nn 状态异常，可能双备了！！！"
    if not check_kafka() and not DeployInfo().get_simplified_cluster():
        dl_info_data["Dataloader_info"]["ERROR Kafka status"] = "Kafka 状态异常，混部环境的话可忽略，查看状态：kafka-topics --zookeeper `cat ~/conf/sensors_data.property |grep zookeeper.connect|awk -F '=' '{print $NF}'` --topic event_topic --describe"
    if get_skip_pre_set_group_sync():
        dl_info_data["Dataloader_info"]["ERROR sps config"] = "注意！！！ sps 开启了 skip_pre_set_group_sync，每天会有离线任务将匿名事件里的 userid 补写会用户表中。可能会产生大量 profile 数据导致 profile 延迟，如有延迟联系导入同学优化，无法优化考虑跟客户沟通关闭该配置"
    get_yarn_apps_res = get_yarn_apps()
    if get_yarn_apps_res:
        dl_info_data.update(get_yarn_apps_res)
    return dl_info_data

if __name__ == '__main__':
    print(check_small_files_info())



