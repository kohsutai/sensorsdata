# encoding: utf-8

# @File    : check_services.py
# @Date    : 2024年09月20日15:20:51
# @Author  : liuxiaopeng
# @Desc:  操作 mysql 的结果 json 格式化

def get_mysql_res_to_json(res):
    # 获取列名
    rows = res.split('\n')
    column_names = rows[0].split('\t')

    # 将查询结果转换为JSON格式
    json_data = []
    for row in rows[1:]:
        if row:
            json_data.append(dict(zip(column_names, row.split('\t'))))

    # 输出JSON格式的查询结果
    return json_data