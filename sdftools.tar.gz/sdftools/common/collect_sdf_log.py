# encoding: utf-8
import datetime
import json
# @File    : collect_sdf_log.py
# @Date    : 2022年05月03日14:22:43
# @Author  : liuxiaopeng
# @Desc:

import os
import sys
import pathlib
import sys
from hyperion_client.deploy_topo import DeployTopo
from hyperion_client.hyperion_inner_client.inner_deploy_topo import InnerDeployTopo
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'common')))
from ssh_client import SSHClient
from get_mem_cpu_disk_info import disk_info
from sdf_utils import sdf_major_version
from date_tools import shuzi
# from collections import defaultdict


def env_check():
    if os.environ.get('USER') != "sa_cluster":
        exit("请在 sa_cluster 用户下执行")
    # 判断是不是 sdf 版本，不是 sdf 退出
    if os.environ.get('SENSORS_DATAFLOW_LOG_DIR'):
        pass
    else:
        exit("未安装 sdf 请检查，sp1.17 暂不支持！退出！")

    # 判断磁盘空间是否足够
    disk_path = "/tmp"
    if disk_info(disk_path):
        exit("剩余空间不足 1024M 或者使用空间大于 85% 退出！")


def collect():
    """

    :param stime: 开始时间点
    :param etime: 结束时间点
    :return: E.g {'master.log': (data01, master.log_20000101)}
    """
    env_check()
    sdf_major_version1 = sdf_major_version()
    # print(sdf_major_version1)
    if sdf_major_version1:
        if sdf_major_version1 == "3.0":
            hostnames = DeployTopo().get_host_list_by_module_name("sdf", "master")
        else:
            hostnames = InnerDeployTopo().get_host_list_by_role_name("sdf", "data_loader", "worker_maintenance")
    else:
        hostnames = DeployTopo().get_host_list_by_module_name("infinity", "master")
    # 获取 ssh 端口
    try:
        from hyperion_client.node_info import NodeInfo
        ssh_port = NodeInfo().get_node_ssh_port(hostname=hostnames[0])
    except Exception:
        ssh_port = 22

    # 获取 dl worker 运行的节点
    print("dl worker 运行的节点: %s" % hostnames)

    # 创建依赖目录
    sdf_log_path = "/tmp/sdflogs"
    sdf_worker_jstack_log_path = sdf_log_path + "/jstack"
    pathlib.Path(sdf_log_path).mkdir(parents=True, exist_ok=True)
    pathlib.Path(sdf_worker_jstack_log_path).mkdir(parents=True, exist_ok=True)

    collect_number_out = 50
    collect_number = 100000
    # dl 日志信息搜集
    if sdf_major_version1:
        dl_log_path = os.environ.get('SENSORS_DATAFLOW_LOG_DIR') + "/data_loader/"
    else:
        dl_log_path = os.environ.get('SENSORS_INFINITY_LOG_DIR')

    # if len(hostnames) < 2:
    # exit("单机不用拉日志，直接去 %s 查看" %(dl_log_path))
    # log_info={}
    if sdf_major_version1:
        if sdf_major_version1 == "2.4":
            dl_log_info = {"master.log": {"process_name": "MasterMain"}, "master.out": {}, "worker_kafka_consumer.out": {},
                        "worker_kafka_consumer.log": {"process_name": "KAFKA_CONSUMER"},
                        "worker_kudu_to_parquet.out": {},
                        "worker_kudu_to_parquet.log": {"process_name": "KUDU_TO_PARQUET"},
                        "worker_project_manager.out": {},
                        "worker_project_manager.log": {"process_name": "PROJECT_MANAGER"}, "worker_maintenance.out": {},
                        "worker_maintenance.log": {"process_name": "MAINTENANCE"}}
        elif sdf_major_version1 == "3.0":
            dl_log_info = {"master.log":{"process_name":"MasterDaemon"},"master.out": {},"worker.log":{"process_name":"WorkerDaemon"},"worker.out": {}}
        else:
            dl_log_info = {"master.log": {"process_name": "MasterMain"}, "master.out": {}, "kafka_consumer.out": {},
                        "worker_kafka_consumer.log": {"process_name": "KAFKA_CONSUMER"}, "kudu_to_parquet.out": {},
                        "worker_kudu_to_parquet.log": {"process_name": "KUDU_TO_PARQUET"}, "project_manager.out": {},
                        "worker_project_manager.log": {"process_name": "PROJECT_MANAGER"}, "maintenance.out": {},
                        "worker_maintenance.log": {"process_name": "MAINTENANCE"}}
    else:
        dl_log_info = {"master.log":{"process_name":"MasterDaemon"},"master.out": {},"worker.log":{"process_name":"WorkerDaemon"},"worker.out": {}}


    logtype2_host_and_logname = {}  # 映射关系。key为日志类型，value元组(日志所在的主机名，日志名称). E.g {'master.log': (data01, master.log_20000101)}

    # hostnames2files = defaultdict(list)  # 各主机名对应的日志、创建时间、最后修改时间

    # 若未指定开始时间，则直接取当前的日志。只获取各主机名对应的日志列表
    for dl_log in dl_log_info.keys():
        possible_dl_logs_and_last_modified_time_and_hostnames = []    # 可能存在多个节点上有相同的日志名，例如都有master.log。首先都取出，然后根据最后修改时间排序，取最新的日志文件
        if sdf_major_version1:
            if sdf_major_version1 == "3.0"  and (dl_log == "master.log" or dl_log =="master.out") :
                dl_log_path = os.environ.get('SENSORS_DATAFLOW_LOG_DIR') + "/master/"
            elif sdf_major_version1 == "3.0" and (dl_log == "worker.log" or dl_log =="worker.out"):
                dl_log_path = os.environ.get('SENSORS_DATAFLOW_LOG_DIR') + "/worker/"
        else:
            if dl_log == "master.log" or dl_log =="master.out":
                dl_log_path = os.environ.get('SENSORS_INFINITY_LOG_DIR') + "/master/"
            elif dl_log == "worker.log" or dl_log =="worker.out":
                dl_log_path = os.environ.get('SENSORS_INFINITY_LOG_DIR') + "/worker/"

        for hostname in hostnames:
            ssh_client = SSHClient(hostname=hostname, port=ssh_port)
            cmd = f"find {dl_log_path} -type f -name {dl_log}"
            res = ssh_client.run_cmd(cmd)
            if res["stdout"]:
                log_file = res["stdout"].strip("\r\n")
                cmd = f"stat -c '%Y' {log_file}"    # 获取最后修改时间戳。
                res = ssh_client.run_cmd(cmd)
                last_modified_time = res["stdout"].strip("\r\n")
                possible_dl_logs_and_last_modified_time_and_hostnames.append((log_file, last_modified_time, hostname))
        if len(possible_dl_logs_and_last_modified_time_and_hostnames) >= 1:
            # 存在多个节点上有相同的日志名
            # 根据最后修改时间取出最新的日志
            print(f"检测到集群存在多个{dl_log}日志，在这些节点上存在", [x[2] for x in possible_dl_logs_and_last_modified_time_and_hostnames])
            possible_dl_logs_and_last_modified_time_and_hostnames = sorted(possible_dl_logs_and_last_modified_time_and_hostnames, key=lambda x: x[1])
            target_dl_log_and_last_modified_time_and_hostname = possible_dl_logs_and_last_modified_time_and_hostnames[-1]
            logtype2_host_and_logname[target_dl_log_and_last_modified_time_and_hostname[0]]=(target_dl_log_and_last_modified_time_and_hostname[-1],target_dl_log_and_last_modified_time_and_hostname[1],target_dl_log_and_last_modified_time_and_hostname[0])
    # 需要拉取指定时间的日志
    logtype2_host_and_logname_without_abs_path = {}
    for log, host_and_logname in logtype2_host_and_logname.items():
        logtype2_host_and_logname_without_abs_path[log.split("/")[-1]] = [host_and_logname[0], host_and_logname[-1].split("/")[-1]]
    for hostname,log_file in logtype2_host_and_logname_without_abs_path.values():
        # worker_file = dl_log_path + dl_log
        if sdf_major_version1:
            if sdf_major_version1 == "3.0"  and (dl_log == "master.log" or dl_log =="master.out") :
                dl_log_path = os.environ.get('SENSORS_DATAFLOW_LOG_DIR') + "/master/"
            elif sdf_major_version1 == "3.0" and (dl_log == "worker.log" or dl_log =="worker.out"):
                dl_log_path = os.environ.get('SENSORS_DATAFLOW_LOG_DIR') + "/worker/"
        else:
            if dl_log == "master.log" or dl_log =="master.out":
                dl_log_path = os.environ.get('SENSORS_INFINITY_LOG_DIR') + "/master/"
            elif dl_log == "worker.log" or dl_log =="worker.out":
                dl_log_path = os.environ.get('SENSORS_INFINITY_LOG_DIR') + "/worker/"

        worker_file = dl_log_path + log_file
        if ".out" in log_file:
            real_collect_number = collect_number_out
        else:
            real_collect_number = collect_number
        print("%s 日志所在节点: %s，取最后 %s 条日志到本地 %s" % (log_file, hostname, real_collect_number, sdf_log_path))
        ssh_client = SSHClient(hostname=hostname, port=ssh_port)
        worker_cmd = "tail -%s %s >/tmp/%s" % (real_collect_number, worker_file, log_file)
        ssh_client.run_cmd(worker_cmd)

        # 将 worker 日志文件 scp 到本地
        scp_cmd = "scp -P %s %s:/tmp/%s %s " % (ssh_port, hostname, log_file, sdf_log_path)
        os.popen(scp_cmd).readlines()

    for dl_log in dl_log_info.keys():
        if dl_log not in logtype2_host_and_logname_without_abs_path:
            continue
        worker_host = logtype2_host_and_logname_without_abs_path.get(dl_log)[0]
        # 对 worker 进程进行 jstack ，并将生成的 jstack 日志拉到文档，方便排查问题
        if "process_name" in dl_log_info[dl_log].keys():
            process_name = dl_log_info[dl_log]["process_name"]
            process_time = shuzi()
            process_cmd = "pid=`jps -m |grep %s|head -1|awk '{print $1}'`;if [ -z $pid ];then pass;else jstack $pid >/tmp/jstack_%s_%s_%s_${pid}.log;echo jstack_%s_%s_%s_${pid}.log;fi" % (
            process_name, process_name, worker_host, process_time, process_name, worker_host, process_time)
            ssh_client = SSHClient(hostname=worker_host, port=ssh_port)
            res1 = ssh_client.run_cmd(process_cmd)
            process_file = res1["stdout"].strip()

            # 将 jstack 文件 scp 到本地
            scp_jstack_file_cmd = "scp -P %s %s:/tmp/%s %s " % (
            ssh_port, worker_host, process_file, sdf_worker_jstack_log_path)
            os.popen(scp_jstack_file_cmd).readlines()

        # log_info[dl_log]=max(file_info.keys())

    # return log_info
    return logtype2_host_and_logname