# encoding: utf-8

# @File    : all_kudu_info.py
# @Date    : 2023年07月13日09:46:05
# @Author  : liuxiaopeng
# @desc    : 获取 kudu 所有信息


import json
import logging
import os
import sys
import pathlib
import re
import subprocess
from prettytable import PrettyTable
from distutils.version import LooseVersion
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'common')))
from ssh_client import SSHClient
from get_mem_cpu_disk_info import disk_info
from date_tools import shuzi,year
from get_mem_cpu_disk_info import sys_info
from check_services import get_variance
from hyperion_client.config_manager import ConfigManager
from hyperion_client.deploy_info import DeployInfo
from hyperion_client.deploy_topo import DeployTopo


class ColorFormatter(logging.Formatter):
    BLACK, RED, GREEN, YELLOW, BLUE, MAGENTA, CYAN, WHITE = range(8)
    COLORS = {
        'WARNING': YELLOW,
        'INFO': GREEN,
        'DEBUG': BLUE,
        'CRITICAL': RED,
        'ERROR': RED
    }

    def __init__(self, msg):
        logging.Formatter.__init__(self, msg)


    def format(self, record):
        levelname = record.levelname
        if levelname in self.COLORS:
            bg = ''  #  background
            color = '1;%d' % (30 + self.COLORS[levelname])
            record.msg = '\033[%s%sm%s\033[0m' % (color, bg, record.msg)
        return logging.Formatter.format(self, record)


def get_logger(name):
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)
    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    formatter = ColorFormatter('[%(asctime)s] - %(levelname)s - %(message)s')
    ch.setFormatter(formatter)
    file_handler = logging.FileHandler('/tmp/redo_kudu.log')
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    logger.addHandler(ch)
    return logger

SOKU_TOOL_ROOT_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'soku_tool')
if SOKU_TOOL_ROOT_PATH not in sys.path:
    sys.path.append(SOKU_TOOL_ROOT_PATH)

class KuduInfo:        
    logger = get_logger(__name__)
    def __init__(self):
        self.is_ge_sp21 = self.is_ge_sp2_1_version()
        self.kudu_bin = "kudu" if self.is_ge_sp21 else "sp_kudu"
        self.master_addresses = self.get_kudu_master_addresses()
        self.ssh_port = self.get_hostname_ssh_port()
        self.tserver_addresses = self.get_kudu_tserver_addresses()
        self.tmp_kudu_log_path = "/tmp/kudulogs"
        self.kudu_version = self.get_kudu_version()

    def get_hostname_ssh_port(self):
        # 获取 ssh 端口
        try:
            from hyperion_client.node_info import NodeInfo
            ssh_port = NodeInfo().get_node_ssh_port(hostname=self.get_hostname())
        except Exception:
            ssh_port = 22
        return ssh_port



    def cmd_run(self,cmd):
        """
        没有使用 云平台提供的 run_cmd 场景不适用，重写个
        """
        p = subprocess.Popen([cmd], stdout=subprocess.PIPE, stderr=subprocess.PIPE,shell=True)
        stdout, _ = p.communicate()
        stdout = stdout.strip()
        if p.returncode != 0:
            self.logger.info("execute command:%s failed" % cmd)
            exit(1)
        stdout = stdout.decode("utf-8", "ignore")
        return stdout
    

    def get_sp_version(self):
        """
        获取 sp 版本，sp2.1 后 接口和命令都变了
        """
        sp_version = DeployTopo().get_product_major_version("sp")
        return sp_version


    def is_ge_sp2_1_version(self):
        if LooseVersion(self.get_sp_version()) >= LooseVersion("2.1.0"):
            return True


    def check_kudu_tablets_balance(self):
        try:
            kudu_info = {}
            cmd = """%s table list %s -list_tablets | grep :7050 | awk '{print $NF}'|sort |uniq -c|awk '{print $1}'""" %(self.kudu_bin,self.master_addresses)
            cmd1 = """kudu cluster rebalance %s""" %self.master_addresses
            res = os.popen(cmd).readlines()
            data_list = []
            for data in res:
                data_list.append(int(data.strip('\n')))
            if get_variance(data_list) > 400:
                kudu_info["Tablets_status"]=data_list
                kudu_info["Balance_cmd"]="kudu tablets 不均衡，可能影响查询或 k2p 速度，数据均衡命令（可能耗时很长）：%s" %cmd1
            return kudu_info
        except Exception as e:
            return False


    def check_kudu_leader_balance(self):
        try:
            kudu_info = {}
            cmd = """%s cluster ksck %s -ksck_format=plain_full  | grep LEADER | awk '{print$2}' | sort | uniq -c|awk '{print $1}'""" %(self.kudu_bin,self.master_addresses)
            res = os.popen(cmd).readlines()
            data_list = []
            for data in res:
                data_list.append(int(data.strip('\n')))
            if get_variance(data_list) > 400:
                kudu_info["code"]="200"
                kudu_info["Leader_status"]=data_list
                kudu_info["Balance_cmd"]="kudu 不均衡可能影响 k2p 速度，kudu 均衡命令：cd ../kudu && sh exec_leader.sh  等滚动信息出现后 ctrl + c ,会后台跑，均衡详情 tailf leader_balance.log"
            return kudu_info
        except Exception as e:
            return False

    def health_check(self):
        try:
            cmd = """%s cluster ksck %s|tail -1""" %(self.kudu_bin,self.master_addresses)
            # print(cmd)
            res = os.popen(cmd).readlines()
            if "OK" in res[0]:
                return True
            else:
                return False
        except Exception as e:
            error_msg = "Exception:{}".format(e)
            return False



    def ksck(self, master_addresses, table_filter):
        """
        kudu ksck 检查信息 
        """
        ksck_cmd = '%s cluster ksck %s -ksck_format=json_compact -sections=TABLET_SUMMARIES -tables=%s' \
            % (self.kudu_bin,master_addresses, table_filter)
        # 无法使用云平台的接口，因为含有特殊字符，云平台的接口解析不了
        stdout = self.cmd_run(cmd=ksck_cmd)
        return stdout
    


    def get_kudu_table_rf(self):
        """
        获取 kudu 所有表的 RF 检查副本数是否足够 >=3
        """
        get_kudu_tables_rf_cmd = '%s cluster ksck %s -sections=TABLE_SUMMARIES  -ksck_format=json_compact' %(self.kudu_bin,self.master_addresses)
        stdout = self.cmd_run(cmd=get_kudu_tables_rf_cmd)
        get_kudu_tables_rf_info = json.loads(stdout)
        return get_kudu_tables_rf_info["table_summaries"]



    def get_sp_version(self):
        """
        获取 sp 版本，sp2.1 后 接口和命令都变了
        """
        sp_version = DeployTopo().get_product_major_version("sp")
        return sp_version



    def get_kudu_master_addresses(self):
        """
        获取 kudu master 地址
        """
        if self.is_ge_sp21:
            get_kudu_master_addresses_cmd = "aradmin config get client -m kudu -p sp -n master_address -w literal"
            kudu_master_addresses = self.cmd_run(cmd=get_kudu_master_addresses_cmd)
            return kudu_master_addresses
        else:
            kudu_master_addresses = ConfigManager().get_client_conf("sp", "kudu")['master_address']
            return kudu_master_addresses


    def get_kudu_tserver_addresses(self):
        """
        获取 kudu tserver 地址
        """
        get_kudu_tserver_addresses_cmd = "%s tserver list %s --format=json" %(self.kudu_bin,self.master_addresses)
        kudu_tserver_addresses_info = json.loads(self.cmd_run(cmd=get_kudu_tserver_addresses_cmd))
        kudu_tserver_addresses_list = []
        for kudu_tserver_address in kudu_tserver_addresses_info:
            kudu_tserver_addresses_list.append(kudu_tserver_address["rpc-addresses"])
        return list(set(kudu_tserver_addresses_list))



    def get_kudu_version(self):
        """
        获取 kudu 版本信息
        """
        get_kudu_version_cmd = "%s -version|grep kudu" %(self.kudu_bin)
        kudu_version = self.cmd_run(cmd=get_kudu_version_cmd).split(' ')[1]
        return kudu_version
    
    
    def get_hostname(self):
        """
        获取本机 hostname -f 
        """
        get_hostname_cmd = "hostname -f"
        hostname = self.cmd_run(cmd=get_hostname_cmd)
        return hostname


    def is_ms_or_cdh(self):
        """
        判断下是 mothership 还是 cdh
        """
        ms_or_cdh = "mothership2" if self.is_ge_sp21 else DeployInfo().get_hadoop_distribution()
        return ms_or_cdh


    def get_kudu_tables(self):
        get_kudu_tables_cmd = "%s table list %s" %(self.kudu_bin,self.master_addresses)
        get_kudu_tables_cmd_res = self.cmd_run(get_kudu_tables_cmd)
        return get_kudu_tables_cmd_res.split('\n')


    def convert_to_byte_unit(self,num):
        units = ['B', 'KB', 'MB', 'GB', 'TB']
        unit_index = 0
        while num >= 1024 and unit_index < len(units) - 1:
            num /= 1024
            unit_index += 1
        return f'{num:.2f} {units[unit_index]}'


    def get_kudu_table_size_and_row_count(self,tablename):
        get_kudu_table_size_cmd = "%s table statistics %s %s" %(self.kudu_bin,self.master_addresses,tablename)
        get_kudu_table_size_cmd_res = self.cmd_run(get_kudu_table_size_cmd)
        kudu_table_size_and_row_count_info = {}
        for kudu_table_info in get_kudu_table_size_cmd_res.split('\n'):
            if ":" in kudu_table_info:
                kudu_table_info_list = kudu_table_info.split(':')
                if "on disk size" in kudu_table_info_list:
                    kudu_table_size_and_row_count_info["table size"]=self.convert_to_byte_unit(int(kudu_table_info_list[1]))
                else:
                    kudu_table_size_and_row_count_info["rows"]=kudu_table_info_list[1]
        return kudu_table_size_and_row_count_info
    

    def get_kudu_table_height(self,tablename):
        get_kudu_table_height_tablet_hosts_cmd = "%s cluster ksck %s -ksck_format=plain_full -tables=%s|grep RUNNING|awk '{print $2}'|awk -F ['(:'] '{print $2}'|sort -rn |uniq|sort -rn" %(self.kudu_bin,self.master_addresses,tablename)
        get_kudu_table_height_tablet_hosts_cmd_res = self.cmd_run(get_kudu_table_height_tablet_hosts_cmd).split('\n')
        height_list = []            
        for hostname in get_kudu_table_height_tablet_hosts_cmd_res:
            get_kudu_table_height_cmd = """ curl 'http://%s:8050/metrics?metrics=average_diskrowset_height&attributes=table_name,%s&merge_rules=tablet|table|table_name' """ %(hostname,tablename)
            get_kudu_table_height_cmd_res = json.loads(self.cmd_run(get_kudu_table_height_cmd))
            for height_info in get_kudu_table_height_cmd_res:
                if height_info["id"] == tablename:
                    height = int(height_info["metrics"][0]["value"])
                    height_list.append(height)
        return max(height_list)
    


    def get_kudu_table_column_count(self,tablename):
        get_kudu_table_column_count_cmd = "%s table describe %s %s|egrep -v 'TABLE|HASH|RANGE|PARTITION|PRIMARY|REPLICAS|OWNER|\)'|wc -l" %(self.kudu_bin,self.master_addresses,tablename)
        get_kudu_table_column_count_cmd_res = self.cmd_run(get_kudu_table_column_count_cmd)
        return get_kudu_table_column_count_cmd_res
    
    

    def get_kudu_tserver_memory(self,tserver_address):
        web_port = 8050 if "7050" in tserver_address else 8070
        hostname = tserver_address.split(':')[0]
        get_kudu_tserver_memory_cmd = "curl http://%s:%s/varz -s|grep memory_limit_hard_bytes" %(hostname,web_port)
        get_kudu_tserver_memory_cmd_res = int(self.cmd_run(get_kudu_tserver_memory_cmd).split('=')[1])
        # print(get_kudu_tserver_memory_cmd_res,type(get_kudu_tserver_memory_cmd_res))
        return self.convert_to_byte_unit(num=get_kudu_tserver_memory_cmd_res)
    


    def get_kudu_tserver_maintenance_threads(self,tserver_address):
        web_port = 8050 if "7050" in tserver_address else 8070
        hostname = tserver_address.split(':')[0]
        get_kudu_tserver_maintenance_threads_cmd = "curl http://%s:%s/varz -s|grep maintenance_manager_num_threads" %(hostname,web_port)
        get_kudu_tserver_maintenance_threads_cmd_res = self.cmd_run(get_kudu_tserver_maintenance_threads_cmd).split('=')[1]
        return get_kudu_tserver_maintenance_threads_cmd_res
    


    def get_kudu_tserver_estimat_size(self,tserver_address):
        get_kudu_tserver_estimat_size_cmd = "%s remote_replica list %s | grep Estimat | sed 's/Estimated on disk size: //g'  | sed 's/M/*1024/' | sed 's/G/*1024*1024/' | sed 's/K//' | xargs | sed -e 's/\ /+/g' | bc | xargs -i echo {}/1024 | bc | xargs -i echo {}/1024 | bc |xargs -i echo {}G" %(self.kudu_bin,tserver_address)
        get_kudu_tserver_estimat_size_cmd_res = self.cmd_run(get_kudu_tserver_estimat_size_cmd)
        return get_kudu_tserver_estimat_size_cmd_res
    

    def get_kudu_tserver_disk_size(self,tserver_address):
        web_port = 8050 if "7050" in tserver_address else 8070
        hostname = tserver_address.split(':')[0]
        ssh_client = SSHClient(hostname=hostname,port=self.ssh_port)
        get_kudu_tserver_disk_size_cmd = """ disk_size=0;for fs_data_dir in $(curl %s:%s/varz 2>/dev/null | grep fs_data_dirs= | sed 's/.*=//' | tr ,  '\n');do disk_size=$[${disk_size}+$(sudo du -s ${fs_data_dir} | awk '{print $1}')];done;echo "${disk_size}" """%(hostname,web_port)
        get_kudu_tserver_disk_size_cmd_res = ssh_client.run_cmd(get_kudu_tserver_disk_size_cmd)

        return self.convert_to_byte_unit(num=int(get_kudu_tserver_disk_size_cmd_res["stdout"].strip())*1024)
    

    def get_kudu_tserver_tablets(self):
        get_kudu_tserver_tablets_cmd = """ %s cluster ksck %s -sections=TABLET_SUMMARIES  -ksck_format=plain_full|grep RUNNING|awk '{print $2}'|awk -F [' ()'] '{print $2 $4}'|sort -rn|uniq -c|awk '{print "{\\\""$2"\\\":"$1"}"}' """%(self.kudu_bin,self.master_addresses)
        # print(get_kudu_tserver_tablets_cmd)
        get_kudu_tserver_tablets_cmd_res = self.cmd_run(get_kudu_tserver_tablets_cmd).split('\n')
        # for line in get_kudu_tserver_tablets_cmd_res:
            # print(line,type(line))
            # print(eval(line)["hybrid03.classic-tx-beijing-01.sensors-training.deploy.sensorsdata.cloud:7070"])
        return get_kudu_tserver_tablets_cmd_res
    

    def get_kudu_tserver_leaders_and_scanners(self):
        get_kudu_tserver_leaders_and_scanners_cmd = "%s cluster ksck %s -sections=TSERVER_SUMMARIES --ksck_format=plain_full" %(self.kudu_bin,self.master_addresses)
        get_kudu_tserver_leaders_and_scanners_cmd_res = self.cmd_run(get_kudu_tserver_leaders_and_scanners_cmd)
        # 提取需要的数据
        lines = get_kudu_tserver_leaders_and_scanners_cmd_res.strip().split('\n')
        extracted_data = []

        for line in lines:
            # 使用正则表达式提取数据
            match = re.match(r'\s*(\w+)\s+\|\s+(.+)\s+\|\s+(\w+)\s+\|\s+(.+?)\s+\|\s+(\d+)\s+\|\s+(\d+)\s*', line)
            if match:
                row = {
                    'UUID': match.group(1),
                    'Address': match.group(2),
                    'Status': match.group(3),
                    'Location': match.group(4),
                    'Tablet Leaders': int(match.group(5)),
                    'Active Scanners': int(match.group(6))
                }
                extracted_data.append(row)
        # print(extracted_data)
        return extracted_data


    def get_kudu_table_rf_and_tablets(self):
        get_kudu_table_rf_and_tablets_cmd = "%s cluster ksck %s -sections=TABLE_SUMMARIES" %(self.kudu_bin,self.master_addresses)
        get_kudu_table_rf_and_tablets_cmd_res = self.cmd_run(get_kudu_table_rf_and_tablets_cmd)
        # 提前需要的数据
        lines = get_kudu_table_rf_and_tablets_cmd_res.split('\n')
        extracted_data = []
        for line in lines:
            # 使用正则表达式提取数据
            match = re.match(r'\s*(\w+)\s+\|\s+(\d+)\s+\|\s+(\w+)\s+\|\s+(\d+)\s+\|\s+(\d+)\s+\|\s+(\d+)\s+\|\s+(\d+)\s+\|\s+(\d+)\s*', line)
            if match:
                row = {
                    'tablename': match.group(1),
                    'rf': int(match.group(2)),
                    'status': match.group(3),
                    'tablets': int(match.group(4)),
                    'healthy': int(match.group(5)),
                    'recovering': int(match.group(6)),
                    'under_relicated': int(match.group(7)),
                    'unavailable': int(match.group(8))
                }
                extracted_data.append(row)
        # print(extracted_data)
        return extracted_data
        

    def get_kudu_tables_info(self):
        self.logger.info("Kudu version：%s" %self.kudu_version)

        if self.health_check():
            self.logger.info("Kudu cluster is OK! ")

            data = []
            tables_data = self.get_kudu_table_rf_and_tablets()
            for table_data in tables_data:
                tablename = table_data["tablename"]
                table_size_and_rows = self.get_kudu_table_size_and_row_count(tablename=tablename)
                table_size = table_size_and_rows["table size"]
                rows = table_size_and_rows["rows"]
                height = self.get_kudu_table_height(tablename=tablename)
                columns = self.get_kudu_table_column_count(tablename=tablename)
                tablets = table_data["tablets"]
                rf = table_data["rf"]
                data.append([tablename,table_size,rows,height,columns,tablets,rf])
            # print(data)
            table = PrettyTable(["table name","table size","rows","height","columns","tablets","rf"])
            table.align = 'l'
            for row in data:
                table.add_row(row)
            self.logger.info("表级别\n%s" %table)
            return table


    def get_kudu_tserver_info(self):
        tserver_addresses = self.tserver_addresses
        kudu_tserver_tablets = self.get_kudu_tserver_tablets()
        kudu_tserver_leaders_and_scanners = self.get_kudu_tserver_leaders_and_scanners()
        data = []
        for tserver_address in tserver_addresses:
            memory = self.get_kudu_tserver_memory(tserver_address=tserver_address)
            maintenance = self.get_kudu_tserver_maintenance_threads(tserver_address=tserver_address)
            estimat = self.get_kudu_tserver_estimat_size(tserver_address=tserver_address)
            disk_size = self.get_kudu_tserver_disk_size(tserver_address=tserver_address)
            tablets = 0
            for line in kudu_tserver_tablets:
                if tserver_address in line:
                    tablets = eval(line)[tserver_address]
            leaders = 0
            scanner = 0
            for line1 in kudu_tserver_leaders_and_scanners:
                if line1["Address"] == tserver_address:
                    leaders = line1["Tablet Leaders"]
                    scanner = line1["Active Scanners"]
            data.append([tserver_address,memory,maintenance,estimat,disk_size,tablets,leaders,scanner])
        # print(data)
        table = PrettyTable(["tserver","memory","maintenance","estimat size","disk size","tablets","leaders","scanner"])
        table.align = 'l'
        for row in data:
            table.add_row(row)
        self.logger.info("节点级别\n%s"%table)
        return table 
    

    def collect_kudu_log(self,hostname,count=2000):
        # 创建依赖目录
        tmp_kudu_log_path = self.tmp_kudu_log_path
        # 创建依赖目录
        web_port = 8051 if "7051" in hostname else 8050
        info_log_name = "kudu-master.INFO" if "7051" in hostname else "kudu-tserver.INFO"
        warn_log_name = "kudu-master.WARNING" if "7051" in hostname else "kudu-tserver.WARNING"
        error_log_name = "kudu-master.ERROR" if "7051" in hostname else "kudu-tserver.ERROR"
        log_name_list = [info_log_name,warn_log_name,error_log_name]

        host = hostname.split(':')[0]
        log_path_cmd = "curl -s %s:%s/varz|grep log_dir" %(host,web_port)
        log_path = self.cmd_run(log_path_cmd).split('=')[1]
        tmp_log_path = tmp_kudu_log_path + "/%s" %host
        pathlib.Path(tmp_log_path).mkdir(parents=True, exist_ok=True)
        ssh_client = SSHClient(hostname=host,port=self.ssh_port)
        for log_name in log_name_list:
            get_log_ssh_cmd = "sudo tail -%s %s/%s >/tmp/%s" %(count,log_path,log_name,log_name)
            res = ssh_client.run_cmd(get_log_ssh_cmd)
            scp_cmd = "scp -P %s %s:/tmp/%s %s " %(self.ssh_port,host,log_name,tmp_log_path)
            self.logger.info("拉取 %s 主机的日志 %s/%s 最后 %s 条日志到本地 %s" %(host,log_path,log_name,count,tmp_log_path))
            os.popen(scp_cmd).readlines()


    def error_info_count(self,error_info_key, log_file_path):
        cmd = '''fgrep -- """%s""" %s |wc -l''' %(error_info_key,log_file_path)
        # print(cmd)
        line_count = os.popen(cmd).readlines()[0]
        return int(line_count)

    def error_info_start_time(self,error_info_key,log_file_path):
        with open(log_file_path,'r') as f:
            error_info = {}
            for line in f.readlines():
                if error_info_key in line:
                    pattern = r"\d{4} \d{2}:\d{2}:\d{2}"
                    match = re.search(pattern,line)
                    if match:
                        error_start_time = match.group()
                        start_time =  re.sub(r'(\d{4})(\d{2})(\d{2})', r'\1-\2-\3',year() + error_start_time.split(' ')[0] ) + " " + error_start_time.split(' ')[1]
                        error_info["start_time"] = start_time
                        error_info["line"] = line
                        return error_info
                    
    def tserver_addresses_count(self):
        tserver_addresses = self.tserver_addresses
        ts_count = 0
        for tserver_address in tserver_addresses:
            if "7050" in tserver_address:
                ts_count +=1
        return ts_count
        

    def op_check_kudu(self,count):
        if os.environ.get('USER') != "sa_cluster":
            exit("请在 sa_cluster 用户下执行")
        # 判断磁盘空间是否足够
        disk_path = "/tmp"
        if  disk_info(disk_path):
            exit("剩余空间不足 1024M 或者使用空间大于 85% 退出！")

        total_info = {}
        total_info.update(sys_info())

        # kudu 日志信息搜集
        master_addresses = self.master_addresses
        tserver_addresses = self.tserver_addresses
        # print(master_addresses,tserver_addresses)

        if "," in master_addresses:
            master_addresses_list = master_addresses.split(',')
            for master_address in master_addresses.split(','):
                self.collect_kudu_log(hostname=master_address,count=count)
        else:
            master_addresses_list = [master_addresses]
            master_address = master_addresses
            self.collect_kudu_log(hostname=master_address,count=count)
        tserver_address_list = []
        for tserver_address in tserver_addresses:
            if "7050" in tserver_address:
                tserver_address_list.append(tserver_address)
                self.collect_kudu_log(hostname=tserver_address,count=count)

        # 加载 dl 知识库
        self.logger.info("加载 kudu 知识库")
        f = open('kudu.json','r')
        data = json.load(f)
        keys = data["kudu"].keys()


        self.logger.info("解析日志数据")
        filename_info = {"master":"master.log","tserver":"tserver.log"}
        for filename_key in filename_info.keys():

            addresses = master_addresses_list if filename_key == "master" else tserver_address_list
            index_key_name = "Master Problems" if filename_key == "master" else "Tserver Problems"
            log_name = filename_info["master"] if filename_key == "master" else filename_info["tserver"]
            
            index_info2 = {index_key_name:{}}
            for address in addresses:
                address_hostname = address.split(':')[0]
                gen_log_file_cmd1 = f"cat {self.tmp_kudu_log_path}/{address_hostname}/kudu-master* >{self.tmp_kudu_log_path}/{address_hostname}/master.log"
                gen_log_file_cmd2 = f"cat {self.tmp_kudu_log_path}/{address_hostname}/kudu-tserver* >{self.tmp_kudu_log_path}/{address_hostname}/tserver.log"
                os.popen(gen_log_file_cmd1).readlines()
                os.popen(gen_log_file_cmd2).readlines()
                log_file_path = self.tmp_kudu_log_path + "/%s/%s" %(address_hostname,log_name)
                index_info = {address_hostname:{log_name:{}}}
                index_count = 0
                for key in keys:
                    error_msgs_count = self.error_info_count(error_info_key=key,log_file_path=log_file_path)
                    error_info_res = self.error_info_start_time(error_info_key=key,log_file_path=log_file_path)
                    if  error_msgs_count > 0:
                        index_count += 1
                        index_info1 = {index_count:{}}
                        index_info1[index_count]["ERROR"] = key
                        index_info1[index_count]["solution"] = data["kudu"][key]
                        index_info1[index_count]["occurrence number"] = error_msgs_count
                        index_info1[index_count]["start time"] = error_info_res["start_time"]
                        index_info1[index_count]["line_info"] = error_info_res["line"]
                        index_info[address_hostname][log_name][index_count] = index_info1[index_count]
                        index_info2[index_key_name][address_hostname] = index_info[address_hostname]
                        total_info.update(index_info2)


        msg_log = json.dumps(total_info)
        file_name = "/tmp/kudulogs/op_check_kudu_" + shuzi() + ".log"
        dl_detail_info = json.dumps(json.loads(msg_log), indent=4,ensure_ascii=False)
        color_dl_detail_info = '\033[1;36;40m%s\033[0m' %dl_detail_info
        self.logger.info("Kudu version：%s" %self.kudu_version)
        self.logger.info("日志级别")
        with open(file_name,'w') as file1:
            file1.write(color_dl_detail_info)
        with open(file_name,'r') as file2:
            for line in file2.readlines():
                if "ERROR" in line or "failed_count" in line:
                    line = '\033[31;1m%s\033[0m' %line.strip('\n')
                elif "可选项" in line:
                    line = '\033[33;1m%s\033[0m' %line.strip('\n')
                else:
                    line = '\033[36;1m%s\033[0m' %line.strip('\n')
                print(line)


# print(KuduInfo().get_html())
# KuduInfo().get_kudu_tables()
# KuduInfo().get_kudu_tserver_tablets()
# print(KuduInfo().get_kudu_tserver_leaders_and_scanners())
# KuduInfo().get_kudu_table_rf_and_tablets()
# KuduInfo().get_kudu_tables_info()
# KuduInfo().get_kudu_tserver_info()

# KuduInfo().collect_kudu_master_and_tserver_logs()

# KuduInfo().collect_kudu_master_and_tserver_logs()

# KuduInfo().op_check_kudu()