# encoding: utf-8

# @File    : sdf_utils.py
# @Date    : 2024年10月01日11:03:28
# @Author  : liuxiaopeng
# @Desc:  dl 相关信息
from hyperion_client.deploy_topo import DeployTopo
from distutils.version import LooseVersion
import utils.product_major_dependency


def sa_major_version():
    sa_major_version =DeployTopo().get_product_major_version("sa")
    return sa_major_version

def is_ge301_version():
    if LooseVersion(sa_major_version()) >=LooseVersion("3.0.1"):
        return True
    else:
        return False

def sdf_major_version():
    if not is_ge301_version():
        sdf_major_version = DeployTopo().get_product_major_version("sdf")[:3]
        return sdf_major_version
    else:
        return False
    
def get_sdf_full_version():
    if not is_ge301_version():
        sdf_major_version_res = sdf_major_version()
        if sdf_major_version_res == "2.4" or  sdf_major_version_res == "3.0":
            sdf_full_version = DeployTopo().get_product_full_version("sdf")
        else:
            sdf_full_version = utils.product_major_dependency.get_full_version("sdf")
        return sdf_full_version
    else:
        return False