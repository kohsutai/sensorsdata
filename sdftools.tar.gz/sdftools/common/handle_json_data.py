# encoding: utf-8

# @File    : handle_json_data.py
# @Date    : 2023年11月30日10:09:19
# @Author  : liuxiaopeng
# @Desc:  处理 json 数据

import json

def DeleteTheKeyForTheSpecifiedValue(data):
    """
    删除字典内指定字符串的key
    使用场景：只要包含"可选项"，删除对应的父key，减少输出
    """ 
    del_list=[]
    for k,v in data.items():
        for k1,v1 in v.items():
            if "可选项" in str(v1):
                t = (k,k1)
                del_list.append(t)
    for keys in del_list:
        del data[keys[0]][keys[1]]
    return data

def PrintToScreen(file_name,tmp_file_name,tmp_file_detail_name,file_detail_name,msg_log,total_info,simple_or_detail):
    dl_detail_info = json.dumps(json.loads(msg_log), indent=4,ensure_ascii=False)
    dl_skiped_info = json.dumps(DeleteTheKeyForTheSpecifiedValue(total_info),indent=4,ensure_ascii=False)
    color_dl_detail_info = '\033[1;36;40m%s\033[0m' %dl_detail_info
    color_dl_skiped_info = '\033[1;36;40m%s\033[0m' %dl_skiped_info

    with open(tmp_file_detail_name,'w') as file1:
        file1.write(color_dl_detail_info)
    with open(tmp_file_name,'w') as file2:
        file2.write(color_dl_skiped_info)
    with open(tmp_file_detail_name,'r') as file3:
        with open(file_detail_name,'w') as file4:
            for line in file3.readlines():
                if "ERROR" in line or "failed_count" in line:
                    line = '\033[31;1m%s\033[0m' %line
                elif "可选项" in line:
                    line = '\033[33;1m%s\033[0m' %line
                else:
                    line = '\033[36;1m%s\033[0m' %line
                file4.write(line)
    with open(tmp_file_name,'r') as file5:
        with open(file_name,'w') as file6:
            for line in file5.readlines():
                if "ERROR" in line or "failed_count" in line:
                    line = '\033[31;1m%s\033[0m' %line
                else:
                    line = '\033[36;1m%s\033[0m' %line
                file6.write(line)
    if simple_or_detail:
        with open(file_name,'r') as file7:
            for line in file7.readlines():
                print(line.strip('\n'))
    else:
        with open(file_detail_name,'r') as file8:
            for line in file8.readlines():
                print(line.strip('\n'))


