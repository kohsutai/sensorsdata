# encoding: utf-8

# @File    : xxxx.py
# @Date    : 2022年05月29日22:22:39
# @Author  : liuxiaopeng@sensorsdata.cn
# @Desc:

import os
import time
from hyperion_client.hyperion_inner_client.inner_deploy_topo import InnerDeployTopo
from ssh_client import SSHClient

def all_hosts_exec_cmd(cmd):
    hostnames_all = InnerDeployTopo().get_host_list()
    # 获取 ssh 端口
    try:
        from hyperion_client.node_info import NodeInfo
        ssh_port = NodeInfo().get_node_ssh_port(hostname=hostnames_all[0])
    except Exception:
        ssh_port = 22
    
    for host in hostnames_all:
        try:
            ssh_client1 = SSHClient(hostname=host,port=ssh_port)
            res1 = ssh_client1.run_cmd(cmd)
            cmd_res1 = res1["stdout"].strip()
            if cmd_res1 != "0":
                return cmd_res1
                break
        except Exception:
            cmd_res1 = False            

def all_hosts_exec_cmd_res_list(cmd):
    hostnames_all = InnerDeployTopo().get_host_list()
    tmp_list = []
    # 获取 ssh 端口
    try:
        from hyperion_client.node_info import NodeInfo
        ssh_port = NodeInfo().get_node_ssh_port(hostname=hostnames_all[0])
    except Exception:
        ssh_port = 22
    
    for host in hostnames_all:
        try:
            ssh_client1 = SSHClient(hostname=host,port=ssh_port)
            res1 = ssh_client1.run_cmd(cmd)
            # print(res1)
            cmd_res1 = int(res1["stdout"].strip())
            # print(cmd_res1)
            tmp_list.append(cmd_res1)
        except Exception:
            cmd_res1 = False   
    return tmp_list
def sys_info():
    cpu_count = os.cpu_count()
    (d1,d2,d3)=os.getloadavg()
    mem_info = os.popen("free -m").readlines()
    mem_info_total = int(mem_info[1].split()[1])
    mem_info_available = int(mem_info[1].split()[6])
    sys_info = {"Sys_info":{}}
    sys_info["Sys_info"]["cpu_count"] = cpu_count
    sys_info["Sys_info"]["loadavg"] = "5min:%s, 10min:%s, 15min:%s" %(d1,d2,d3)
    sys_info["Sys_info"]["mem_info_total"] = mem_info_total
    sys_info["Sys_info"]["mem_info_available"] = mem_info_available
    cmd_ps_batch_importer='''pid1=`ps aux --sort=start_time|grep batchimporter.ImporterMain|grep -v grep|head -1|awk '{print $2}'`;if [ -z $pid1 ];then echo 0;else date -d "`ps -eo lstart,pid,cmd |grep -w $pid1|grep -v grep|head -1|awk '{print $1,$2,$3,$4,$5}'`" "+%s";fi'''
    res = all_hosts_exec_cmd(cmd=cmd_ps_batch_importer)
    if res:
        today_id = int(time.time()/3600/24)
        ps_day_id = int(int(res)/3600/24)
        if today_id - ps_day_id >=1:
            sys_info["Sys_info"]["batch_importer_ERROR"] = "集群存在启动时间是一天前的 batch_importer 任务，怀疑是 bug ，2.2.12826/2.3.1.157/2.4.0.3891 已经修复,每个节点检查确认下，任务会导致长期占用系统内存最后引发系统 oom，每个节点检查下：%s" %cmd_ps_batch_importer

    # 判断每个节点是否存磁盘使用率 >= 90% 的情况，有的话直接提示执行王庆的脚本
    used_percent = 90
    worker_cmd1 = """df -h|awk 'NR>1{if(int($5)>%s){print $1" "$6" used "$5""} else {print 0}}'|grep -v ^0|head -1""" %(used_percent)
    res_disk_info=all_hosts_exec_cmd(cmd=worker_cmd1)
    if res_disk_info:
        sys_info["Sys_info"]["disk_used_ERROR"] = "集群存在节点磁盘使用率超过 90% 的情况，详细信息执行脚本: cd ../tools && python3 aiopDisk.py -r 90"
    return sys_info


def disk_info(path):
    vfs = os.statvfs(path)
    free_size = int(vfs.f_bsize * vfs.f_bavail / 1024 / 1024)
    used = vfs.f_bsize * (vfs.f_blocks - vfs.f_bfree) / 1024
    avail = vfs.f_bsize * vfs.f_bavail / 1024
    used_percent = round(float(used) / float(used + avail) * 100, 2)
    if free_size < 2048 or used_percent <= 90:
        return False
    else:
        return True

def ntp_info():
    ntp_check_cmd = "date +%s"
    res = all_hosts_exec_cmd_res_list(cmd=ntp_check_cmd)
    if len(res) > 0:
        return res
    else:
        return False



