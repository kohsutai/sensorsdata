# encoding: utf-8

# @File    : generate_knowledge.py
# @Date    : 2023年12月24日20:07:32
# @Author  : liuxiaopeng
# @Desc:  根据 cf 知识库生成 json 文件

import os
import requests
import json
from bs4 import BeautifulSoup
import subprocess


# 知识库 json 样式
extractor_knowledge_data={
    "extractor":{}
}

data_loader_knowledge_data={
    "data_loader":{}
}

# 生成知识库 json 文件后存放位置
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
extractor_knowledge_path = BASE_DIR + "/../extractor/extractor.json"
dl_knowledge_path = BASE_DIR + "/../data_loader/data_loader.json"
# 知识库地址
extractor_knowledge_doc_url = "https://doc.sensorsdata.cn/rest/api/content/458724485?expand=body.view"
data_loader_knowledge_doc_url = "https://doc.sensorsdata.cn/rest/api/content/458724427?expand=body.view"
# 知识库标识
ex_filter_string = "【EXTRACTOR】"
dl_filter_string = "【DATA_LOADER】"

def send_to_robot(result):
    curl_command = [
        'curl',
        'https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=9f30ce11-8f9d-416c-a710-0e31670e9580',
        '-H', 'Content-Type: application/json',
        '-d', '{"msgtype": "text", "text": {"content": "%s"}' % result
    ]

    subprocess.run(curl_command)


def GenerateKnowledge(url,filter_string,knowledge_data_json,file_path):

    """
    url: cf 文档地址，类似：https://doc.sensorsdata.cn/rest/api/content/458724485?expand=body.view，只替换 id 即可
    filter_string:【EXTRACTOR】知识库标题里的标记
    knowledge_data_json: 知识库格式
    file_path: 知识库保存路径

    """
    # 仅针对 sdftools 知识库
    for key_name in knowledge_data_json.keys():
        key_name1 = key_name
        

    # 设置Confluence API的基本URL和API Token
        
    api_token = 'MjY0NTc4MjIxNTExOiD8kf+EpNzqLGWmH8rIxQWNCwYB'    

    # 构建HTTP请求头部信息
    headers = {
        'Accept': 'application/json',
        'Authorization': f'Bearer {api_token}'
    }

    # 发送GET请求，获取用户信息
    response = requests.get(url, headers=headers)

    # 解析响应JSON数据
    res_info = response.text
    # print(res_info)
    soup = BeautifulSoup(res_info,'html.parser')
    for item in soup.find_all('h2'):
        # print(item)
        if filter_string in item:
            knowledge_data = {}
            for itme1 in item.next_sibling.contents:
                tmp_line = itme1.text
                # print(tmp_line)
                if "知识库录入：" in tmp_line:
                    key = itme1.text.split('知识库录入：')[1]
                    knowledge_data["key"]=key
                elif "问题原因：" in tmp_line:
                    reason = itme1.text.split('问题原因：')[1].replace('"', '')
                    knowledge_data["reason"]=reason
                elif "解决方法：" in tmp_line:
                    solution = itme1.text.split('解决方法：')[1].replace('"', '')
                    knowledge_data["solution"]=solution
            knowledge_data_json[key_name1][knowledge_data["key"]]=knowledge_data["reason"] + knowledge_data["solution"]
    knowledge_json=json.dumps(knowledge_data_json, indent=4,ensure_ascii=False)
    line_num=len(json.loads(knowledge_json)[key_name1])
    msg = "%s 知识库条数：%s" % (key_name1,line_num)
    # print(msg)
    send_to_robot(result=msg)

    with open(file_path,'w') as file:
        file.write(knowledge_json)

    

GenerateKnowledge(url=extractor_knowledge_doc_url,filter_string=ex_filter_string,knowledge_data_json=extractor_knowledge_data,file_path=extractor_knowledge_path)


GenerateKnowledge(url=data_loader_knowledge_doc_url,filter_string=dl_filter_string,knowledge_data_json=data_loader_knowledge_data,file_path=dl_knowledge_path)

