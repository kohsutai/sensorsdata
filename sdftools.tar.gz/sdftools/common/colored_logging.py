# encoding: utf-8

# @File    : log.py
# @Date    : 2023年06月15日09:16:44
# @Author  : liuxiaopeng
# @Desc:  日志函数
import logging


class ColorFormatter(logging.Formatter):
    BLACK, RED, GREEN, YELLOW, BLUE, MAGENTA, CYAN, WHITE = range(8)
    COLORS = {
        'WARNING': YELLOW,
        'INFO': GREEN,
        'DEBUG': BLUE,
        'CRITICAL': RED,
        'ERROR': RED
    }

    def __init__(self, msg):
        logging.Formatter.__init__(self, msg)

    def format(self, record):
        levelname = record.levelname
        if levelname in self.COLORS:
            bg = ''  # red background
            color = '1;%d' % (30 + self.COLORS[levelname])
            record.msg = '\033[%s%sm%s\033[0m' % (color, bg, record.msg)
        return logging.Formatter.format(self, record)


def get_logger(name):
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)

    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    formatter = ColorFormatter('[%(asctime)s] - %(levelname)s - %(message)s')
    ch.setFormatter(formatter)

    logger.addHandler(ch)
    return logger
