# encoding: utf-8

# @File    : date_tools.py
# @Date    : 2022年06月25日16:32:58
# @Author  : liuxiaopeng
# @Desc:  日期转换的所有信息
import time
import datetime

# def gettime():
#     time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
# if __name__ == "__main__":
#     res = gettime()
#     print(res)
# nyrsfm 年月日时分秒 格式
def nyrsfm(time1):
    return  time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time1))
# nyr 年月日 格式
def nyr():
    return time.strftime("%Y-%m-%d", time.localtime())
# shuzi 年月日时分秒 数字格式
def shuzi():
    return time.strftime("%Y%m%d%H%M%S", time.localtime())
# 时间戳
def chuo():
    return time.time()
def miao():
    return int(time.time())
# 将时间字符串转换为datetime对象
def str_time_to_timestamp(str_time):
    #str_time = "2021-08-03 10:25:35"
    datetime_obj = datetime.datetime.strptime(str_time, "%Y-%m-%d %H:%M:%S")

    # 将datetime对象转换为时间戳
    return time.mktime(datetime_obj.timetuple())

def year():
    return time.strftime("%Y",time.localtime())

def timestamp_second(time=None):
    '''获取时间戳，精确到秒，不指定则为当前时间'''
    dt = datetime.datetime.strptime(time,'%Y-%m-%d %H:%M:%S') if time else datetime.datetime.now()
    return int(dt.timestamp())


if __name__ == "__main__":
    print(chuo())
