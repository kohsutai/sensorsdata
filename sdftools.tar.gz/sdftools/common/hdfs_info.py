# encoding: utf-8

# @File    : hdfs_info.py
# @Date    : 2023年09月27日14:43:34
# @Author  : liuxiaopeng
# @Desc:

import json
import xml.etree.ElementTree as ET
from urllib.request import urlopen
from hyperion_client.deploy_topo import DeployTopo
from hyperion_client.deploy_info import DeployInfo
from distutils.version import LooseVersion




def sp_version():
    """
    获取 sp 版本，sp2.1 后 接口和命令都变了
    """
    sp_version = DeployTopo().get_product_major_version("sp")
    return sp_version


def is_ge_sp21_version():
    if LooseVersion(sp_version()) >= LooseVersion("2.1.0"):
        return True
    
# 请求对应 url 然后返回 json 格式
def req_get_json(url):
    return json.loads(urlopen(url).read().decode('utf-8'))

# 获取 nn 管理地址
def get_nn_http_addresses():
    # 取 hdfs 配置时，单机和集群区别处理下
    dfs_namenode_http_address = "dfs.namenode.http-address." if not DeployInfo().get_simplified_cluster() else "dfs.namenode.http-address"
    nn_http_addresses=[]
    conf_dict = {}
    file_path = "/etc/hadoop/conf/hdfs-site.xml"
    if is_ge_sp21_version():
        from hyperion_guidance.mothership_connector import MothershipConnector
        connector = MothershipConnector().get_instance()
        nn_addresses = connector.get_role_deploy_nodes("hdfs", "namenode")
        nn_http_addresses = [x + ':50070' for x in nn_addresses]
        return nn_http_addresses
    else:
        try:
            tree = ET.parse(file_path)
            for prop in tree.getroot().findall('property'):
                key = prop.find('name').text
                value = prop.find('value').text
                conf_dict[key] = value
            for key in conf_dict.keys():
                if dfs_namenode_http_address in key:
                        nn_http_address = conf_dict[key]
                        nn_http_addresses.append(nn_http_address)
            return list(set(nn_http_addresses))
        except Exception:
            # print(e)
            return False
    

def check_nn_status():
    """
    查看 nn 主备状态
    :return: bool，True 表示正常，False 表示异常（可能双备了）
    """
    nn_http_addresses=get_nn_http_addresses()
    if nn_http_addresses:
        nn_active_count = 0
        for nn_http_address in nn_http_addresses:
            url = f'http://{nn_http_address}/jmx?qry=Hadoop:service=NameNode,name=NameNodeStatus'
            # print(url)
            try: 
                if "active" == req_get_json(url=url)["beans"][0]["State"]:
                    nn_active_count += 1
            except Exception:
                return False
        if nn_active_count != 1:
            return False
        else:
            return True


if __name__ == "__main__":
    print(get_nn_http_addresses())
    