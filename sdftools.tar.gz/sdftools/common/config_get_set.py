# encoding: utf-8

# @File    : configget.py
# @Date    : 2023年12月07日08:18:07
# @Author  : liuxiaopeng
# @Desc:  获取各种服务配置信息

from distutils.version import LooseVersion
from hyperion_client.deploy_topo import DeployTopo
from hyperion_client.config_manager import ConfigManager
from hyperion_utils.shell_utils import check_output
import json

class ConfigGetSet:
    def __init__(self):
        self.sp_version = self.get_sp_version()
        self.is_ge_sp21 = self.is_ge_sp2_1_version()

    def get_sp_version(self):
        """
        获取 sp 版本，sp2.1 后 接口和命令都变了
        """
        sp_version = DeployTopo().get_product_major_version("sp")
        return sp_version

    def is_ge_sp2_1_version(self):
        if LooseVersion(self.sp_version) >= LooseVersion("2.1.0"):
            return True

    def confGet(self,key,product,namespace,default_value):
        """
        获取配置
        :param product: 产品线名称
        :param namespace: 命名空间/模块名称
        :param key: 查询的 key
        :param default_value:  查不到配置时使用默认值
        :return: 查询 key 的值
        """
        if self.is_ge_sp21:
            cmd = 'sbpadmin business_config -a get -p {} -n {} -k {} -t json'.format(product, namespace, key)
            res = json.loads(check_output(cmd=cmd, print_fun=lambda x: None, timeout=60))
            value = res['value']
            if value is None or value.strip().lower() == 'null':
                value = default_value
        else:
            conf_dict = ConfigManager().get_server_conf(product, namespace)
            value = conf_dict.get(key, default_value)
        return value

    def confSet(self,key,product,namespace,value):
        """
        生成配置命令
        :param product: 产品线名称
        :param namespace: 命名空间/模块名称
        :param key: 设置的 key
        :param value:  设置的值
        :return: 配置命令
        """
        if self.is_ge_sp21:
            cmd = f"sbpadmin business_config -a set -p {product} -n {namespace} -k {key} -v {value}"
        else:
            cmd = f"spadmin config set server -m {namespace} -p {product} -n {key} -v {value}"
        return cmd