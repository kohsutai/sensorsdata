# encoding: utf-8

# @File    : check_sensors_service.py
# @Date    : 2023年12月20日16:14:01
# @Author  : wangfei
# @Desc    : 检查 kafka 状态，新版本的 kafka 不适配重新适配了下

import re
import subprocess

def run_cmd(cmd=None, should_succ=False, output_process=True, timeout=7200):
    """
    exec command Popen
    stdcode, stdout, stderr = runCmd(cmd)
    """
    if output_process:
        stdout = ""
        stderr = ""
        try:
            p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)  # 使用管道
            all_info = ""
            while p.poll() is None:
                line = p.stdout.readline().decode("utf8")
                all_info += line

            if not re.search("renturncode:0", all_info.split()[-1]):
                res = {'cmd': cmd, 'ret': 1, 'stdout': stdout, 'stderr': all_info}
            else:
                res = {'cmd': cmd, 'ret': 0, 'stdout': all_info, 'stderr': stderr}
        except Exception as e:
            res = {'cmd': cmd, 'ret': 1, 'stdout': stdout, 'stderr': e}

        return res
    else:
        p = subprocess.Popen(
            cmd,
            shell=True,
            universal_newlines=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        try:
            (stdout, stderr) = p.communicate(timeout=timeout)
        except subprocess.TimeoutExpired:
            # (stdout, stderr) = p.communicate()
            stdout = stderr = "timeout"
            p.kill()

        ret = p.returncode
        res = {'cmd': cmd, 'ret': ret, 'stdout': stdout, 'stderr': stderr}
        return res


def check_kafka():
    """
    检查1 replaction数量是否对齐
    检查2 rs isr是否对齐
    检查3 leader是否是1个(多个的话就是脑裂)
    Returns:
    """
    item_name = "check_kafka"
    status = "normal"
    error_msg = ""
    try:
        cmd1 = """kafka-topics --zookeeper $(cat $SENSORS_DATA_HOME/conf/sensors_data.property |grep zookeeper.connect|awk -F "=" '{print $2}') --describe"""
        res = run_cmd(cmd1, output_process=False)

        if res["ret"] == 0:
            # step1 先获取每个Topic对应的ReplicationFactor
            dict_topic_map_replication = {}
            for line1 in res["stdout"].strip().split('\t'):
                if "Topic: " in line1:
                    repr_topic = re.compile(r"Topic:\s+(\w+)\s+.*ReplicationFactor:\s+(\d+)")
                else:
                    repr_topic = re.compile(r"Topic:(\w+)\s+.*ReplicationFactor:(\d+)")
                break
            res_repr_topic = repr_topic.findall(res["stdout"])
            for line in res_repr_topic:
                dict_topic_map_replication[line[0]] = line[1]

            # step2 遍历每个Topic
            for line in res["stdout"].splitlines():
                if re.search("ReplicationFactor", line):
                    continue

                # 将每一个行的数据 转换成字典格式
                dict_line = {}
                for row in line.split("\t"):
                    if not row:
                        continue
                    key_name = row.split(":")[0].strip()
                    val = row.split(":")[1].strip()
                    dict_line[key_name] = val

                topic_name = dict_line["Topic"]
                replicationFactor = dict_topic_map_replication[topic_name]
                # 检查1 检查replaction数量是否和rs isr对齐
                if len(dict_line["Replicas"].split(",")) == len(dict_line["Isr"].split(",")) == int(replicationFactor) and sorted(dict_line["Replicas"].split(",")) == sorted(dict_line["Isr"].split(",")) and len(dict_line["Leader"].split(",")) == 1:
                    return True
                else:
                    return False

        else:
            return False

    except Exception as e:
        return False

def get_topic_partition_num(topic_name = "event_topic"):
    """
    获取：topic name 分区数
    Returns:
    """
    item_name = "get_topic_partition_num"
    status = "normal"
    error_msg = ""
    try:
        cmd1 = """kafka-topics --zookeeper $(cat $SENSORS_DATA_HOME/conf/sensors_data.property |grep zookeeper.connect|awk -F "=" '{print $2}') --topic %s --describe""" %topic_name
        res = run_cmd(cmd1, output_process=False)
        print(res)

        if res["ret"] == 0:
            # step1 先获取每个Topic对应的ReplicationFactor
            dict_topic_map_partition_num = {}
            for line1 in res["stdout"].strip().split('\t'):
                if "Topic: " in line1:
                    repr_topic = re.compile(r"Topic:\s+(\w+)\s+.*PartitionCount:\s+(\d+)")
                else:
                    repr_topic = re.compile(r"Topic:(\w+)\s+.*PartitionCount:(\d+)")
                break
            res_repr_topic = repr_topic.findall(res["stdout"])
            print(res_repr_topic)
            for line in res_repr_topic:
                dict_topic_map_partition_num[line[0]] = line[1]
                print(dict_topic_map_partition_num)
            
            return dict_topic_map_partition_num[topic_name]
    except Exception as e:
        return False

if __name__ == '__main__':
    print(get_topic_partition_num())
