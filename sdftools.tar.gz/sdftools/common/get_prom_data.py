# encoding: utf-8

# @File    : get_prom_data.py
# @Date    : 2023年10月12日09:15:49
# @Author  : liuxiaopeng
# @Desc:   : 拉取 Prometheus 数据


import requests
import json
from hyperion_client.deploy_topo import DeployTopo
from date_tools import timestamp_second


def get_prom_node():
    '''获取 Prometheus 所在节点'''
    try:
        prom_node = (DeployTopo().get_host_list_by_module_name('sm', 'prometheus'))[0]
        return prom_node

    except Exception as e:
        return False


def get_prom_data(expr,step,start_time,end_time):
    '''根据提供的 promQL 表达式从 Prometheus 拉取对应时间段数据，step 为隔几秒取一个样本值'''
    prom_node = get_prom_node()
    if prom_node:
        url = """http://%s:8310/api/v1/query_range?query=(%s)&start=%s&end=%s&step=%s""" %(prom_node,expr,start_time,end_time,step)
        # print(url)
        try:
            res = json.loads(requests.post(url=url).content.decode('utf8', 'ignore'))
            if res["status"] == "success":
                return res
        except Exception as e:
            return False
    else:
        return False
    
def get_sdf_latency_min(data_type="event"):
    expr = """max (data_flow_latency_time_min{data_type="%s"})""" %data_type
    start_time = timestamp_second() - 3600
    end_time = timestamp_second()
    step = 60
    res = get_prom_data(expr=expr,step=step,start_time=start_time,end_time=end_time)
    # print(res)
    if res:
        try:
            res_data = res["data"]["result"][0]["values"]
            max_value = max(int(item[1]) for item in res_data)
            return max_value
        except Exception as e:
            return False
    else:
        return False   


    
def get_avg_import_rate(expr):
    '''
    1 天 = 86400 秒
    2 天 = 172800 秒
    3 天 = 259200 秒
    7 天 = 604800 秒
    '''

    start_time = timestamp_second() - 604800
    end_time = timestamp_second()
    step = 1800
    res = get_prom_data(expr=expr,step=step,start_time=start_time,end_time=end_time)
    if res:
        try:
            res_data = res["data"]["result"][0]["values"]
            data = [[int(item[0]), float(item[1])] for item in res_data]
            average = int(sum(item[1] for item in data)  / len(data))
            # 输出 + 1，是为了解决当结果为 0 时，后面判断输出是否为真，结果就为 False 了，影响判断逻辑
            average +=1
            return average
        except Exception as e:
            return False
    else:
        return False




if __name__ == '__main__':
    expr = """sum(rate(data_flow_data_load_count{data_type="event"}[5m]))"""
    get_avg_import_rate(expr=expr)
    print(get_sdf_latency_min())



