#!/bin/bash

# $Name:         kafka_partition_reassignment
# $Version:      v1.0
# $Function:     kafka 分区重新分配均衡
# $Author:       liuxiaopeng
# $Create Date:  2022年02月22日06:47:14
# $Description:  1、参数 all 对所有 topic 重新分配均衡
#                2、指定 topic 进行重新分配均衡
#######################################################
# Shell Env
SHELL_NAME=`basename $0`
SHELL_DIR="/tmp"
SHELL_LOG="${SHELL_DIR}/${SHELL_NAME}.log"
LOCK_FILE="/tmp/${SHELL_NAME}.lock"

# mains
#Write Log
shell_log(){
    LOG_INFO=$1
    echo "$(date "+%Y-%m-%d") $(date "+%H:%M:%S") : ${SHELL_NAME} : ${LOG_INFO}" >> ${SHELL_LOG}
}

red_color(){
    CONTENT=$1
    echo -e "\033[31m $CONTENT \033[0m"
}
green_color(){
    CONTENT=$1
    echo -e "\033[32m $CONTENT \033[0m"
}

KAFKA_BIN=`ps aux|egrep "kafka.properties|server.properties"|awk -F jar: '{print $2}'|grep -v "^$" |awk -F '\\\.\\\./' '{print $1}'`
green_color "Kafka BIN 路径为：$KAFKA_BIN"
ZK_SERVER=`cat ~/conf/sensors_data.property |grep zookeeper.connect|awk -F '=' '{print $NF}'`
green_color "ZK Server 列表：$ZK_SERVER"
REASSIGNMENT_JSON_FILE="/tmp/part.json"
#REASSIGNMENT_BROKER_IDS=`echo "ls /brokers/ids" |zookeeper-client  2>&1|tail -2|head -1|sed 's#\[##g'|sed 's#\]##g'|sed 's# ##g'`
REASSIGNMENT_BROKER_IDS=$(ssh `cat ~/conf/sensors_data.property |grep zookeeper.connect|awk -F '=' '{print $NF}'|awk -F :2181 '{print $1}' ` echo "ls /brokers/ids" |zookeeper-client  2>&1|tail -2|head -1|sed 's#\[##g'|sed 's#\]##g'|sed 's# ##g')
green_color "Broker ID 列表：$REASSIGNMENT_BROKER_IDS"

# 记录 event_topic 数据目录
kafka-run-class kafka.admin.LogDirsCommand  --bootstrap-server `hostname`:9092 --describe --topic-list event_topic |tail -1 |python3 -m json.tool >/tmp/kafka_log_dir.json

KAFKA_BROKERS=`spadmin config get client -m kafka -p sp -n broker_list 2>&1 | grep "^ " | sed 's/"//g;s/ *$//g' | awk '{print $1}' | xargs | sed 's/ //g'`

green_color "Broker 列表: $KAFKA_BROKERS"
BROKER_COUNTER=`ss -an |grep -i listen |grep  ":9092"|wc -l`

[ $BROKER_COUNTER -lt 1 ] && red_color "未在broker节点执行，请在 $KAFKA_BROKERS 其中一个节点执行" && exit

[ -z $1 ] && red_color "缺少参数：all 或者 topic 名称" && exit

if [ $1 == "all" ];then
   TOPIC_LIST=`$KAFKA_BIN/kafka-topics.sh --list --zookeeper $ZK_SERVER|grep -v __consumer_offsets`
else
   TOPIC_LIST=`echo $1`
fi

green_color "需要均衡的 topic：$TOPIC_LIST"

for n in `echo $TOPIC_LIST`
do
    cat >/tmp/move.json <<EOF
{"topics": [{"topic": "$n"}],
 "version":1
}
EOF
    $KAFKA_BIN/kafka-reassign-partitions.sh --zookeeper $ZK_SERVER --topics-to-move-json-file /tmp/move.json  --broker-list  "$REASSIGNMENT_BROKER_IDS"  --generate|tail -1 >$REASSIGNMENT_JSON_FILE
    exit
    $KAFKA_BIN/kafka-reassign-partitions.sh --zookeeper $ZK_SERVER --reassignment-json-file $REASSIGNMENT_JSON_FILE --execute
    sleep 10
    for n in `seq 10000`
    do
       process_num=`$KAFKA_BIN/kafka-reassign-partitions.sh --zookeeper $ZK_SERVER --reassignment-json-file $REASSIGNMENT_JSON_FILE --verify|awk '{print $NF}'|grep "progress"|wc -l`
       if [ "$process_num" -eq 0 ];then
          break
       else
          $KAFKA_BIN/kafka-reassign-partitions.sh --zookeeper $ZK_SERVER --reassignment-json-file $REASSIGNMENT_JSON_FILE --verify
          sleep 10
       fi
     done
done
echo "查看进度:$KAFKA_BIN/kafka-reassign-partitions.sh --zookeeper $ZK_SERVER --reassignment-json-file $REASSIGNMENT_JSON_FILE --verify"
