>leader_balance.log
nohup kudu table list $(spadmin config get client -m kudu -p sp -n master_address -c -p sp| sed 's/"//g') | xargs -i python3 leader.py $(spadmin config get client -m kudu -p sp -n master_address -c -p sp| sed 's/"//g') {} &>leader_balance.log &
tailf leader_balance.log