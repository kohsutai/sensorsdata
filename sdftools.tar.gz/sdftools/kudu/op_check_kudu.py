# encoding: utf-8

# @File    : op_check_kudu.py
# @Date    : 2023年07月13日09:46:05
# @Author  : liuxiaopeng
# @desc    : kudu 问题排查工具

import os,sys
import argparse
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'common')))
from all_kudu_info import KuduInfo


# 参数解析
parser = argparse.ArgumentParser(
    description='适用于获取 kudu 表，节点，日志 等信息',
)
# 指定需要重做的类型t
parser.add_argument('-t', '--type', dest="type", type=str, default="all",choices=["log","table","node","all"], help="指定类型: 1、log 只展示日志级别 2、table 只展示表级别 3、node 只展示节点级别 4、all 获取以上全部信息，默认参数：all")
parser.add_argument('-c', '--count', dest="count", type=int, default=2000, help="指定截取日志行数：默认是 2000 条，例如：-c 2000")
args = parser.parse_args()

type1 = args.type
count = args.count
if type1 == "all":
    KuduInfo().get_kudu_tables_info()
    KuduInfo().get_kudu_tserver_info()
    KuduInfo().op_check_kudu(count)
elif type1 == "log":
    KuduInfo().op_check_kudu(count)
elif type1 == "table":
    KuduInfo().get_kudu_tables_info()
else:
    KuduInfo().get_kudu_tserver_info()


