# encoding: utf-8

# @File    : redo_kudu.py
# @Date    : 2023年06月27日08:41:42
# @Author  : liuxiaopeng
# @Desc:  重做 kudu 参考的文档：https://doc.sensorsdata.cn/pages/viewpage.action?pageId=269977788

import json
import logging
import os
import sys
import subprocess
import argparse
import requests

from distutils.version import LooseVersion
# import time
# import threading

# from hyperion_utils import shell_utils
from hyperion_client.config_manager import ConfigManager
from hyperion_client.deploy_info import DeployInfo
from hyperion_client.deploy_topo import DeployTopo

SOKU_TOOL_ROOT_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'soku_tool')
if SOKU_TOOL_ROOT_PATH not in sys.path:
    sys.path.append(SOKU_TOOL_ROOT_PATH)


# 参数解析
parser = argparse.ArgumentParser(
    description='适用于 kudu master 或者 tserver 重做场景',
)
# 指定需要重做的类型t
parser.add_argument('-t', '--type', dest="type", type=str, default="tserver",choices=["tserver","master"], help="指定重做的类型： master 或者 tserver")
args = parser.parse_args()

class ColorFormatter(logging.Formatter):
    BLACK, RED, GREEN, YELLOW, BLUE, MAGENTA, CYAN, WHITE = range(8)
    COLORS = {
        'WARNING': YELLOW,
        'INFO': GREEN,
        'DEBUG': BLUE,
        'CRITICAL': RED,
        'ERROR': RED
    }

    def __init__(self, msg):
        logging.Formatter.__init__(self, msg)


    def format(self, record):
        levelname = record.levelname
        if levelname in self.COLORS:
            bg = ''  #  background
            color = '1;%d' % (30 + self.COLORS[levelname])
            record.msg = '\033[%s%sm%s\033[0m' % (color, bg, record.msg)
        return logging.Formatter.format(self, record)


def get_logger(name):
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)

    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    formatter = ColorFormatter('[%(asctime)s] - %(levelname)s - %(message)s')
    ch.setFormatter(formatter)
    file_handler = logging.FileHandler('/tmp/redo_kudu.log')
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    logger.addHandler(ch)
    return logger




class RedoClusterKudu:        
    logger = get_logger(__name__)
    def __init__(self):
        self.is_ge_sp21 = self.is_ge_sp2_1_version()
        self.kudu_bin = "kudu" if self.is_ge_sp21 else "sp_kudu"
    def cmd_run(self,cmd):
        """
        没有使用 云平台提供的 run_cmd 场景不适用，重写个
        """
        p = subprocess.Popen([cmd], stdout=subprocess.PIPE, stderr=subprocess.PIPE,shell=True)
        stdout, _ = p.communicate()
        stdout = stdout.strip()
        if p.returncode != 0:
            self.logger.info("execute command:%s failed" % cmd)
            exit(1)
        stdout = stdout.decode("utf-8", "ignore")
        return stdout
 
    def health_check(self, master_addr):
        """
        kudu health 状态是否 OK
        """
        ksck_cmd = '%s cluster ksck -sections=TSERVER_SUMMARIES %s -ksck_format=json_compact' % (self.kudu_bin,master_addr)
        stdout = json.loads(self.cmd_run(cmd=ksck_cmd))["tserver_summaries"]
        status_is_ok_count = 0
        kudu_tserver_count = len(self.get_kudu_tserver_addresses(kudu_master_addresses=master_addr))
        for tserver in stdout:
            if tserver["status"] =="OK":
                status_is_ok_count +=1
        if status_is_ok_count >= kudu_tserver_count:
            return True
        return False



    def ksck(self, master_addresses, table_filter):
        """
        kudu ksck 检查信息 
        """
        ksck_cmd = '%s cluster ksck %s -ksck_format=json_compact -sections=TABLET_SUMMARIES -tables=%s' \
            % (self.kudu_bin,master_addresses, table_filter)
        # 无法使用云平台的接口，因为含有特殊字符，云平台的接口解析不了
        stdout = self.cmd_run(cmd=ksck_cmd)
        return stdout
    
    def get_kudu_tables_rf(self,master_addresses):
        """
        获取 kudu 所有表的 RF 检查副本数是否足够 >=3
        """
        get_kudu_tables_rf_cmd = '%s cluster ksck %s -sections=TABLE_SUMMARIES  -ksck_format=json_compact' %(self.kudu_bin,master_addresses)
        stdout = self.cmd_run(cmd=get_kudu_tables_rf_cmd)
        get_kudu_tables_rf_info = json.loads(stdout)
        tables_count = len(get_kudu_tables_rf_info["table_summaries"])
        tmp_table_count = 0 
        for table_info in get_kudu_tables_rf_info["table_summaries"]:
            if table_info["replication_factor"] >=3:
                tmp_table_count +=1
            else:
                self.logger.info("表名：%s，副本数为：%s 小于 3" %(table_info["name"],table_info["replication_factor"]))
        if tmp_table_count < tables_count:
            return False
        return True
    


    def get_sp_version(self):
        """
        获取 sp 版本，sp2.1 后 接口和命令都变了
        """
        sp_version = DeployTopo().get_product_major_version("sp")
        return sp_version



    def is_ge_sp2_1_version(self):
        if LooseVersion(self.get_sp_version()) >= LooseVersion("2.1.0"):
            return True



    def get_kudu_master_addresses(self):
        """
        获取 kudu master 地址
        """
        if self.is_ge_sp21:
            get_kudu_master_addresses_cmd = "aradmin config get client -m kudu -p sp -n master_address -w literal"
            kudu_master_addresses = self.cmd_run(cmd=get_kudu_master_addresses_cmd)
            return kudu_master_addresses
        else:
            kudu_master_addresses = ConfigManager().get_client_conf("sp", "kudu")['master_address']
            return kudu_master_addresses


    def get_kudu_tserver_addresses(self,kudu_master_addresses):
        """
        获取 kudu tserver 地址
        """
        get_kudu_tserver_addresses_cmd = "%s tserver list %s --format=json" %(self.kudu_bin,kudu_master_addresses)
        kudu_tserver_addresses_info = json.loads(self.cmd_run(cmd=get_kudu_tserver_addresses_cmd))
        kudu_tserver_addresses_list = []
        for kudu_tserver_address in kudu_tserver_addresses_info:
            kudu_tserver_addresses_list.append(kudu_tserver_address["rpc-addresses"].split(':')[0])
        return list(set(kudu_tserver_addresses_list))



    def get_kudu_version(self):
        """
        获取 kudu 版本信息
        """
        get_kudu_version_cmd = "%s -version|grep kudu" %(self.kudu_bin)
        kudu_version = self.cmd_run(cmd=get_kudu_version_cmd).split(' ')[1]
        return kudu_version
    
    def get_hostname(self):
        """
        获取本机 hostname -f 
        """
        get_hostname_cmd = "hostname -f"
        hostname = self.cmd_run(cmd=get_hostname_cmd)
        return hostname


    def is_ms_or_cdh(self):
        """
        判断下是 mothership 还是 cdh
        """
        ms_or_cdh = "mothership2" if self.is_ge_sp21 else DeployInfo().get_hadoop_distribution()
        return ms_or_cdh


    def start_or_stop_kudu_by_api(self,start_or_stop,master_or_tserver,hostname):
        cloudera_manager_config_info = ConfigManager().get_client_conf("sp", "cloudera")
        cloudera_manager_api_url = cloudera_manager_config_info['cloudera_manager_api_url']
        cloudera_manager_password = cloudera_manager_config_info['cloudera_manager_password']
        cloudera_manager_username =  cloudera_manager_config_info['cloudera_manager_username']
        cluster_name = cloudera_manager_config_info['cluster_name']
        # 先获取下 api 的版本信息
        get_cdh_api_version_url = "%s/api/version" %cloudera_manager_api_url
        # 先获取下 host 映射
        auth = requests.auth.HTTPBasicAuth(cloudera_manager_username,cloudera_manager_password)
        get_cdh_api_version = requests.get(get_cdh_api_version_url,auth=auth).text
        get_hosts_cdh_api_url = "%s/api/%s/hosts" %(cloudera_manager_api_url,get_cdh_api_version)
        get_hosts_response = json.loads(requests.get(get_hosts_cdh_api_url, auth=auth).text)
        get_roleid_cdh_api_url = "%s/api/%s/clusters/%s/services/kudu/roles" %(cloudera_manager_api_url,get_cdh_api_version,cluster_name)
        get_roleid_response = json.loads(requests.get(get_roleid_cdh_api_url,auth=auth).text)
        type = "KUDU_MASTER" if master_or_tserver == "master" else "KUDU_TSERVER"
        for hosts in get_hosts_response["items"]:
            if hostname == hosts["hostname"]:
                hostid = hosts["hostId"]
                for roleid in get_roleid_response["items"]:
                    if hostid == roleid["hostRef"]["hostId"] and roleid["type"] == type:
                        role_id_name = roleid["name"]
        url_auth = "%s:%s" %(cloudera_manager_username,cloudera_manager_password)
        start_or_stop_api_url = """curl -X POST -H "Content-Type:application/json" -u %s %s/api/%s/clusters/%s/services/kudu/roleCommands/%s -d '{"items":["%s"]}' """ %(url_auth,cloudera_manager_api_url,get_cdh_api_version,cluster_name,start_or_stop,role_id_name)
        return start_or_stop_api_url


        
    def pre_check_kudu_table_rf(self):
        # 第一步 判断表的副本数是否满足
        kudu_master_addresses = self.get_kudu_master_addresses()
        if self.get_kudu_tables_rf(master_addresses=kudu_master_addresses):
            self.logger.info("\n\n=======分割线=======\n\n")
            self.logger.error("注意，如果是混部环境不要按脚本提示执行！！！咨询下存储专项同学！")
            self.logger.info("第一步：检查所有表的副本数，表副本数均大于等于 3 【通过】")
            return True
        else:
            kudu_version = self.get_kudu_version()
            kudu_12_verison = "1.12.0"
            kudu_14_version = "1.14.0"
            if LooseVersion(kudu_version) > LooseVersion(kudu_12_verison) and LooseVersion(kudu_version) < LooseVersion(kudu_14_version):
                modify_kudu_table_rf_cmd = """%s table list %s  | xargs -i sp_kudu table set_extra_config %s {} 'kudu.table.num_replicas' 3 """ %(self.kudu_bin,kudu_master_addresses,kudu_master_addresses)
                self.logger.warning("存在 kudu 表副本数小于 3 的情况，kudu 版本为 %s ，修改副本数命令为：%s" %(kudu_version,modify_kudu_table_rf_cmd))
            elif LooseVersion(kudu_version) > LooseVersion(kudu_14_version):
                modify_kudu_table_rf_cmd = """%s table list %s | xargs -i sp_kudu table  set_replication_factor %s {}  3 """ %(self.kudu_bin,kudu_master_addresses,kudu_master_addresses)
                self.logger.warning("存在 kudu 表副本数小于 3 的情况，kudu 版本为：%s，修复副本数命令为：%s" %(kudu_version,modify_kudu_table_rf_cmd))
            else:
                self.logger.warning("存在 kudu 表副本数小于 3 的情况，kudu 版本为：%s，版本不符合预期修复副本命令未收录，退出！")
                exit()
            return False



    def pre_check_kudu_config(self,master_or_tserver):
        kudu_master_addresses = self.get_kudu_master_addresses()
        kudu_tserver_addresses = self.get_kudu_tserver_addresses(kudu_master_addresses=kudu_master_addresses)
        # 第二步 判断 kudu ksck 是否正常
        if self.health_check(master_addr=kudu_master_addresses):
            self.logger.info("第二步：检查 kudu 集群状态：OK！【通过】")
            # 第三步 获取 master_or_tserver 的必要配置信息
            ## 3.1 获取 master_or_tserver address
            kudu_addresses = kudu_master_addresses if master_or_tserver =="master" else kudu_tserver_addresses
            ## 判断下是不是在 master_or_tserver 节点
            hostname = self.get_hostname()            
            if hostname in kudu_addresses:
                # 获取 master_or_tserver 的必要配置信息
                kudu_url = "http://%s:8051" %hostname if master_or_tserver =="master" else "http://%s:8050" %hostname
                get_wal_dir_cmd =  "curl %s/varz 2>/dev/null | grep fs_wal_dir= | awk -F'=' '{print $2}'" %(kudu_url)
                wal_dir=self.cmd_run(cmd=get_wal_dir_cmd)
                get_data_dirs_cmd = "curl %s/varz 2>/dev/null | grep fs_data_dirs= | awk -F'=' '{print $2}'" %(kudu_url)
                data_dirs= self.cmd_run(cmd=get_data_dirs_cmd)
                get_uuid_cmd = "%s %s list %s|grep `hostname`|grep -v beefbeef|awk '{print $1}'" %(self.kudu_bin,master_or_tserver,kudu_master_addresses)
                uuid= self.cmd_run(cmd=get_uuid_cmd)
                msg_log = """{"master_or_tserver":"%s","local_hostname":"%s","kudu_master_addresses":"%s","wal_dir":"%s","data_dirs":"%s","uuid":"%s"}""" %(master_or_tserver,hostname,kudu_master_addresses,wal_dir,data_dirs,uuid)
                tmp_msg_log = json.dumps(json.loads(msg_log), indent=4, ensure_ascii=False)
                color_detail_info = '\033[1;36;40m%s\033[0m' % tmp_msg_log
                self.logger.info("第三步：获取 %s 必要的配置信息，如下【通过】：\n%s" %(master_or_tserver,color_detail_info))
                return json.loads(msg_log)
            else:
                self.logger.error("当前节点不是 %s 节点，退出！" %master_or_tserver)
                exit()
        else:
            self.logger.error("kudu 集群状态 ERROR！ 退出！")
            exit()
    


    def pre_check_redo_kudu(self,master_or_tserver,config_info):
        # 判断环境是 mothership 还是 cdh，停 tserver 服务
        local_hostname = config_info["local_hostname"]
        ms_or_cdh = self.is_ms_or_cdh()
        service_name = "kudu_master" if master_or_tserver == "master" else "kudu_tserver"
        # process_name = "kudu-master" if master_or_tserver == "master" else "kudu-tserver"
        # webserver_port = "webserver_port=8051" if master_or_tserver == "master" else "webserver_port=8050"
        # pre_check_redo_kudu_msg_log=""" {"kudu_bin":"%s","ms_or_cdh":"%s","service_name":"%s","process_name":"%s","webserver_port":"%s"} """%(kudu_bin,ms_or_cdh,service_name,process_name,webserver_port)
        # tmp_pre_check_redo_kudu_msg_log = json.dumps(json.loads(pre_check_redo_kudu_msg_log), indent=4, ensure_ascii=False)
        # color_detail_info = '\033[1;36;40m%s\033[0m' % tmp_pre_check_redo_kudu_msg_log
        # self.logger.info(color_detail_info)
        

        if "mothership" == ms_or_cdh:
            stop_cmd = "spadmin mothership stop -m kudu -r %s -n `hostname -f`" %service_name
            start_cmd = "spadmin mothership start -m kudu -r %s -n `hostname -f`" %service_name
            self.logger.info("第四步：停 %s 服务，%s 环境，执行 stop %s 的命令如下：\n%s" %(master_or_tserver,ms_or_cdh,master_or_tserver,stop_cmd))
        elif "mothership2" == ms_or_cdh:
            stop_cmd = "mothershipadmin stop -m kudu -r %s --host `hostname -f`" %service_name
            start_cmd = "mothershipadmin start -m kudu -r %s --host `hostname -f`" %service_name
            self.logger.info("第四步：停 %s 服务，%s 环境，执行 stop %s 的命令如下：\n%s" %(master_or_tserver,ms_or_cdh,master_or_tserver,stop_cmd))
        else:
            stop_cmd = self.start_or_stop_kudu_by_api(start_or_stop="stop",master_or_tserver=master_or_tserver,hostname=local_hostname)
            start_cmd = self.start_or_stop_kudu_by_api(start_or_stop="start",master_or_tserver=master_or_tserver,hostname=local_hostname)
            self.logger.info("第四步：停 %s 服务，%s 环境，执行 stop %s 的命令如下：\n%s" %(master_or_tserver,ms_or_cdh,master_or_tserver,stop_cmd))
            
            ## 下面的方法不灵，重启不更新配置
            # get_pid_cmd = """for n in `ps aux|grep %s|grep gflagfile|awk -F '=' '{print $NF}'`;do num=$(sudo grep "%s" $n|wc -l);if [ $num -eq 1 ];then echo $n;fi;done""" %(process_name,webserver_port)
            # pid_name=self.cmd_run(cmd=get_pid_cmd).split('/')[4]
            # stop_cmd = "sudo /usr/lib64/cmf/agent/build/env/bin/supervisorctl -c /run/cloudera-scm-agent/supervisor/supervisord.conf stop %s" %pid_name          
            # start_cmd = "sudo /usr/lib64/cmf/agent/build/env/bin/supervisorctl -c /run/cloudera-scm-agent/supervisor/supervisord.conf start %s" %pid_name
            # self.logger.info("第四步：停 %s 服务，%s 环境，执行 stop %s 的命令如下：\n%s" %(master_or_tserver,ms_or_cdh,master_or_tserver,stop_cmd))

        # 删除数据操作
        self.logger.info("第五步：重做默认是按删除数据目录方式，不备份数据，删除数据目录命令如下：")
        wal_dir = config_info["wal_dir"]
        data_dirs = config_info["data_dirs"]
        uuid = config_info["uuid"]
        if "," in wal_dir:
            for _wal_dir in wal_dir.split(','):
                print("sudo rm -rf %s" %_wal_dir)
        else:
            self.logger.info("\nsudo rm -rf %s" %wal_dir)
        if "," in data_dirs:
            for data_dir in data_dirs.split(','):
                print("sudo rm -rf %s" %data_dir)
        else:
            self.logger.info("\nsudo rm -rf %s" %data_dirs)


        # 使用 原 uuid format 数据

        uuid_format_cmd = "%s fs format -fs_wal_dir=%s -fs_data_dirs=%s -uuid=%s" %(self.kudu_bin,wal_dir,data_dirs,uuid)  if self.is_ge_sp21 else "sudo %s fs format -fs_wal_dir=%s -fs_data_dirs=%s -uuid=%s" %(self.kudu_bin,wal_dir,data_dirs,uuid) 
        self.logger.info("第六步：使用原 uuid format 数据，并添加目录 kudu 属主权限，命令如下：\n%s" %uuid_format_cmd)
        if self.is_ge_sp21:
            print("sp2.1 版本不做其他操作。")
        else:
            if "," in wal_dir:
                for wal_dir in wal_dir.split(','):
                    print("sudo chown kudu. -R %s" %wal_dir)
            else:
                self.logger.info("\nsudo chown kudu. -R %s" %wal_dir)
            if "," in data_dirs:
                for data_dir in data_dirs.split(','):
                    print("sudo chown kudu. -R %s" %data_dir)
            else:
                self.logger.info("\nsudo chown kudu. -R %s" %data_dirs)
        if master_or_tserver == "master":
            local_hostname_kudu_master_address = self.get_hostname() + ":7051"
            print(local_hostname_kudu_master_address)
            tmp_kudu_master_addresses =  self.get_kudu_master_addresses().split(',')
            tmp_kudu_master_addresses.remove(local_hostname_kudu_master_address)
            self.logger.info("非本机正常的 master 节点主机列表：%s"%tmp_kudu_master_addresses)

            self.logger.info("复制 meta 数据到该节点，命令如下：\nsudo -u kudu kudu local_replica copy_from_remote 00000000000000000000000000000000  %s -fs_wal_dir=%s -fs_data_dirs=%s" %(tmp_kudu_master_addresses[0],wal_dir,data_dirs))

        # 启动 master_or_tserver 服务
        self.logger.info("第七步：启动 %s 服务，命令如下：\n%s"%(master_or_tserver,start_cmd))



    def redo_kudu(self,master_or_tserver):
        if  DeployInfo().get_simplified_cluster():
            self.logger.error("单机环境暂不支持重做，退出！")
            exit()
        kudu_master_addresses = self.get_kudu_master_addresses()
        self.pre_check_kudu_table_rf()
        config_info = self.pre_check_kudu_config(master_or_tserver=master_or_tserver)
        kudu_tserver_addresses = self.get_kudu_tserver_addresses(kudu_master_addresses=kudu_master_addresses)
        ksck_cmd = '%s cluster ksck %s' % (self.kudu_bin,kudu_master_addresses)

        # 不更换路径，重置 master_or_tserver 选择直接删除原有数据方式
        # 调整不可用时间，先判断下 master_or_tserver 节点大于 3 的话才执行
        if master_or_tserver =="tserver":
            kudu_tserver_addresses_count = len(kudu_tserver_addresses)
            if kudu_tserver_addresses_count > 3:

                need_exec_cmd1 = """%s tserver list %s -columns=rpc-addresses -format=space | xargs -i sudo su kudu -s /bin/bash -c "%s tserver set_flag {} follower_unavailable_considered_failed_sec 7200 --force" """ %(self.kudu_bin,kudu_master_addresses,self.kudu_bin)
                need_exec_cmd2 = """%s master list %s -columns=rpc-addresses -format=space | xargs -i sudo su kudu -s /bin/bash -c "%s master set_flag {} follower_unavailable_considered_failed_sec 7200 --force" """ %(self.kudu_bin,kudu_master_addresses,self.kudu_bin)
                need_exec_cmd3 = """%s tserver list %s -columns=rpc-addresses -format=space | xargs -i sudo su kudu -s /bin/bash -c "%s tserver set_flag {} follower_unavailable_considered_failed_sec 300 --force" """ %(self.kudu_bin,kudu_master_addresses,self.kudu_bin)
                need_exec_cmd4 = """%s master list %s -columns=rpc-addresses -format=space | xargs -i sudo su kudu -s /bin/bash -c "%s master set_flag {} follower_unavailable_considered_failed_sec 300 --force" """ %(self.kudu_bin,kudu_master_addresses,self.kudu_bin)                    
                step_3_log = "第三步：调整不可用时间 kudu 集群节点数 %s 大于 3，需要调整不可用时间，命令如下：\n%s\n%s" %(kudu_tserver_addresses_count,need_exec_cmd1,need_exec_cmd2)
                step_9_log = "第九步：所有节点重做后再调整即可，不可用时间 kudu 集群节点数 %s 大于 3，需要调整不可用时间，命令如下：\n%s\n%s" %(kudu_tserver_addresses_count,need_exec_cmd3,need_exec_cmd4)
                self.logger.warning(step_3_log)
            else:
                step_3_log = "第三步：调整不可用时间 kudu 集群节点数等于 3，不需要调整不可用时间【通过】"
                step_9_log = "第九步：调整不可用时间 kudu 集群节点数等于 3，不需要调整不可用时间【通过】"
                self.logger.info(step_3_log)
        else:
            step_9_log = "第九步：重做 master，不用调整不可用时间【通过】"
        # 判断环境是 mothership 还是 cdh，停 tserver 服务
        # print(config_info)
        self.pre_check_redo_kudu(master_or_tserver=master_or_tserver,config_info=config_info)
        # 检查 kudu 状态
        self.logger.info("第八步：检查 kudu 集群状态，命令：\n%s " %ksck_cmd)
        if self.health_check(master_addr=kudu_master_addresses):
            self.logger.info(step_9_log)
        else:
            self.logger.error("kudu 集群状态 ERROR！ 退出!")
            exit()
        # 均衡下
        self.logger.info("第十步：所有节点重做后再均衡 leader 即可，命令如下：\nsh exec_leader.sh")


master_or_tserver = args.type
RedoClusterKudu().redo_kudu(master_or_tserver=master_or_tserver)