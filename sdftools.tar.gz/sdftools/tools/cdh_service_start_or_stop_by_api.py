#!/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) 2023 SensorsData, Inc. All Rights Reserved
@author liuxiaopeng
"""
'''
针对 cdh 管理的服务使用 api 重启服务
'''

import sys,os
import json
import requests
import logging
import subprocess
import argparse
from hyperion_client.config_manager import ConfigManager
from hyperion_client.deploy_info import DeployInfo
from hyperion_client.deploy_topo import DeployTopo
from distutils.version import LooseVersion
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'common')))

import logging


def cmd_run(cmd):
    """
    没有使用 云平台提供的 run_cmd 场景不适用，重写个
    """
    p = subprocess.Popen([cmd], stdout=subprocess.PIPE, stderr=subprocess.PIPE,shell=True)
    stdout, _ = p.communicate()
    stdout = stdout.strip()
    if p.returncode != 0:
        logger.info("execute command:%s failed" % cmd)
        exit(1)
    stdout = stdout.decode("utf-8", "ignore")
    return stdout




def get_hostname():
    """
    获取本机 hostname -f 
    """
    get_hostname_cmd = "hostname -f"
    hostname = cmd_run(cmd=get_hostname_cmd)
    return hostname


# 参数解析
parser = argparse.ArgumentParser(
    description='适用于 cdh 管理的环境 通过 api 重启服务场景',
)

# 创建一个参数组
group = parser.add_argument_group('Options')

# 添加第一个参数
group.add_argument('-m', '--module', dest="module", type=str, default="kudu", choices=["zookeeper","impala","kudu","yarn","kafka","hdfs"],
                   help="指定重做的类型：zookeeper, impala , kudu , yarn , kafka , hdfs")

# 添加第二个参数，根据第一个参数值的不同而限定取值范围
if parser.parse_known_args()[0].module == 'zookeeper':
    group.add_argument('-r', '--role', dest="role", type=str, default="SERVER",
                       choices=["SERVER"], help="指定 role 类型：SERVER")
elif parser.parse_known_args()[0].module == 'kudu':
    group.add_argument('-r', '--role', dest="role", type=str,
                       default="KUDU_TSERVER", choices=["KUDU_MASTER", "KUDU_TSERVER"],
                       help="指定 role 类型：KUDU_MASTER , KUDU_TSERVER")
elif parser.parse_known_args()[0].module == "impala":
    group.add_argument('-r', '--role', dest="role", type=str,
                       default="IMPALAD", choices=["IMPALAD", "STATESTORE", "CATALOGSERVER"],
                       help="指定 role 类型：IMPALAD, STATESTORE, CATALOGSERVER")
elif parser.parse_known_args()[0].module == "kafka":
    group.add_argument('-r', '--role', dest="role", type=str,
                       default="KAFKA_BROKER", choices=["KAFKA_BROKER"],
                       help="指定 role 类型：KAFKA_BROKER")
elif parser.parse_known_args()[0].module == "hdfs":
    group.add_argument('-r', '--role', dest="role", type=str,
                       default="DATANODE", choices=["DATANODE", "NAMENODE"],
                       help="指定 role 类型：DATANODE, NAMENODE")
parser.add_argument('-t', '--type', dest="type", type=str, default="start",choices=["start","stop","restart"], help="指定操作类型：start, stop, restart")
parser.add_argument('-a', '--hostname', dest="hostname", type=str,default=get_hostname(), help="填写主机名，默认是本机主机名")
args = parser.parse_args()



class ColorFormatter(logging.Formatter):
    BLACK, RED, GREEN, YELLOW, BLUE, MAGENTA, CYAN, WHITE = range(8)
    COLORS = {
        'WARNING': YELLOW,
        'INFO': GREEN,
        'DEBUG': BLUE,
        'CRITICAL': RED,
        'ERROR': RED
    }

    def __init__(self, msg):
        logging.Formatter.__init__(self, msg)

    def format(self, record):
        levelname = record.levelname
        if levelname in self.COLORS:
            bg = ''  # red background
            color = '1;%d' % (30 + self.COLORS[levelname])
            record.msg = '\033[%s%sm%s\033[0m' % (color, bg, record.msg)
        return logging.Formatter.format(self, record)


def get_logger(name):
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)

    ch = logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    formatter = ColorFormatter('[%(asctime)s] - %(levelname)s - %(message)s')
    ch.setFormatter(formatter)

    logger.addHandler(ch)
    return logger

logger = get_logger(__name__)





def get_sp_version():
    """
    获取 sp 版本，sp2.1 后 接口和命令都变了
    """
    sp_version = DeployTopo().get_product_major_version("sp")
    return sp_version


def is_ge_sp2_1_version():
    if LooseVersion(get_sp_version()) >= LooseVersion("2.1.0"):
        return True


def is_ms_or_cdh():
    """
    判断下是 mothership 还是 cdh
    """
    ms_or_cdh = "mothership2" if is_ge_sp2_1_version() else DeployInfo().get_hadoop_distribution()
    return ms_or_cdh

    

def start_or_stop_service_by_api(start_or_stop,module,role,hostname):
    if is_ms_or_cdh() == "cloudera":
        cloudera_manager_config_info = ConfigManager().get_client_conf("sp", "cloudera")
        cloudera_manager_api_url = cloudera_manager_config_info['cloudera_manager_api_url']
        cloudera_manager_password = cloudera_manager_config_info['cloudera_manager_password']
        cloudera_manager_username =  cloudera_manager_config_info['cloudera_manager_username']
        cluster_name = cloudera_manager_config_info['cluster_name']
        # 先获取下 api 的版本信息
        try:
            get_cdh_api_version_url = "%s/api/version" %cloudera_manager_api_url
        except Exception:
            logger.error("未获取到 cdh api 版本信息，请确认 7180 端口是否打开，退出！")
            exit()
        # 先获取下 host 映射
        auth = requests.auth.HTTPBasicAuth(cloudera_manager_username,cloudera_manager_password)
        get_cdh_api_version = requests.get(get_cdh_api_version_url,auth=auth).text
        get_hosts_cdh_api_url = "%s/api/%s/hosts" %(cloudera_manager_api_url,get_cdh_api_version)
        get_hosts_response = json.loads(requests.get(get_hosts_cdh_api_url, auth=auth).text)
        get_roleid_cdh_api_url = "%s/api/%s/clusters/%s/services/%s/roles" %(cloudera_manager_api_url,get_cdh_api_version,cluster_name,module)
        get_roleid_response = json.loads(requests.get(get_roleid_cdh_api_url,auth=auth).text)
        # print(get_hosts_response)
        # print(get_roleid_response)
        info = {}
        info["module"] = module
        info["role"] = role
        for hosts in get_hosts_response["items"]:
                hostname1 = hosts["hostname"]
                ipAddress = hosts["ipAddress"]

            # if hostname == hosts["hostname"]:
                hostId = hosts["hostId"]
                for roleid in get_roleid_response["items"]:
                    if hostId == roleid["hostRef"]["hostId"] and roleid["type"] == role:
                        role_id_name = roleid["name"]
                        tmp_info={role_id_name:{}}
                        tmp_info[role_id_name]["hostname"] = hostname1
                        tmp_info[role_id_name]["ipAddress"] = ipAddress
                        tmp_info[role_id_name]["hostId"] = hostId
                        info.update(tmp_info)
            
        print(json.dumps(info, indent=4, ensure_ascii=False))        
        role_id_keys = list(info.keys())
        # print(role_id_keys,type(role_id_keys))
        role_id_keys.remove("module")
        role_id_keys.remove("role")
        print(role_id_keys)
        for key in role_id_keys:
                 if hostname == info[key]["hostname"]:
                    role_id_name = key
                    url_auth = "%s:%s" %(cloudera_manager_username,cloudera_manager_password)
                    start_or_stop_api_url = """curl -X POST -H "Content-Type:application/json" -u %s %s/api/%s/clusters/%s/services/%s/roleCommands/%s -d '{"items":["%s"]}' """ %(url_auth,cloudera_manager_api_url,get_cdh_api_version,cluster_name,module,start_or_stop,role_id_name)
                    start_or_stop_all_instance_api_url = """curl -X POST -H "Content-Type:application/json" -u %s %s/api/%s/clusters/%s/services/%s/commands/%s """ %(url_auth,cloudera_manager_api_url,get_cdh_api_version,cluster_name,module,start_or_stop)
                    print("重启 %s 所有节点服务实例命令：%s" %(module,start_or_stop_all_instance_api_url))
                    return start_or_stop_api_url
    else:
        logger.warning("非 cdh 环境，无法使用该脚本！")
        exit()
    return False

start_or_stop = args.type
module = args.module
role = args.role
hostname = args.hostname
print(start_or_stop_service_by_api(start_or_stop=start_or_stop,module=module,role=role,hostname=hostname))