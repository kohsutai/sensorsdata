# encoding: utf-8

# @File    : table_partition_repair.py
# @Date    : 2023年04月12日11:47:51
# @Author  : liuxiaopeng
# desc     : 修复 table_partition

import os
import utils.sa_utils
exit("未经许可，不能执行")
day_id_list = [19413,19402,19411,19404,19416,19406,19415,19410,19403,19409,19414,19407,19412,19405,19408]
project_id = 2
get_table_id_sql = """select id as id from table_define where table_name = "event_view_p%s";""" %project_id
get_table_id_sql_res = utils.sa_utils.SAMysql.query(get_table_id_sql)
table_id = get_table_id_sql_res[0]["id"]
for dayid in day_id_list:
    cmd1 =  """echo -n `hdfs dfs -ls /sa/data/%s/event/%s|grep /sa/data/|awk -F '/' '{print $NF}'`|sed 's# #,#g'|sed 's#^#[#g'|sed 's#$#]#g'""" %(project_id,dayid)
    bucket_id_list = eval(os.popen(cmd1).readlines()[0].strip())
    for event_bucket in bucket_id_list:
        cmd2 = """ impala-shell -d rawdata -q "select count(1) from event_ros_p%s where event_bucket = %s and day = %s" -B --quiet""" %(project_id,event_bucket,dayid)
        row_count = os.popen(cmd2).readlines()[0].strip()
        if_exist_row_sql = """select count(1) as count from table_partition where table_id = %s and day = %s and event_bucket = %s""" %(table_id,dayid,event_bucket)
        if_exist_row_sql_res = utils.sa_utils.SAMysql.query(if_exist_row_sql)
        exist_count = if_exist_row_sql_res[0]["count"]
        if exist_count == 0:
            update_table_partition_sql = """insert into  table_partition (table_id,day,event_bucket,update_time,storage_type,status,row_count,split_num,is_stable) values (%s,%s,%s,NOW(),0,1,%s,0,0)""" %(table_id,dayid,event_bucket,row_count)
            print(update_table_partition_sql)
            update_table_partition_sql_res = utils.sa_utils.SAMysql.update(update_table_partition_sql)
            print(update_table_partition_sql_res)

