#!/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) 2020 SensorsData, Inc. All Rights Reserved
@author yangfei
"""
'''
当不能在浏览器里面访问用户的historyserver的时候，可以运行此脚本进行简单的统计分析
https://hadoop.apache.org/docs/r2.4.1/hadoop-yarn/hadoop-yarn-site/HistoryServerRest.html#Tasks_API
会输出每一个map reduce的运行时间，以及运行的物理节点，如果发现某个map/reduce特别慢，可以用
mapred -logs <job-id> <task-attempt-id> 进行日志拉取
'''
import urllib.request
import urllib.parse
import json
import sys
import os

if len(sys.argv) < 2:
  print("python3 hadoop_job_stats.py jobId [host]")
  sys.exit(1)
jobId=sys.argv[1]
if len(sys.argv) > 2:
  host = sys.argv[2]
else:
  getHostShellCommand = "yarn application -appStates ALL -list |tail -n 1 | awk '{print $NF}' |awk -F '/' '{print $3}'"
  process = os.popen(getHostShellCommand)
  host = process.read()
  host = host[0:len(host)-1]
  process.close()
print("host=%s" % host)
def getNodeAddress(jobId,taskId,attemptId):
  nodeRequestUrl='http://{host}/ws/v1/history/mapreduce/jobs/{jobid}/tasks/{taskid}/attempts/{attemptid}'.format(host=host,jobid=jobId,taskid=taskId,attemptid=attemptId)
  f = urllib.request.urlopen(nodeRequestUrl)
  t=f.read().decode('utf-8')
  jsonResponse = json.loads(t)
  return jsonResponse['taskAttempt']['nodeHttpAddress']

url = 'http://{host}/ws/v1/history/mapreduce/jobs/{jobid}/tasks'.format(host=host,jobid=jobId)
print(url)
f = urllib.request.urlopen(url)
t=f.read().decode('utf-8')
jsonResponse = json.loads(t)
tasks=jsonResponse['tasks']['task']
tasks=sorted(tasks, key=lambda x: x['elapsedTime'])
print("Map:--------------")
for task in tasks:
  if task['type'] == 'MAP':
    task['nodeHttpAddress'] = getNodeAddress(jobId,task['id'],task['successfulAttempt'])
    print(task)
print("Reduce:--------------")
for task in tasks:
  if task['type'] == 'REDUCE':
    task['nodeHttpAddress'] = getNodeAddress(jobId,task['id'],task['successfulAttempt'])
    print(task)