#!/bin/bash

#####################################################
# File Name: oom_check.sh                           #
# Author: huayang                                   #
# Created Time: Wed Mar 15 12:02:40 CST 2023        #
# Version: 1.0                                      #
#####################################################

# 版本信息
version=1.0.CST-2024_0102_1619
# 输入的参数
input=$1

# 颜色函数
function color_theme() {
    GREEN='\E[1;32m'
    YELLOW='\E[1;33m'
    RED='\E[1;31m'
    RES='\E[0m'
    info="${GREEN}INFO${RES}"
    warn="${YELLOW}WARN${RES}"
    err="${RED}ERROR${RES}"
}

# 定义函数，输出带时间戳和等级的日志信息
# 重写函数，抛弃原本的 alise
function log_level() {
    local level=$1
    shift # 为了下面的 echo $@,输出所有输入的参数作为日志信息，将 $1 去掉
    local timestamp=$(date '+%F %H:%M:%S')

    case $level in
    INFO)
        level_color=$GREEN
        ;;
    WARN)
        level_color=$YELLOW
        ;;
    ERROR)
        level_color=$RED
        ;;
    *)
        level_color=$RES
        ;;
    esac

    echo -e "\n=============== $timestamp $level_color$level$RES $@"
}

# help 提示函数
function help() {
    # -h 输出 help 相关信息
    if [[ "$input" = "-h" ]]; then
        echo -e "Usage:  sh oom_check.sh -c\n"
        echo -e "${YELLOW}  -c${RES}\tCollect: collect and check system ${RED}Out of memory${RES} information"
        echo -e "${YELLOW}  -g${RES}\tGet: Get Hadoop and SensorsData config"
        echo -e "${YELLOW}  -h${RES}\tHelp: print help text"
        echo -e "${YELLOW}  -v${RES}\tVersion: print script version"
        exit
    # -v 输出版本信息
    elif [[ "$input" = "-v" ]]; then
        echo -e "Version: $version" && exit
    # -c 默认执行 -g 只获取配置
    elif [[ "$input" != "-c" ]] && [[ "$input" != "-g" ]]; then
        log_level "ERROR" "输入参数不合法: sh oom_check.sh -h" && exit
    fi
}

# 适配 sp2.1，指令集更新
function get_cmd() {
    # 获取 spadmin / aradmin
    sp_version_string=$(python3 -c 'from hyperion_client.deploy_topo import DeployTopo;print(DeployTopo().get_product_full_version("sp"))')
    echo $sp_version_string | grep 2.1 >/dev/null 2>&1 # 看版本是否包含 2.1
    if [[ "$?" = 0 ]]; then
        sp_version="2.1"
        sp_cmd="aradmin"
    else
        sp_version="2.0"
        sp_cmd="spadmin"
    fi
}

# 前置检测
function check() {
    log_level "INFO" "程序前置检测中"
    #用户检查,脚本必须在 sa_cluster 用户下执行
    user_name=$(whoami)
    if [[ "$user_name" != "sa_cluster" ]]; then
        log_level "ERROR" "Please check: Usename should be sa_cluster!" && exit
    fi

    # 版本检测 sp>=2.0
    echo $sp_version | egrep '1.18|2.0|2.1' >/dev/null 2>&1
    if [[ "$?" != 0 ]]; then
        log_level "ERROR" "sp version must >= 1.18!" && exit
    fi
    log_level "INFO" "检测通过 √"
}

# 函数用到的变量
function global_var() {
    # 判断是单机还是 mini 集群还是标准集群(>5 台暂时都算成标准集群)
    host_num=$(python3 -c "from hyperion_client.deploy_topo import DeployTopo; print(DeployTopo().get_host_list_by_module_name('sp', 'nginx'))" | sed "s/'//g; s/\[//; s/\]//; s/ //g" | tr "," "\n" | wc -l)
    if [ $host_num -eq 1 ]; then
        is_standalone=true
    elif [ "$host_num" -ge 3 ] && [ "$host_num" -le 5 ]; then
        is_minicluster=true
    else
        is_standcluster=true
    fi

    # 所有项目名
    project_all=$(sa_mysql -Ne "use metadata;select name from project where status = 1;")

    # 项目数量
    project_num=$(echo ${project_all} | awk '{print NF}')

    # 当前日期
    today=$(sa_mysql -Ne "select TO_DAYS('$(date +%F)')-TO_DAYS('1970-01-01')")

    # 当前日期的 30 天之前
    dayago_30=$(echo "${today}-30" | bc)

    # sp2.0 获取一些变量
    if [[ "$sp_version" = 2.0 ]]; then
        # 导入模式
        sdf_loader_mode=$($sp_cmd config get server -m data_loader -p sdf -n loader_mode -d stream -c 2>&1 | tail -n 1 | sed 's/"//g')
        # impala 节点
        impalad_host=$(python3 -c 'from hyperion_client.config_manager import ConfigManager;print(ConfigManager().get_client_conf("sp", "impala")["hive_url_list"][0])' 2>&1 | awk -F "/" '{print $3}' | awk -F ":" '{print $1}')
        # hdfs namenode 节点
        hdfs_namenode_host=$(cat /etc/hadoop/conf/hdfs-site.xml | grep 50070 | head -n 1 | sed -r 's/.*>(.*)<.*/\1/g' | awk -F ":" '{print $1}')
        # 非单机获取 yarn 的相关参数
        if [[ "$is_standalone" != "true" ]]; then
            # yarn rm master 节点
            yarn_rm_host=$(cat /etc/hadoop/conf/yarn-site.xml | grep -A 1 yarn.resourcemanager.ha.rm-ids | grep value | sed -r 's/.*>(.*)<.*/\1/g' | tr "," "\n")
            for rmmaster in ${yarn_rm_host}; do
                sudo -u yarn yarn rmadmin -getServiceState ${rmmaster} | grep active >/dev/null 2>&1
                if [[ "$?" = 0 ]]; then
                    yarn_rm_master_host=$(cat /etc/hadoop/conf/yarn-site.xml | grep -A 1 webapp.address.${rmmaster} | grep value | sed -r 's/.*>(.*)<.*/\1/g')
                fi
            done
            # yarn nodemanager 节点
            yarn_nodemanager_host=$(yarn node -list 2>/dev/null | awk '{print $3}' | tail -n 1)
        fi

    # sp2.1 获取一些变量
    else
        sdf_loader_mode=$(aradmin config get server -m data_loader -p sdf -n loader_mode -d stream -w literal 2>&1 | tail -n 1 | sed 's/"//g')
        # sp2.1 用新的接口更方便，老得接口也还能用
        impalad_host=$(python3 -c 'from hyperion_guidance.mothership_connector import MothershipConnector;connector = MothershipConnector().get_instance();print(connector.get_role_deploy_nodes("impala", "impala_daemon")[0])')
        hdfs_namenode_host=$(python3 -c 'from hyperion_guidance.mothership_connector import MothershipConnector;connector = MothershipConnector().get_instance();print(connector.get_role_deploy_nodes("hdfs", "namenode")[0])')
        # 非单机获取 yarn 的相关参数
        if [[ "$is_standalone" != "true" ]]; then
            # yarn nodemanager 节点
            yarn_nodemanager_host=$(yarn node -list 2>/dev/null | awk '{print $3}' | tail -n 1)
        fi
    fi

    # 获取 promethues 节点
    prometheus_host=$(python3 -c "from hyperion_client.deploy_topo import DeployTopo; print(DeployTopo().get_host_list_by_module_name('sm', 'prometheus')[0])")

    # kudu tserver 节点
    kudu_master=$(python3 -c 'from hyperion_client.config_manager import ConfigManager;print(ConfigManager().get_client_conf("sp", "kudu")["master_address"])')
    kudu_tserver=$(kudu tserver list $kudu_master 2>&1 | awk -F "|" '{print $2}' | awk -F ":" '{print $1}' | tail -n +3)
    tserver_host=$(echo ${kudu_tserver} | tail -n 1)

    # kafka broker 节点
    kafka_broker_host=$(python3 -c 'from hyperion_client.config_manager import ConfigManager;print(ConfigManager().get_client_conf("sp", "kafka")["broker_list"][0])' | awk -F ':' '{print $1}')

    # gb 转化除数
    divisor="1073741824"

    # 最近 7 天总导入量
    loader_data_num=$(impala-shell -i ${impalad_host} -d rawdata --quiet -B --output_delimiter="\t" -q "select sum(send) from track_statistic where day < ${today};" 2>/dev/null | tail -n 1)

    # 最近 7 天平均日导入量
    daily_loader_data_num=$(echo "scale=0; ${loader_data_num}/7" | bc)
}

# 中间参数文件清理,防止之前执行过有干扰
function parameter_file_delete() {
    rm -f oom_*.txt bookmark_time_30.py >/dev/null 2>&1
}

# 定义获取主机信息函数
function get_hostname() {
    # 通过 nginx 获取所有节点
    python3 -c 'from hyperion_client.deploy_topo import DeployTopo; print(DeployTopo().get_all_host_list())' | sed "s/'//g; s/\[//; s/\]//; s/ //g" | tr "," "\n" | sort -n >oom_host.txt
}

# 获取主机 ssh 端口
function get_ssh_port() {
    ssh_port=$(sudo cat /etc/ssh/sshd_config | grep -i -w "port" | grep -v "#" | awk -F " " '{print $NF}' | tail -n 1)
    port=22
    if [[ $ssh_port ]]; then
        port=$ssh_port
    fi
}

# RD 提供的 30 天概览脚本缩减后的结果
function bookmark_python() {
    cat >bookmark_time_30.py <<EOF
#!/usr/bin/env python3
import os
import json
from datetime import datetime
from dateutil import rrule
from hyperion_guidance.mysql_connector import MysqlConnector
time_interval = 30
def stat():
    results = MysqlConnector().query("select b.id,b.name,b.data from (select distinct(bookmark_id) from dashboard_item  where dashboard_id in(select id from dashboard) ) i left join bookmark b on b.id = i.bookmark_id")    
    bookmark_list = []
    for record in results:
        data = json.loads(record['data'])
        if 'from_date' in data:
            from_date_str = data['from_date'].split(' ', 1)[0]
            to_date_str = data['to_date'].split(' ', 1)[0]
            from_date = datetime.strptime(from_date_str, '%Y-%m-%d')
            to_date = datetime.strptime(to_date_str, '%Y-%m-%d')
            days = rrule.rrule(freq=rrule.DAILY, dtstart=from_date, until=to_date)
            if days.count() > time_interval:
                del record['data']
                record['day'] = days.count()
                bookmark_list.append(record)
    str_output = str(len(bookmark_list))
    print(str_output)
if __name__ == '__main__':
    stat()
EOF
}

# OOM 总次数及每个节点 10 行展示
# 最重要最复杂的一个函数,要考虑的各种情况太多
function oom_detail() {
    log_level "INFO" "节点 Out of memory 详情"
    # 定义初始 oom_sum
    oom_sum=0
    # 循环获取单个节点的 oom 的日志行和下一行,下一行会有内存消耗 rss 信息和 uid
    for host in $(cat oom_host.txt); do

        # 从 messages 日志里面获取 oom 次数
        oom_message_count=$(ssh $host -p $port "sudo find /var/log -mtime -30 -name "messages*" -type f -exec cat {} \; | grep 'Out of memory' | wc -l" 2>/dev/null)

        # 如果 messages 日志为 0,就从 dmesg 里面获取 oom 信息
        if [ "$oom_message_count" -eq 0 ]; then
            # 标识参数用于后面判读数据来源是 dmesg
            oom_source="dmesg"
            # 取 dmesg 30 天内的日志,感谢 GPT 救我狗命,太难了
            ssh $host -p $port "sudo dmesg -T" | sed 's/\[\(.*\)\]/\1/' | awk '{"date -d \""$2" "$3" "$5"\" +\"%Y-%m-%d\"" | getline time;print time,$0}' 2>/dev/null | grep -A 1 'Out of memory' | awk -v start="$(date -d '1 months ago' +'%Y-%m-%d')" '$1 >= start' | awk '{print $1="",$0}' | sed -e 's/^ *//' >oom_detail.txt
        else
            oom_source="message"
            ssh $host -p $port "sudo find /var/log -mtime -30 -name "messages-*" -type f -exec cat {} \; | grep -A 1 'Out of memory'" 2>/dev/null >oom_detail.txt
            # 最新的 message 文件追加到最后面
            ssh $host -p $port "sudo cat /var/log/messages | grep -A 1 'Out of memory'" 2>/dev/null >>oom_detail.txt
        fi

        # 单节点 oom 次数
        oom_count=$(cat oom_detail.txt | grep 'Out of memory' | wc -l)

        # 每个节点的 oom 次数累加到 oom_sum,方便后面输出整个环境的 oom 总次数
        oom_sum=$((${oom_sum} + ${oom_count}))

        # 记录单节点的主机名和最近一次 oom 时间戳追加到 oom_timestamp.txt 文件中,方便后面的 memory_detail 函数使用
        # 同时记录每个节点最近一次 impala oom 的时间,方便后面分析 impala oom 的函数 impala_reason 使用
        if [ "$oom_source" = "message" ]; then
            # messages 来源
            echo -e "$host $(cat oom_detail.txt | grep 'Out of memory' | tail -n 1 | awk '{"date -d \""$1" "$2" "$3"\" +\"%s\"" | getline timestamp; print timestamp}' 2>/dev/null)" >>oom_timestamp.txt
            cat oom_detail.txt | grep 'Out of memory' | grep impala | tail -n 1 | awk '{print $1,$2,$3}' 2>/dev/null >>oom_impala_time.txt
        else
            # dmesg 来源
            echo -e "$host $(cat oom_detail.txt | grep 'Out of memory' | tail -n 1 | awk '{"date -d \""$2" "$3" "$4"\" +\"%s\"" | getline timestamp; print timestamp}' 2>/dev/null)" >>oom_timestamp.txt
            cat oom_detail.txt | grep 'Out of memory' | grep impala | tail -n 1 | awk '{print $2,$3,$4}' 2>/dev/null >>oom_impala_time.txt
        fi
        # oom top5 的组件和 uid
        # 先判断是否有 UID 记录,没有 UID 就只记录次数和进程
        cat oom_detail.txt | grep 'Killed process' | grep UID >/dev/null 2>&1
        if [ "$?" -eq 0 ]; then
            top_uid="true"
            cat oom_detail.txt | grep 'Killed process' | grep UID | awk -F "," '{print $1,$2}' | awk '{match($0, /\((.*)\)/,mod);print mod[1],$NF}' | sort | uniq -c | sort -nr | head -n 5 >oom_top5.txt
        else
            top_uid="false"
            cat oom_detail.txt | grep 'Out of memory' | sed -r 's/.*\((.*)\).*/\1/g' | sort | uniq -c | sort -nr | head -n 5 >oom_top5.txt
        fi

        # 输出每个节点的 oom 详细信息
        if [[ "$oom_count" = 0 ]]; then
            echo -e "\n\t\t• ${GREEN}${host}${RES}\n\t\t\t• 最近 30 天 Out of memory 次数: 0"
        else
            echo -e "\n\t\t• ${YELLOW}${host}${RES}\n\t\t\t• ${YELLOW}最近 30 天 Out of memory 次数${RES}: ${RED}${oom_count}${RES}"

            # 判读数据来源,处理标准输入,输出 oom 的 时间\进程名\内存\uid
            printf "\t\t\t\t• %-17s %-17s %-17s %s\n\n" "OOM_TIME" "OOM_MOD" "MEM(GB)" "UID"
            if [[ "$oom_source" = "message" ]]; then
                # messages 来源
                cat oom_detail.txt | grep 'Killed process' | tail -n 10 | awk '{
                    "date -d \""$1" "$2" "$3"\" +\"%m-%d %H:%M:%S\"" | getline time; 
                    match($0,/\((.*)\)/,mod); 
                    match($0,"anon-rss:([0-9]*)kB",mem); 
                    match($0, /UID ([0-9]+)/, uid);
                    printf("%-17s %-17s %-17.4f %s\n",time,mod[1],mem[1]/1024/1024,uid[1])
                }' | sed 's/^/\t\t\t\t• /g'
            else
                # dmesg 来源
                cat oom_detail.txt | grep 'Killed process' | tail -n 10 | awk '{
                    "date -d \""$2" "$3" "$4"\" +\"%m-%d %H:%M:%S\"" | getline time; 
                    match($0,/\((.*)\)/,mod); 
                    match($0,"anon-rss:([0-9]*)kB",mem); 
                    match($0, /UID ([0-9]+)/, uid);
                    printf("%-17s %-17s %-17.4f %s\n",time,mod[1],mem[1]/1024/1024,uid[1])
                }' | sed 's/^/\t\t\t\t• /g'
            fi

            # 打印 oom top5 的次数\用户\进程
            line=$(wc -l oom_top5.txt | awk '{print $1}')
            echo -e "\t\t\t• ${YELLOW}最近 30 天 OOM 进程 Top5${RES}"
            printf "\t\t\t\t• %-17s %-17s %s\n\n" "OOM_COUNT" "OOM_MOD" "OOM_USER"
            for ((i = 1; i <= $line; i++)); do
                top_count=$(cat oom_top5.txt | sed -n "$i"p | awk '{print $1}')
                # 判断 top5 的日志中是否有 uid,没有就不输出了
                if [[ "$top_uid" = "true" ]]; then
                    top_user=$(cat oom_top5.txt | sed -n "$i"p | awk '{print $NF}' | xargs -i ssh $host -p $port "id {}" | awk '{print $1}' 2>/dev/null) # ssh 到目标节点查看 uid 对应的用户
                    top_mod=$(cat oom_top5.txt | sed -n "$i"p | awk '{$1="";$NF="";print}')
                    printf "\t\t\t\t• %-17s %-17s %s %s %s %s\n" "${top_count}" "${top_mod}" "${top_user}"
                else
                    top_mod=$(cat oom_top5.txt | sed -n "$i"p | awk '{$1="";print}')
                    printf "\t\t\t\t• %-17s %-17s %s %s %s\n" "${top_count}" "${top_mod}"
                fi
            done
        fi
    done

    if [ "$oom_sum" -eq 0 ]; then
        log_level "INFO" "最近 30 天环境未出现 Out of memory 情况,整体健康"
    elif [ "$oom_sum" -gt 0 ] && [ "$oom_sum" -le 50 ]; then
        log_level "WARN" "最近 30 天环境 Out of memory 总次数: ${RED}${oom_sum}${RES}"
    else
        log_level "ERROR" "最近 30 天环境频繁出现 OOM,内存存在严重瓶颈,Out of memory 总次数: ${RED}${oom_sum}${RES}"
    fi
}

# 输出环境运行内存的相关信息
function memory_detail() {
    log_level "INFO" "环境内存使用详细信息"

    # 根据版本确定 prometheus 是用户级别还是进程级别
    if [[ "$sp_version" = 2.0 ]]; then
        level="用户"
    else
        level="进程"
    fi

    # 定义一个子函数: 打印最近一次 OOM 时间点的系统内存,按照用户分组
    oom_mem_print() {
        # 获取当前节点的最近一次 oom 时间戳 timestamp
        last_oom_timestamp=$(cat oom_timestamp.txt | grep "$host" | awk '{print $2}')

        if [[ $last_oom_timestamp ]]; then
            # promethues 指标采集默认是 15 秒钟一次,所以要在两个时间戳的范围内取值,往前推 60s
            last_oom_before_one_min_timestamp=$(echo "${last_oom_timestamp} - 60" | bc)
            echo -e "\n\t\t\t• 最近一次 OOM 时间点: $(date -d @${last_oom_timestamp} +"%Y-%m-%d %H:%M:%S"),节点${YELLOW}${level}级别${RES}使用的内存:"
            # 用 wget 通过时间戳去调用 prometheus query_range api 获取按用户分组的内存使用,保存到中间文件,用 curl 解析 url 转义有问题,尝试了 offset 等参数都不行,还是需要用 api 中的 timestamp,只能用 wget
            wget -q -O oom_mem_use.txt 'http://'$prometheus_host':8310/api/v1/query_range?query=(sum by(groupname)(namedprocess_namegroup_memory_bytes{memtype="resident",instance="'$host'"}))&start='$last_oom_before_one_min_timestamp'&end='$last_oom_timestamp'&step=10'
            # 用 python 处理数据,获取 json 数据用户分组,再用 awk 格式化
            printf "\t\t\t\t• %-90s %-9s\n\n" "USER" "MEM(GB)"
            cat oom_mem_use.txt |
                python3 -c "import sys, json; data = json.load(sys.stdin); [print(result['metric']['groupname'], result['values'][0][1]) for result in data['data']['result']]" |
                awk '{printf("%-90s %-9.4f\n",$1,$2/1024/1024/1024)}' | sort -nrk2 | sed 's/^/\t\t\t\t• /g'
        else
            echo -e "\n\t\t\t• 最近一次 OOM 时间点: NULL" # 如果没有 oom_timestamp,那后面就不执行了

        fi
    }

    # 定义一个子函数: 打印脚本执行当前时间的系统内存,按照用户分组
    local_mem_print() {
        echo -e "\n\t\t\t• 此刻节点${YELLOW}${level}级别${RES}使用的内存:"
        printf "\t\t\t\t• %-90s %-9s\n\n" "USER" "MEM(GB)"
        # 用 curl 方式调用 prometheus query api 获取按当前时间用户分组的内存使用,然后用 python 处理数据,获取 json 数据用户分组,再用 awk 格式化
        curl -fs --data-urlencode 'query=sum by(groupname)(namedprocess_namegroup_memory_bytes{memtype="resident",instance="'$host'"})' http://${prometheus_host}:8310/api/v1/query |
            python3 -c "import sys, json; data = json.load(sys.stdin); [print(result['metric']['groupname'], result['value'][1]) for result in data['data']['result']]" |
            awk '{printf("%-90s %-9.4f\n",$1,$2/1024/1024/1024)}' | sort -nrk2 | sed 's/^/\t\t\t\t• /g'

        if [[ "$sp_version" = 2.0 ]]; then
            # sp2.0 还只支持用户级别，需要再定义一个子函数获取系统进程级别的内存消耗 TOP10（但是只能打印当前的）
            process_mem_print() {
                # 通过 ps 命令打印当前的内存 Top10
                echo -e "\n\t\t\t• 此刻节点${YELLOW}整体系统进程${RES}使用的内存 ${YELLOW}Top10${RES}:"
                printf "\t\t\t\t• %-90s %-12s %-9s %-10s\n\n" "Process" "USER" "PID" "MEM(GB)"
                ssh $host -p $port "ps -eo user,pid,rss,cmd | sort -nrk3 | head -n 10" | awk '{printf("%-90s %-12s %-9s %-10.2f\n",$NF,$1,$2,$3/1024/1024)}' | sed 's/^/\t\t\t\t• /g'
            }
        fi
    }

    # 定义一个子函数: 打印系统当前 sa_cluster 用户进程内存消耗 Top10
    sensors_process_mem_print() {
        # 通过 ps 命令打印当前的内存 Top10
        echo -e "\n\t\t\t• 此刻节点${YELLOW}sa_cluster 用户进程${RES}使用的内存 ${YELLOW}Top10${RES}:"
        printf "\t\t\t\t• %-90s %-12s %-9s %-10s\n\n" "Process" "USER" "PID" "MEM(GB)"
        ssh $host -p $port "ps -eo user,pid,rss,cmd | grep sa_clus+ | sort -nrk3 | head -n 10" | awk '{printf("%-90s %-12s %-9s %-10.2f\n",$NF,$1,$2,$3/1024/1024)}' | sed 's/^/\t\t\t\t• /g'
    }

    # 定义一个子函数：打印系统当前 spadmin jps (sa_cluster java 进程)
    jps_mem_print() {
        ssh $host -p $port "spadmin jps" 2>/dev/null >oom_jps.txt
        echo -e "\n\t\t\t• 此刻节点${YELLOW} sa_cluster jps java 进程${RES}使用的内存:"
        printf "\t\t\t\t• %-90s %-12s %-9s %-10s\n\n" "Process" "USER" "PID" "MEM(GB)"
        # 存储进程名和 pid 的关联数组
        declare -A process_map
        # 读取文件内容并将进程名和 pid 存储到关联数组中
        jps_line=$(cat oom_jps.txt | grep -v 'Jps' | wc -l)
        if [ "$jps_line" -ne 0 ]; then
            while read -r pid process_name; do
                process_map[$process_name]+=" $pid"
            done <<<"$(grep -v 'Jps' oom_jps.txt)"
        fi
        # 遍历进程名数组，打印每个进程名、pid、用户名以及使用的内存
        for process_name in "${!process_map[@]}"; do
            pids=${process_map[$process_name]}
            for pid in $pids; do
                ssh $host -p $port "ps -p $pid -o user,pid,rss" | awk -v process_name="$process_name" 'NR > 1 {printf("%-90s %-12s %-9s %-10.2f\n",process_name,$1,$2,$3/1024/1024)}' | sed 's/^/\t\t\t\t• /g'
            done
        done | tee oom_process.txt
    }

    # 定义一个字函数,记录每个节点的重复进程
    duplicate_processes() {
        # 输出重复进程到文件
        awk '{print $2}' oom_process.txt | sort | uniq -d | awk 'FNR==NR {seen[$1]; next} $2 in seen' - oom_process.txt | egrep -v 'WorkerMain|CliFrontend' >oom_dup_process.txt
        dup_file=oom_dup_process.txt
        if [ -f "$dup_file" ] && [ -s "$dup_file" ]; then
            log_level "WARN" "检测到 $host 存在重复 java 进程,请核查!"
            printf "\t\t\t\t• %-90s %-12s %-9s %-10s\n\n" "Process" "USER" "PID" "MEM(GB)"
            echo -ne "$YELLOW" && cat oom_dup_process.txt && echo -ne "$RES"
        fi
    }

    for host in $(cat oom_host.txt); do
        # 打印节点信息
        echo -e "\n\t\t• ${YELLOW}${host}${RES}"

        # 打印最近一次 oom 用户内存
        oom_mem_print

        # 打印当前用户 / 进程内存
        local_mem_print

        # sp2.0 打印当前进程内存
        if [[ "$sp_version" = 2.0 ]]; then
            process_mem_print
        fi

        # 打印当前 sa_cluster 用户进程 Top10
        sensors_process_mem_print

        # 打印 jps 内存占用
        jps_mem_print

        # 输出重复进程
        duplicate_processes
    done
}

# 获取机器物理内存并进行修正
function get_physical_memory() {
    # 判断是否是单机,集群取 impalad 节点的物理内存
    if [[ "$is_standalone" = "true" ]]; then
        physical_memory=$(free -g | sed -n 2p | awk '{print $2}') # 单机物理内存
    else
        physical_memory=$(ssh ${impalad_host} -p ${port} "free -g" 2>/dev/null | sed -n 2p | awk '{print $2}') # 集群取 impalad 节点内存
    fi

    # 内存修正成常见数值
    if [ "$physical_memory" -lt 28 ]; then
        echo -e "${RED}----- physical memory is too low,only ${physical_memory}G !!!${RES}" && exit
    elif [ "$physical_memory" -ge 28 ] && [ "$physical_memory" -le 33 ]; then
        revise_memory=32
    elif [ "$physical_memory" -ge 60 ] && [ "$physical_memory" -le 65 ]; then
        revise_memory=64
    elif [ "$physical_memory" -ge 91 ] && [ "$physical_memory" -le 97 ]; then
        revise_memory=96
    elif [ "$physical_memory" -ge 120 ] && [ "$physical_memory" -le 129 ]; then
        revise_memory=128
    elif [ "$physical_memory" -ge 249 ] && [ "$physical_memory" -le 257 ]; then
        revise_memory=256
    else
        revise_memory=$physical_memory
    fi
}

# 将平均日导入和服务器推荐配置做对比
function data_comparison() {
    log_level "INFO" "导入相关信息\n"

    # 打印最近 7 天的日导入
    echo -e "\t\t• 环境导入模式: ${GREEN}${sdf_loader_mode}${RES},最近 7 天日导入如下:"
    impala-shell -i ${impalad_host} -d rawdata --quiet -B --output_delimiter="\t" -q "select day_to_date(day), sum(send) from track_statistic group by 1 order by 1;" >>oom_data_input.txt 2>/dev/null
    cat oom_data_input.txt | sed 's/^/\t\t\t• /g' | tail -n 8
    echo -e "\t\t• 最近 7 天平均日导入量 ${YELLOW}${daily_loader_data_num}${RES}"
    # 物理内存不能低于 64G
    if [ "$physical_memory" -lt 60 ]; then
        echo -e "\t\t• 服务器物理内存至少需要 ${RES}64G${RES}"
    fi

    # 根据不同的日导入量级推荐内存大小
    if [[ "$is_standalone" = "true" ]]; then                                                           # 云版和单机跟推荐配置做对比
        if [ "$daily_loader_data_num" -ge 8000000 ] && [ "$daily_loader_data_num" -le 20000000 ]; then # 日导入 800 万到 1000 万,物理内存必须 128G
            if [ "$physical_memory" -lt 120 ]; then
                echo -e "\t\t• 单机导入量级 [800 万 - 2000 万]，服务器物理内存至少需要 ${RED}128G${RES}"
            fi
        elif [ "$daily_loader_data_num" -gt 20000000 ]; then # 日导入 1000 万以上,建议迁移集群
            echo -e "\t\t• 单机日导入量级 > 2000 万,建议迁移集群"
        fi
    else # 集群跟推荐配置做对比
        if [[ "$is_minicluster" = "true" ]]; then
            if [ "$daily_loader_data_num" -gt 60000000 ] && [ "$daily_loader_data_num" -le 100000000 ]; then # 日导入大于 6000 万,判断日导入 1 亿以下,物理内存必须 128G
                if [ "$physical_memory" -lt 120 ]; then
                    echo -e "\t\t• 日导入量级 0.6-1 亿,服务器物理内存至少需要 ${RED}128G${RES}"
                fi
            elif [ "$daily_loader_data_num" -ge 100000000 ]; then
                echo -e "\t\t• Mini 集群日导入量级 > 1 亿,建议迁移标准集群"
            fi
        else                                        # 不是 mini 集群也不是单机，那判断是标准集群
            if [ "$physical_memory" -lt 120 ]; then # 标准集群的内存必须大于 128G,暂时不做更细的划分
                echo -e "\t\t• 标准集群服务器物理内存至少需要 ${RED}128G${RES}"
            fi
        fi
    fi
}

# 根据机器类型和内存大小预定义大数据组件默认内存
function hadoop_memory_define() {
    # 根据单机还是集群预定义初始内存
    if [[ "$is_standalone" = "true" ]]; then
        # 单机配置
        # impalad 部署完预定内存大小,mem/4
        impalad_mem_define_gb=$(echo "scale=0; ${revise_memory}/4" | bc)

        # impalad jvm 内存,部署完预定内存大小,mem/4
        impalad_jvm_define_gb=$(echo "scale=0; ${revise_memory}/4" | bc)

        # kudu tserver 部署完预定内存大小,mem/4
        tserver_mem_define_gb=$(echo "scale=0; ${revise_memory}/4" | bc)

        # kafka broker 部署完预定内存大小,单机固定 1G
        kafka_mem_define_gb=1

        # hdfs namenode 部署完预定内存大小，单机固定 512M
        namenode_mem_define_gb=0.5
    else
        # 集群配置
        # mini 集群,namenode 4G,标准集群 0G
        if [[ "$is_minicluster" = "true" ]]; then
            namenode_mem_define_gb=4
        else
            namenode_mem_define_gb=0
        fi

        # impalad 部署完预定内存大小,没有固定规则,不同内存大小给的值不同，只能 if 多基层判断
        if [ "$revise_memory" -eq 32 ]; then
            impalad_mem_define_gb=16
        elif [ "$revise_memory" -eq 64 ]; then
            impalad_mem_define_gb=24
        elif [ "$revise_memory" -eq 96 ]; then
            impalad_mem_define_gb=36
        elif [ "$revise_memory" -ge 128 ]; then
            impalad_mem_define_gb=50
        fi

        # impalad jvm 内存,部署完预定内存大小,mem/4
        impalad_jvm_define_gb=$(echo "scale=0; ${revise_memory}/4" | bc)

        # kudu tserver 部署完预定内存大小, <=70G mem=6G, >70G mem=12G
        if [ "$revise_memory" -le 70 ]; then
            tserver_mem_define_gb=6
        else
            tserver_mem_define_gb=12
        fi

        # yarn 部署完预定 resource memory 大小, mem*6/16
        yarn_mem_define_gb=$(echo "scale=0; ${revise_memory}*6/16" | bc)

        # kafka broker 部署完预定内存大小,集群固定 1.5G
        kafka_mem_define_gb=1.5
    fi

}

# 获取环境当前配置的大数据组件内存
function hadoop_memory_config() {
    # impalad
    impalad_mem=$(curl -s $impalad_host:25000/varz?json | grep -w -A 5 '"mem_limit"' | grep current | awk -F '"' '{print $4}')
    impalad_service_num=$(ssh $impalad_host -p $port "sudo ps -ef | grep beeswax" | grep impala | wc -l)
    impalad_mem_single_config_gb=$(echo "${impalad_mem} ${divisor}" | awk '{print $1/$2}')
    impalad_mem_config_gb=$(echo "${impalad_mem_single_config_gb} ${impalad_service_num}" | awk '{print $1*$2}')

    # impalad jvm
    impalad_jvm_single_config_gb=$(curl -s $impalad_host:25000/metrics | grep "jvm.heap.max-usage-bytes" -A 5 | tail -n 1 | sed -e 's/^ *//' | awk '{print $1}')
    impalad_jvm_config_gb=$(echo "${impalad_jvm_single_config_gb} ${impalad_service_num}" | awk '{print $1*$2}')

    # kudu tserver
    tserver_mem=$(curl ${tserver_host}:8050/varz 2>/dev/null | grep memory_limit_hard_bytes | awk -F "=" '{print $2}')
    tserver_mem_config_gb=$(echo "${tserver_mem} ${divisor}" | awk '{print $1/$2}')

    # yarn nodemanager resource memory,单机 yarn 不启动,不取值
    if [[ "$is_standalone" != "true" ]]; then
        yarn_mem=$(curl -s $yarn_nodemanager_host/ws/v1/node/info | python3 -m json.tool | grep totalPmemAllocatedContainersMB | awk '{print $2}' | sed 's/,$//g')
        yarn_mem_config_gb=$(echo "${yarn_mem} 1024" | awk '{print $1/$2}')
    else
        yarn_mem_config_gb=0
    fi

    # kafka broker
    kafka_mem=$(ssh $kafka_broker_host -p $port "ps -ef | egrep 'kafka.properties|server.properties|kafka/bin'" | grep Xmx | awk -F 'Xmx' '{print $2}' | awk '{print $1}' | sed 's/.$//g')
    kafka_mem_config_gb=$(echo "${kafka_mem} 1024" | awk '{print $1/$2}')

    # hdfs namenode,集群 namenode 在元数据节点,不取值
    if [[ "$is_standalone" = "true" ]]; then
        namenode_mem=$(ssh $hdfs_namenode_host -p $port "ps -ef | grep namenode.NameNode" | grep Xmx | awk -F 'Xmx' '{print $2}' | awk '{print $1}' | sed 's/.$//g')
        namenode_mem_config_gb=$(echo "${namenode_mem} 1024" | awk '{print $1/$2}')
    else
        # mini 集群,需要统计 namenode,标准集群值给 0
        if [[ "$is_minicluster" = "true" ]]; then
            namenode_mem=$(ssh $hdfs_namenode_host -p $port "ps -ef | grep namenode.NameNode" | grep Xmx | awk -F 'Xmx' '{print $2}' | awk '{print $1}' | sed 's/.$//g')
            namenode_mem_config_gb=$(echo "${namenode_mem} 1024" | awk '{print $1/$2}')
        else
            namenode_mem_config_gb=0
        fi
    fi
}

# 根据机器类型和内存大小预定义基础组件默认内存
function sensors_memory_define() {
    # 常见组件内存
    sa_web_mem_define_mb=2048
    sbp_web_mem_define_mb=512
    sps_web_mem_define_mb=512
    sdg_web_mem_define_mb=512
    srp_web_mem_define_mb=512
    sat_web_mem_define_mb=512
    ex_mem_define_mb=512
    redis_mem_define_mb=$(echo "scale=0; ${revise_memory}/8*512" | bc)
    skv_mem_define_gb=$(echo "scale=0; ${physical_memory}/28" | bc)
    if [[ "$is_standcluster" = "true" ]]; then
        sca_cloudatlas_mem_define_mb=576
    else
        sca_cloudatlas_mem_define_mb=1024
    fi
}

# 获取环境当前配置的基础组件内存
function sensors_memory_config() {
    # 产品组件列表
    moudle_list=$(python3 -c 'from hyperion_client.deploy_topo import DeployTopo;print(DeployTopo().get_product_name_list())')
    # 不区分版本的只有 redis，通过配置文件获取
    redis_mem_config_mb=$(cat $SENSORS_PLATFORM_HOME/redis/conf/redis_6178.conf | awk '/^maxmemory / {print}' | awk '{print $2}' | sed 's/.$//g')
    # 其他产品线都要区分 sp2.0 / sp2.1
    if [[ "$sp_version" = 2.0 ]]; then
        # sp2.0 提供了统一接口获取,如果默认没有值,可能获取不到,还要做个判断
        sa_web_mem_config_mb=$($sp_cmd config get server -m web -p sa -n mem_mb -c -d 2048 2>/dev/null)
        sbp_web_mem_config_mb=$($sp_cmd config get server -m web -p sbp -n mem_mb -c -d 512 2>/dev/null)
        sps_web_mem_config_mb=$($sp_cmd config get server -m web -p sps -n mem_mb -c -d 512 2>/dev/null)
        sdg_web_mem_config_mb=$($sp_cmd config get server -m web -p sdg -n mem_mb -c -d 512 2>/dev/null)
        ex_mem_config_mb=$($sp_cmd config get server -m extractor -p sdf -n mem_mb -c -d 512 2>/dev/null)
        skv_mem_config_gb=$($sp_cmd skv config show -m skv_offline -r replica_server 2>&1 | grep rocksdb_block_cache_capacity | head -n 1 | awk '{print $3}' | xargs -i echo "{} ${divisor}" | awk '{print $1/$2}')

        # 报表
        echo $moudle_list | grep "blitzreport" >/dev/null 2>&1
        if [[ "$?" = 0 ]]; then
            srp_web_mem_config_mb=$($sp_cmd config get server -m web -p blitzreport -n mem_mb -c -d 512 2>/dev/null)
        else
            srp_web_mem_config_mb=0
        fi

        # 广告
        echo $moudle_list | grep "advertising-management" >/dev/null 2>&1
        if [[ "$?" = 0 ]]; then
            sat_web_mem_config_mb=$($sp_cmd config get server -m web -p advertising-management -n mem_mb -c -d 512 2>/dev/null)
        else
            sat_web_mem_config_mb=0
        fi

        # sca cloudatlas Xmx 内存，单机默认 576m,集群 1024m
        if [[ "$is_standcluster" = "true" ]]; then
            sca_cloudatlas_mem_config_mb=$($sp_cmd config get server -m cloudatlas -p sca -n mem_mb -c -d 576 2>/dev/null)
        else
            sca_cloudatlas_mem_config_mb=$($sp_cmd config get server -m cloudatlas -p sca -n mem_mb -c -d 1024 2>/dev/null)
        fi
    else
        # sp2.1 环境没提供统一的接口，jvm Xmx 内存都只能通过 aradmin ss get 获取，获取出来的值 * 0.75 才是实际配置的值
        sa_web_mem_config_mb=$(echo "scale=0; $(aradmin ss get -p sa -m web -r web -n mem_limit -w json 2>&1 | grep value | awk -F '"' '{print $4}' | sed 's/Mi//') * 3 / 4" | bc)
        sbp_web_mem_config_mb=$(echo "scale=0; $(aradmin ss get -p sbp -m web -r web -n mem_limit -w json 2>&1 | grep value | awk -F '"' '{print $4}' | sed 's/Mi//') * 3 / 4" | bc)
        sps_web_mem_config_mb=$(echo "scale=0; $(aradmin ss get -p sps -m web -r web -n mem_limit -w json 2>&1 | grep value | awk -F '"' '{print $4}' | sed 's/Mi//') * 3 / 4" | bc)
        sdg_web_mem_config_mb=$(echo "scale=0; $(aradmin ss get -p sdg -m web -r web -n mem_limit -w json 2>&1 | grep value | awk -F '"' '{print $4}' | sed 's/Mi//') * 3 / 4" | bc)
        ex_mem_config_mb=$(echo "scale=0; $(aradmin ss get -p sdf -m extractor -r extractor -n mem_limit -w json 2>&1 | grep value | awk -F '"' '{print $4}' | sed 's/Mi//') * 3 / 4" | bc)
        skv_mem_config_gb=$(mothershipadmin config search -m skv_offline -r replica_server -k rocksdb_block_cache_capacity 2>&1 | grep rocksdb_block_cache_capacity | awk '{print $(NF-1)}' | xargs -i echo "{} ${divisor}" | awk '{print $1/$2}')
        sca_cloudatlas_mem_config_mb=$(echo "scale=0; $(aradmin ss get -p sca -m cloudatlas -r cloudatlas -n mem_limit -w json 2>&1 | grep value | awk -F '"' '{print $4}' | sed 's/Mi//') * 3 / 4" | bc)

        # 报表
        echo $moudle_list | grep "blitzreport" >/dev/null 2>&1
        if [[ "$?" = 0 ]]; then
            srp_web_mem_config_mb=$(echo "scale=0; $(aradmin ss get -p blitzreport -m web -r web -n mem_limit -w json 2>&1 | grep value | awk -F '"' '{print $4}' | sed 's/Mi//') * 3 / 4" | bc)
        else
            srp_web_mem_config_mb=0
        fi

        # 广告
        echo $moudle_list | grep "advertising-management" >/dev/null 2>&1
        if [[ "$?" = 0 ]]; then
            sat_web_mem_config_mb=$(echo "scale=0; $(aradmin ss get -p advertising-management -m web -r web -n mem_limit -w json 2>&1 | grep value | awk -F '"' '{print $4}' | sed 's/Mi//') * 3 / 4" | bc)
        else
            sat_web_mem_config_mb=0
        fi
    fi

}

# 通过 promethues 获取组件过去七天的内存信息，需要引入一个 python 脚本
function get_prometheus_jmv_used() {
    cat >get_jvm.py <<EOF
import urllib.request
import urllib.parse
import json
from datetime import datetime, timedelta
from hyperion_client.deploy_topo import DeployTopo
import pdb

# 获取 prometheus 主机名
prometheus_list = DeployTopo().get_host_list_by_module_name('sm', 'prometheus')
prometheus_host = prometheus_list[0]

def get_prometheus():
    # 当前时间戳
    current_timestamp = int(datetime.timestamp(datetime.now()))
    # 1 天前的时间戳
    past_seven_day_timestamp = current_timestamp - 86400
    # 请求的基础 url
    baseurl = "http://" + prometheus_host + ":8310/api/v1/query_range?"
    # 请求的开始时间，取 7 天前的时间戳 
    start_time = str(past_seven_day_timestamp)
    # 请求结束的时间，取当前时间戳
    end_time = str(current_timestamp)
    # step 取值周期,暂定 60s
    step = "3600"

    # sa jvm url
    sa_web_jvm_url = baseurl + "query=(sum(jvm_memory_used_bytes{job='sa-web',area='heap'})by(instance))&start=" + start_time + "&end=" + end_time + "&step=" + step

    # sps jvm url
    sps_web_jvm_url = baseurl + "query=(sum(jvm_memory_used_bytes{job='SPS-web',area='heap'})by(instance))&start=" + start_time + "&end=" + end_time + "&step=" + step

    # sbp jvm url
    sbp_web_jvm_url = baseurl + "query=(sum(jvm_memory_used_bytes{job='sbp-web',area='heap'})by(instance))&start=" + start_time + "&end=" + end_time + "&step=" + step

    # skv_replica_server url
    replica_server_url = baseurl + "query=(replica_server_memused_res_MB_{inf_role_name='replica_server'})&start=" + start_time + "&end=" + end_time + "&step=" + step

    def get_url_json(url):
        response = urllib.request.urlopen(url)
        if response.status == 200:
            data = response.read().decode()
            json_data = json.loads(data)
        return json_data
            

    # 调用 url 获取数据
    sa_jvm_json_data = get_url_json(sa_web_jvm_url)
    sps_jvm_json_data = get_url_json(sps_web_jvm_url)
    sbp_jvm_json_data = get_url_json(sbp_web_jvm_url)
    replica_server_json_data = get_url_json(replica_server_url)

    # 录入一个大的字典
    get_jvm_messages = {
            "sa_jvm_json": sa_jvm_json_data,
            "sps_jvm_json": sps_jvm_json_data,
            "sbp_jvm_json": sbp_jvm_json_data,
            "replica_server_json": replica_server_json_data
    }

    # 存储结果的字典
    results = {}

    for key,json_data in get_jvm_messages.items():
        # 创建一个字典来存储每个节点的最大值
        node_max_values = {}
        # 遍历每个 "result" 对象中的 "values" 列表
        for result in json_data['data']['result']:
            if "replica" in key:
                instance = result['metric']['host_name']
            else: 
                instance = result['metric']['instance']
            for value in result['values']:
                memory_used = int(value[1])
                if instance not in node_max_values or memory_used > node_max_values[instance]:
                    node_max_values[instance] = memory_used
        
            max_value = max(node_max_values.values())
            if "replica" in key:
                max_value_mb = round((max_value / 1024), 2)
            else:
                max_value_mb = max_value // 1024 ** 2
            max_node = [instance for instance, value in node_max_values.items() if value == max_value][0]

            # 记录结果到字典
            results[key] = {
                "max_value": max_value_mb,
                "max_node": max_node
            }

    for key, value in results.items():
        print(f"{key} {value['max_node']} {value['max_value']}")

get_prometheus()
EOF
    python3 get_jvm.py >oom_get_jvm.txt 2>/dev/null
    sa_web_mem_max_value=$(cat oom_get_jvm.txt | grep "sa_jvm_json" | awk '{print $3}')
    sa_web_mem_max_node=$(cat oom_get_jvm.txt | grep "sa_jvm_json" | awk '{print $2}')
    sps_web_mem_max_value=$(cat oom_get_jvm.txt | grep "sps_jvm_json" | awk '{print $3}')
    sps_web_mem_max_node=$(cat oom_get_jvm.txt | grep "sps_jvm_json" | awk '{print $2}')
    sbp_web_mem_max_value=$(cat oom_get_jvm.txt | grep "sbp_jvm_json" | awk '{print $3}')
    sbp_web_mem_max_node=$(cat oom_get_jvm.txt | grep "sbp_jvm_json" | awk '{print $2}')
    replica_server_mem_max_value=$(cat oom_get_jvm.txt | grep "replica_server_json" | awk '{print $3}')
    replica_server_mem_max_node=$(cat oom_get_jvm.txt | grep "replica_server_json" | awk '{print $2}')
}

# 输出配置
function print_config() {
    log_level "INFO" "模块配置输出\n"

    # 输出环境所有组件内存之和
    # senors 的放一起,区分单机 mini集群 标准集群
    if [[ "$is_standcluster" = "true" ]]; then
        # 标准集群数据节点神策组件只有 extractor
        sensors_mem_config_sum=$(echo "$ex_mem_config_mb / 1024" | bc)
        # hadoop 的放一起,skv 也算存储归纳到这里,单位都是 gb 方便计算,标准集群 namenode 在元数据节点，不纳入计算
        hadoop_mem_config_sum=$(echo "$impalad_mem_config_gb + $impalad_jvm_config_gb + $tserver_mem_config_gb + $yarn_mem_config_gb + $kafka_mem_config_gb + $skv_mem_config_gb" | bc)
    else
        # 单机和 mini 集群,神策组件每个节点都有
        sensors_mem_config_sum=$(echo "$(echo "$sa_web_mem_config_mb + $sbp_web_mem_config_mb + $sps_web_mem_config_mb + $sdg_web_mem_config_mb + $srp_web_mem_config_mb + $sat_web_mem_config_mb + $ex_mem_config_mb + $redis_mem_config_mb + $sca_cloudatlas_mem_config_mb" | bc) / 1024" | bc)
        # hadoop 的放一起,skv 也算存储归纳到这里,单位都是 gb 方便计算
        hadoop_mem_config_sum=$(echo "$impalad_mem_config_gb + $impalad_jvm_config_gb + $tserver_mem_config_gb + $yarn_mem_config_gb + $kafka_mem_config_gb + $namenode_mem_config_gb + $skv_mem_config_gb" | bc)
    fi
    # hadoop 和 sensors 的配置内存一起求和
    system_mem_config_sum=$(echo "$hadoop_mem_config_sum + $sensors_mem_config_sum" | bc)

    if [[ "$is_standalone" = "true" ]]; then
        echo -e "\t\t• 服务器物理内存大小: ${GREEN}${physical_memory}G${RES}"
        echo -e "\t\t• 服务器所有组件配置总内存大小约为: ${YELLOW}${system_mem_config_sum}G${RES}\n"
    else
        echo -e "\t\t• 数据节点物理内存大小: ${GREEN}${physical_memory}G${RES}"
        echo -e "\t\t• 数据节点所有组件配置总内存大小约为: ${YELLOW}${system_mem_config_sum}G${RES}\n"
    fi

    # 预编辑每个模块的标准输出
    print_impala="\t\t• Impalad 标准配置为: ${GREEN}${impalad_mem_define_gb}G${RES}\t\t环境配置实例个数: ${YELLOW}${impalad_service_num}${RES}\t单实例配置为: ${YELLOW}${impalad_mem_single_config_gb}G${RES}\t单节点实际配置为: ${YELLOW}${impalad_mem_config_gb}G${RES}"
    print_impalad_jvm="\t\t• Impalad Jvm 标准配置为: ${GREEN}${impalad_jvm_define_gb}G${RES}\t\t环境配置实例个数: ${YELLOW}${impalad_service_num}${RES}\t单实例配置为: ${YELLOW}${impalad_jvm_single_config_gb}G${RES}\t单节点实际配置为: ${YELLOW}${impalad_jvm_config_gb}G${RES}"
    print_kudu="\t\t• Kudu Tserver 标准配置为: ${GREEN}${tserver_mem_define_gb}G${RES}\t\t实际配置为: ${YELLOW}${tserver_mem_config_gb}G${RES}"
    print_yarn="\t\t• Yarn Resource Memory 标准配置为: ${GREEN}${yarn_mem_define_gb}G${RES}\t实际配置为: ${YELLOW}${yarn_mem_config_gb}G${RES}"
    print_kafka="\t\t• Kafka Heap 标准配置为: ${GREEN}${kafka_mem_define_gb}G${RES}\t\t实际配置为: ${YELLOW}${kafka_mem_config_gb}G${RES}"
    print_hdfs="\t\t• Hdfs Namenode Heap 标准配置为: ${GREEN}${namenode_mem_define_gb}G${RES}\t实际配置为: ${YELLOW}${namenode_mem_config_gb}G${RES}"
    print_sa="\t\t• SA Web 标准配置为: ${GREEN}${sa_web_mem_define_mb}M${RES}\t\t实际配置为: ${YELLOW}${sa_web_mem_config_mb}M${RES}\t最近 7 天 SA web 最大运行内存: ${YELLOW}${sa_web_mem_max_value}M${RES},对应节点: ${YELLOW}${sa_web_mem_max_node}${RES}"
    print_sbp="\t\t• SBP Web 标准配置为: ${GREEN}${sbp_web_mem_define_mb}M${RES}\t\t实际配置为: ${YELLOW}${sbp_web_mem_config_mb}M${RES}\t最近 7 天 SBP web 最大运行内存: ${YELLOW}${sbp_web_mem_max_value}M${RES},对应节点: ${YELLOW}${sbp_web_mem_max_node}${RES}"
    print_sps="\t\t• SPS Web 标准配置为: ${GREEN}${sps_web_mem_define_mb}M${RES}\t\t实际配置为: ${YELLOW}${sps_web_mem_config_mb}M${RES}\t最近 7 天 SPS web 最大运行内存: ${YELLOW}${sps_web_mem_max_value}M${RES},对应节点: ${YELLOW}${sps_web_mem_max_node}${RES}"
    print_sdg="\t\t• SDG Web 标准配置为: ${GREEN}${sdg_web_mem_define_mb}M${RES}\t\t实际配置为: ${YELLOW}${sdg_web_mem_config_mb}M${RES}"
    print_srp="\t\t• Blitzreport Web 标准配置为: ${GREEN}${srp_web_mem_define_mb}M${RES}\t实际配置为: ${YELLOW}${srp_web_mem_config_mb}M${RES}"
    print_sat="\t\t• Sat Web 标准配置为: ${GREEN}${sat_web_mem_define_mb}M${RES}\t实际配置为: ${YELLOW}${sat_web_mem_config_mb}M${RES}"
    print_sca="\t\t• Sca Cloudatlas 标准配置为: ${GREEN}${sca_cloudatlas_mem_define_mb}M${RES}\t实际配置为: ${YELLOW}${sca_cloudatlas_mem_config_mb}M${RES}"
    print_ex="\t\t• Extractor 标准配置为: ${GREEN}${ex_mem_define_mb}M${RES}\t\t实际配置为: ${YELLOW}${ex_mem_config_mb}M${RES}"
    print_redis="\t\t• Redis 标准配置为: ${GREEN}${redis_mem_define_mb}M${RES}\t\t实际配置为: ${YELLOW}${redis_mem_config_mb}M${RES}"
    print_skv="\t\t• Skv_replica_server 标准配置为: ${GREEN}${skv_mem_define_gb}G${RES}\t实际配置为: ${YELLOW}${skv_mem_config_gb}G${RES}\t最近 7 天 replica_server 最大运行内存: ${YELLOW}${replica_server_mem_max_value}G${RES},对应节点: ${YELLOW}${replica_server_mem_max_node}${RES}"

    # 输出每个模块的内存配置
    echo -e "${print_impala}\n${print_impalad_jvm}\n${print_kudu}\n${print_kafka}"
    if [[ "$is_standalone" = "true" ]]; then
        echo -e "${print_hdfs}"
    else
        # mini 集群要统计 namenode
        if [[ "$is_minicluster" = "true" ]]; then
            echo -e "${print_hdfs}"
        fi
        echo -e "${print_yarn}"
    fi
    echo -e "${print_sa}\n${print_sbp}\n${print_sps}\n${print_sdg}\n${print_sca}"
    if [ $srp_web_mem_config_mb -ne 0 ]; then
        echo -e "${print_srp}"
    fi
    if [ $sat_web_mem_config_mb -ne 0 ]; then
        echo -e "${print_sat}"
    fi
    echo -e "${print_ex}\n${print_redis}\n${print_skv}"
    # 下个函数进行数据对比，耗时较长，给出提示
    log_level "INFO" "正在进行内存超配组件配置输出及对比,请等待"
}

# 组件配置内存和预定义内存对比
function memory_comparison() {
    declare -a hadoop_modules
    declare -a sensors_modules

    #namenode
    if [ $(echo "$namenode_mem_config_gb > $namenode_mem_define_gb" | bc) -eq 1 ]; then
        hadoop_modules+=(HDFS)
    fi

    # impalad
    if [ $(echo "$impalad_mem_config_gb > $impalad_mem_define_gb" | bc) -eq 1 ]; then
        hadoop_modules+=(IMPALAD)
    fi
    # impalad jvm
    if [ $(echo "$impalad_jvm_config_gb > $impalad_jvm_define_gb" | bc) -eq 1 ]; then
        hadoop_modules+=(IMPALAD_JVM)
    fi

    # kudu tserver
    if [ $(echo "$tserver_mem_config_gb > $tserver_mem_define_gb" | bc) -eq 1 ]; then
        hadoop_modules+=(KUDU)
    fi
    # yarn nodemanager resource memory
    if [[ "$is_standalone" != "true" ]]; then
        if [ $(echo "$yarn_mem_config_gb > $yarn_mem_define_gb" | bc) -eq 1 ]; then
            hadoop_modules+=(YARN)
        fi
    fi
    # 常见各种 web 的内存对比
    if [ $(echo "$sa_web_mem_config_mb > $sa_web_mem_define_mb" | bc) -eq 1 ]; then
        sensors_modules+=(SA)
    fi
    if [ $(echo "$sbp_web_mem_config_mb > $sbp_web_mem_define_mb" | bc) -eq 1 ]; then
        sensors_modules+=(SBP)
    fi
    if [ $(echo "$sps_web_mem_config_mb > $sps_web_mem_define_mb" | bc) -eq 1 ]; then
        sensors_modules+=(SPS)
    fi
    if [ $(echo "$sdg_web_mem_config_mb > $sdg_web_mem_define_mb" | bc) -eq 1 ]; then
        sensors_modules+=(SDG)
    fi
    if [ $(echo "$sca_cloudatlas_mem_config_mb > $sca_cloudatlas_mem_define_mb" | bc) -eq 1 ]; then
        sensors_modules+=(SCA)
    fi
    # 报表广告 web 内存对比
    if [ $srp_web_mem_config_mb ]; then
        if [ $(echo "$srp_web_mem_config_mb > $srp_web_mem_define_mb" | bc) -eq 1 ]; then
            sensors_modules+=(SRP)
        fi
    fi
    if [ $sat_web_mem_config_mb ]; then
        if [ $(echo "$sat_web_mem_config_mb > $sat_web_mem_define_mb" | bc) -eq 1 ]; then
            sensors_modules+=(SAT)
        fi
    fi
    # ex redis skv
    if [ $(echo "$ex_mem_config_mb > $ex_mem_define_mb" | bc) -eq 1 ]; then
        sensors_modules+=(EXTRACTOR)
    fi
    if [ $(echo "$redis_mem_config_mb > $redis_mem_define_mb" | bc) -eq 1 ]; then
        sensors_modules+=(REDIS)
    fi
    if [ $(echo "$skv_mem_config_gb > $skv_mem_define_gb" | bc) -eq 1 ]; then
        sensors_modules+=(SKV)
    fi
    # 列表的值赋给变量
    hadoop_oom_mod=$(echo -e "${hadoop_modules[*]}")
    sensors_oom_mod=$(echo -e "${sensors_modules[*]}")
}

# 分析超配的可能原因
function impala_reason() {
    # 1、可能项目过多
    if [ "$project_num" -gt 5 ]; then
        echo -e "\t\t\t• 环境项目较多,项目数: ${YELLOW}${project_num}${RES} > 5"
    fi

    # 2、单个项目书签数量 > 1000
    for project in ${project_all}; do
        dashboard_item_num=$(sa_mysql -Ne "use metadata;select count(1) from dashboard_item where dashboard_id in (select id from dashboard where project_id = (select id from project where name = '${project}'));")
        if [ "$dashboard_item_num" -gt 1000 ]; then
            echo -e "\t\t\t• ${YELLOW}${project}${RES} 项目书签数量较多,书签数: ${YELLOW}${dashboard_item_num}${RES} > 1000"
        fi
    done

    # 3、查询超过 30 天书签占比
    all_dashboard_item_num=$(sa_mysql -Ne "use metadata;select count(1) from dashboard_item;")
    bookmark_30_num=$(python3 bookmark_time_30.py)
    bookmark_30_percent=$(echo "scale=0; ${bookmark_30_num}*100/${all_dashboard_item_num}" | bc)
    if [ "$bookmark_30_percent" -gt 20 ]; then
        echo -e "\t\t\t• 查询范围超过 30 天的书签较多,书签数: ${YELLOW}${bookmark_30_num}${RES},占比 ${YELLOW}${bookmark_30_percent}%${RES} > 20%"
    fi

    # 4、例行分群数量过多
    for project in ${project_all}; do
        routine_user_tag_num=$(sa_mysql -Ne "use metadata;select count(1) from sp_user_tag where is_routine = 1 and project_id = (select id from project where name = '${project}');")
        if [ "$routine_user_tag_num" -gt 200 ]; then
            echo -e "\t\t\t• ${YELLOW}${project}${RES} 项目例行分群数量较多,例行分群数: ${YELLOW}${routine_user_tag_num}${RES} > 200"
        fi
    done

    # 5、取查询 top30
    impala-shell -i ${impalad_host} --quiet -q "invalidate metadata workload_query;"
    echo -e "\t\t\t• 最近 30 天查询耗时 Top30 的 sql 保存在当前目录下 ${GREEN}query_time30.log${RES}"
    echo -e "\t\t\t• 最近 30 天查询内存消耗 Top30 的 sql 保存在当前目录下 ${GREEN}query_mem30.log${RES}"
    impala-shell -i ${impalad_host} --quiet -q "select sql,user,start_time,end_time,concat(cast(round(duration / 1000 / 60) as string),' 分钟') as query_time,concat(cast(round(per_node_peak_memory / 1024 / 1024 / 1024) as string),' GB(s)') as query_memory,query_state,functional_module,workload_query_desc from workload_query  where day > ${dayago_30} and user != 'NULL' order by duration desc limit 30;" -B --output_delimiter="\t" --print_header -o query_time30.log
    impala-shell -i ${impalad_host} --quiet -q "select sql,user,start_time,end_time,concat(cast(round(duration / 1000 / 60) as string),' 分钟') as query_time,concat(cast(round(per_node_peak_memory / 1024 / 1024 / 1024) as string),' GB(s)') as query_memory,query_state,functional_module,workload_query_desc from workload_query  where day > ${dayago_30} and user != 'NULL' order by per_node_peak_memory desc limit 30;" -B --output_delimiter="\t" --print_header -o query_mem30.log

    # 6、推荐所有 impala oom 时间点的大查询 profile,然后走查询优化工单
    impala_oom_time=$(date -d "$(cat oom_impala_time.txt | tail -n 1)" "+%Y-%m-%d %H:%M:%S")
    if [[ $impala_oom_time ]]; then
        echo -e "\t\t\t• $impala_oom_time 出现 impala oom, 参考处理: https://doc.sensorsdata.cn/pages/viewpage.action?pageId=150862621#id-%E6%9F%A5%E8%AF%A2%E6%8A%A5%E9%94%99%E9%97%AE%E9%A2%98%E6%B1%87%E6%80%BB-%E7%B3%BB%E7%BB%9FOOM"
    fi
}

function kudu_reason() {
    # 1、可能项目过多
    if [ "$project_num" -gt 5 ]; then
        echo -e "\t\t\t• 环境项目较多,项目数: ${YELLOW}${project_num}${RES} > 5"
    fi

    # 2、kudu 文件数和大小检测
    # 单节点 tserver metadata 最大文件数量
    for host in $kudu_tserver; do
        tserver_dirs=$(ssh $host -p $port "curl 127.0.0.1:8050/varz 2>/dev/null" 2>/dev/null | grep fs_data_dirs= | awk -F'=' '{print $2}')
        tserver_data_dirs=$(echo ${tserver_dirs} | tr "," "\n")
        # 统计一个 tserver 节点的 metadata 文件总和
        metadata_file_sum=0
        metadata_size_sum=0
        for dir in $tserver_data_dirs; do
            tserver_file_num=$(ssh $host -p $port "sudo ls -l $dir/data/ | wc -l" 2>/dev/null)
            metadata_file_num=$(echo "scale=0; $tserver_file_num/2" | bc)
            # 单个目录的 meta 大小近似计算
            if [ "$metadata_file_num" -le 20000 ]; then
                dir_meta_size=$(sudo find $dir/data -iname "*.metadata" | xargs -n 20000 sudo du -scm | tail -n 1 | awk '{print $1}')
            else
                meta_num_percent=$(echo "scale=0; 20000*100/${metadata_file_num}" | bc)
                dir_meta_similar_size=$(sudo find $dir/data -iname "*.metadata" | xargs -n 20000 sudo du -scm | tail -n 1 | awk '{print $1}')
                dir_meta_size=$(echo "scale=0; ${dir_meta_similar_size}*100/${meta_num_percent}" | bc)
            fi
            # 一个节点的文件循环求和
            metadata_file_sum=$((${metadata_file_sum} + ${metadata_file_num}))
            metadata_size_sum=$((${metadata_size_sum} + ${dir_meta_size}))
        done
        echo "${host} ${metadata_file_sum}" >>oom_metafilenum.txt
        if [ "$metadata_size_sum" -ge 51200 ]; then
            metadata_size_sum_gb=$(echo "scale=1; ${metadata_size_sum} / 1024" | bc)
            echo -e "\t\t\t• ${YELLOW}${host}${RES} tserver metadata 文件大小过大,当前大小: ${YELLOW}${metadata_size_sum_gb}G${RES} > 50G"
        fi
    done
    max_host=$(cat oom_metafilenum.txt | sort -nk2 | tail -n 1 | awk '{print $1}')
    max_file_num=$(cat oom_metafilenum.txt | sort -nk2 | tail -n 1 | awk '{print $2}')

    # 文件数过多
    if [[ "$is_standalone" = "true" ]]; then
        if [[ "$max_file_num" -gt 30000 ]]; then
            echo -e "\t\t\t• kudu tserver metadata 文件数量可能过多,当前总数为: ${YELLOW}${max_file_num}${RES} > 3w (仅供参考,该指标实际意义可能不大)"
        fi
    else
        if [[ "$max_file_num" -gt 30000 ]]; then
            echo -e "\t\t\t• kudu tserver metadata 文件数量可能过多,${max_host} metadata 文件数量为: ${YELLOW}${max_file_num}${RES} > 3w (仅供参考,该指标实际意义可能不大)"
        fi
    fi

    # 3、项目属性列过多
    for project in ${project_all}; do
        property_num=$(sa_mysql -Ne "use metadata;select count(1) from property_define where table_type = 0 and project_id = (select id from project where name = '${project}');")
        if [ "$property_num" -gt 1500 ]; then
            echo -e "\t\t\t• ${YELLOW}${project}${RES} 项目属性列数量较多,属性列数: ${YELLOW}${property_num}${RES} > 1500"
        fi
    done

    # 4、profile 每日更新数据量占比高
    # 统计用户总量
    user_count() {
        user_sum=0
        for project in $project_all; do
            count_users=$(impala-shell -i ${impalad_host} -d rawdata --quiet -B --output_delimiter="\t" -q "select count(*) as count from users /*SA(${project})*/;" 2>/dev/null | tail -n 1)
            line=$(echo ${count_users} | awk -F " " '{print NF}')
            if [[ $line = 7 ]]; then
                count_users_new=$(echo ${count_users} | awk -F " " '{print $7}')
            else
                count_users_new=$count_users
            fi
            user_sum=$((${user_sum} + ${count_users_new}))
        done
    }
    user_count
    # 最近 7 天日导入 profile 详情
    echo -e "\t\t\t• 最近 7 天日导入 profile 如下:"
    impala-shell -i ${impalad_host} -d rawdata --quiet -B --output_delimiter="\t" -q "select day_to_date(day), sum(send) from track_statistic where event = '{PROFILE}' group by 1 order by 1;" >oom_data_input.txt 2>/dev/null
    cat oom_data_input.txt | sed 's/^/\t\t\t\t• /g'
    # 最近 7 天总导入 profile 量
    profile_loader_data_num=$(impala-shell -i ${impalad_host} -d rawdata --quiet -B --output_delimiter="\t" -q "select sum(send) from track_statistic where event = '{PROFILE}';" 2>/dev/null | tail -n 1)
    # 最近 7 天平均日导入量
    profile_daily_loader_data_num=$(echo "scale=0; ${profile_loader_data_num}/7" | bc)
    # 日导入占总用户百分比
    profile_update_percent=$(echo "scale=0; $profile_daily_loader_data_num/$user_sum" | bc)
    # 判断百分比是否超标,暂时按照 15% 做对比
    if [ "$profile_update_percent" -gt 15 ]; then
        echo -e "\t\t\t• 日导入 profile 占 users 总量比例过高,users 总量: ${user_sum},日导入 profile 量: ${profile_daily_loader_data_num},占比 ${YELLOW}${profile_update_percent}%${RES} > 15%"
    fi

    # 5、最后建议找存储专项
    echo -e "\t\t\t• 建议提工单,优化 kudu tserver 内存分配"
}

function yarn_reason() {
    # 1、可能项目过多
    if [ "$project_num" -gt 5 ]; then
        echo -e "\t\t\t• 环境项目较多,项目数: ${YELLOW}${project_num}${RES} > 5"
    fi

    # 3、yarn 资源判断以及错误任务展示
    if [[ "$sp_version" = 2.0 ]]; then
        yarn_pending_num=$(curl -s $yarn_rm_master_host/ws/v1/cluster/metrics | tr "," "\n" | grep containersPending | awk -F ":" '{print $2}')
    else
        yarn_rm1=$(python3 -c 'from hyperion_guidance.mothership_connector import MothershipConnector;connector = MothershipConnector().get_instance();print(connector.get_role_deploy_nodes("yarn", "resourcemanager")[0])')
        yarn_rm2=$(python3 -c 'from hyperion_guidance.mothership_connector import MothershipConnector;connector = MothershipConnector().get_instance();print(connector.get_role_deploy_nodes("yarn", "resourcemanager")[1])')
        curl -s $yarn_rm1:8088/ws/v1/cluster/metrics | grep standby >/dev/null 2>&1
        if [[ "$?" != 0 ]]; then
            yarn_active_rm=$yarn_rm1
        else
            yarn_active_rm=$yarn_rm2
        fi
        yarn_pending_num$(curl -s $yarn_active_rm:8088/ws/v1/cluster/metrics | tr "," "\n" | grep containersPending | awk -F ":" '{print $2}')
    fi
    # yarn job log
    yarn application --list -appStates ALL >oom_yarn_log.txt 2>/dev/null
    yarn_failed_num=$(cat oom_yarn_log.txt | grep FAILED | wc -l)
    if [ "$yarn_pending_num" -gt 0 ]; then
        echo -e "\t\t\t• yarn 资源不足,当前 containersPending: ${YELLOW}${yarn_pending_num}${RES}"
    fi
    if [ "$yarn_failed_num" -gt 50 ]; then
        echo -e "\t\t\t• too many yarn application job failed, failed number: ${YELLOW}${yarn_failed_num}${RES}"
    fi

    # 4、是否开启干路化
    if [[ "$sp_version" = 2.0 ]]; then
        $sp_cmd config get server -m web -p sdg -n enable_chain -c -d false >oom_chain.txt 2>&1
    else
        $sp_cmd config get server -m web -p sdg -n enable_chain -d false -w literal >oom_chain.txt 2>&1
    fi

    chain_status=$(cat oom_chain.txt | tail -n 1 | sed 's/"//g')
    if [[ "$chain_status" = "true" ]]; then
        echo -e "\t\t\t• 环境已开启干路化"
    fi

    # 5、flink 任务检测
    flink_task_num=$(cat oom_yarn_log.txt | grep "Apache Flink" | wc -l)
    if [ "$flink_task_num" -gt 50 ]; then
        echo -e "\t\t\t• yarn flink 任务数量较多,任务数: ${YELLOW}${flink_task_num}${RES} > 50,请具体查看 yarn 任务,分析是否是业务合理使用 yarn application --list -appStates ALL | grep 'Apache Flink'"
    fi

    # 6、stream 模式项目导入检查
    if [[ "$sdf_loader_mode" != "batch" ]]; then
        # 提高执行效率,如果不是 stream,就不获取 sdf 版本了
        sdf_version=$(python3 -c 'from hyperion_client.deploy_topo import DeployTopo;print(DeployTopo().get_product_full_version("sdf"))')
        sdf_version_second_num=$(echo ${sdf_version} | awk -F "." '{print $2}')
        sdf_version_third_num=$(echo ${sdf_version} | awk -F "." '{print $3}')
        sdf_version_fourth_num=$(echo ${sdf_version} | awk -F "." '{print $4}')
        echo -e "\t\t\t• 环境导入模式: ${YELLOW}stream${RES}"
        event_kc_stream_failed_num=$(cat oom_yarn_log.txt | grep event_topic-stream | grep FAILED | wc -l)
        event_k2p_failed_num=$(cat oom_yarn_log.txt | grep KuduToParquet | grep FAILED | wc -l)
        # 版本判断及提示
        if [ "$sdf_version_second_num" -le 3 ] && [ "$sdf_version_third_num" -le 1 ]; then # 二位版本 <= 3, 三位版本 <= 1, 就是 sdf 2.3.1 以下，建议升级到 231 最新小版本
            echo -e "\t\t\t• sdf version: ${YELLOW}${sdf_version}${RES},建议升级至 ${GREEN}sdf 2.3.1.x${RES} 最新小版本以上"
        else
            echo -e "\t\t\t• sdf version: ${YELLOW}${sdf_version}${RES}"
        fi

        # 判断 event kc 任务失败情况
        if [ "$event_kc_stream_failed_num" -gt 5 ]; then
            echo -e "\t\t\t• ${YELLOW}event_kc_stream${RES} 任务失败较多,失败数: ${YELLOW}${event_kc_stream_failed_num}${RES} > 5,建议提工单,排查导入问题"
        fi

        # 判断 event k2p 任务失败情况
        if [ "$event_k2p_failed_num" -gt 5 ]; then
            echo -e "\t\t\t• ${YELLOW}event_k2p${RES} 任务失败较多,失败数: ${YELLOW}${event_k2p_failed_num}${RES} > 5,建议提工单,排查导入问题"
        fi
    fi
}

# 根据 overlimit 提出建议
function overlimit_suggestion() {
    # 模块化输出
    suggestion="\t\t\t• ${YELLOW}现状分析:${RES}"
    # 服务器内存是否达标
    if [ "$physical_memory" -lt 60 ]; then
        echo -e "\t\t• ${RED}服务器物理内存至少需要 64G${RES}"
    fi
    # 根据不同模块分析原因输出建议
    # hadoop 组件
    if [ -n "$hadoop_oom_mod" ]; then
        for MOD in ${hadoop_oom_mod}; do
            echo -e "\n\t\t• ${err} ${MOD} 内存超过环境标准配置!"
            if [[ "${MOD}" = "HDFS" ]]; then
                echo -e "\t${print_hdfs}"
            elif [[ "${MOD}" = "IMPALAD" ]]; then
                echo -e "\t${print_impala}\n${suggestion}" && impala_reason
            elif [[ "${MOD}" = "IMPALAD_JVM" ]]; then
                echo -e "\t${print_impalad_jvm}"
            elif [[ "${MOD}" = "KUDU" ]]; then
                echo -e "\t${print_kudu}\n${suggestion}" && kudu_reason
            elif [[ "${MOD}" = "YARN" ]]; then
                echo -e "\t${print_yarn}\n${suggestion}" && yarn_reason
            fi
        done
    fi
    # sensors 组件
    if [ -n "$sensors_oom_mod" ]; then
        for MOD in ${sensors_oom_mod}; do
            echo -e "\n\t\t• ${err} ${MOD} 内存超过环境标准配置!"
            if [[ "${MOD}" = "SA" ]]; then
                echo -e "\t${print_sa}"
            elif [[ "${MOD}" = "SBP" ]]; then
                echo -e "\t${print_sbp}"
            elif [[ "${MOD}" = "SPS" ]]; then
                echo -e "\t${print_sps}"
            elif [[ "${MOD}" = "SDG" ]]; then
                echo -e "\t${print_sdg}"
            elif [[ "${MOD}" = "SCA" ]]; then
                echo -e "\t${print_sca}"
            elif [[ "${MOD}" = "SRP" ]]; then
                echo -e "\t${print_srp}"
            elif [[ "${MOD}" = "SAT" ]]; then
                echo -e "\t${print_sat}"
            elif [[ "${MOD}" = "EXTRACTOR" ]]; then
                echo -e "\t${print_ex}"
            elif [[ "${MOD}" = "REDIS" ]]; then
                echo -e "\t${print_redis}"
            elif [[ "${MOD}" = "SKV" ]]; then
                echo -e "\t${print_skv}"
            fi
        done
    fi

    # 如果 hadoop 组件不存在超配,但还是 oom 就建议提工单
    if [ "$oom_sum" -eq 0 ]; then
        if [ -z "$hadoop_oom_mod" ]; then
            log_level "INFO" "Hadoop 生态链大数据组件配置未出现超配情况"
        fi
        if [ -z "$sensors_oom_mod" ]; then
            log_level "INFO" "Sensors 基础组件配置未出现超配情况"
        fi
    else
        if [ -z "$hadoop_oom_mod" ]; then
            log_level "WARN" "Hadoop 生态链大数据组件配置未出现超配情况,但还是出现 ${RED}${oom_sum}${RES} 次 Out of memory,建议提「SCB-运维专项」或「SOR-扩容评估」工单"
        fi
    fi
} >oom_checklog.txt 2>/dev/null

# 版本检测函数,检测当前环境是否存在常见的已知内存泄露的组件
function bug_version_check() {
    log_level "INFO" "常见的已知内存泄露的组件检测\n"

    version_check() {
        # sp2.0 及以下检测 skv 0.4
        if [[ "$sp_version" = 2.0 ]]; then
            skv_version_check=$(spadmin skv version 2>&1 | tail -n 1 | grep -w '0.4')
            if [[ $skv_version_check ]]; then
                echo -e "\t\t• ${err} skv 版本 0.4 存在已知的内存泄露问题,建议提 「SOR-安装产品组件」 skv 2.0"
            fi
        fi

        # sca 0.7 且 sca 0.7.0.3087 以下
        sca_version=$(python3 -c 'from hyperion_client.deploy_topo import DeployTopo;print(DeployTopo().get_product_full_version("sca"))')
        sca_version_check=$(echo $sca_version | grep -w '0.7.0')
        if [[ $sca_version_check ]]; then
            # 第四位版本号是否低于 3087
            sca_fourth_version=$(echo $sca_version | awk -F '.' '{print $NF}')
            if [ $sca_fourth_version -lt 3087 ]; then
                echo -e "\t\t• ${err} sca 版本 $sca_version 存在已知的内存泄露问题,建议提 「SOR-版本升级」至 sca 0.7.0.3087 以上"
            fi
        fi

        # lumen catalog 加列内存占用过高, lumen 4.0 且 lumen 4.0.0.46 以下
        if [[ "$sp_version" = 2.0 ]]; then
            lumen_version=$(python3 -c 'from hyperion_client.deploy_topo import DeployTopo;print(DeployTopo().get_product_full_version("lumen"))')
        else
            lumen_version=$(python3 -c 'from hyperion_client.hyperion_inner_client.inner_config_manager import InnerConfigManager;print(InnerConfigManager().get_component_version("lumen"))')
        fi
        lumen_version_check=$(echo $lumen_version | grep -w '4.0.0')
        if [[ $lumen_version_check ]]; then
            # 第四位版本号是否低于 46
            lumen_fourth_version=$(echo $lumen_version | awk -F '.' '{print $NF}')
            if [ $lumen_fourth_version -lt 46 ]; then
                echo -e "\t\t• ${err} lumen 版本 $lumen_version 存在已知的加列内存占用过高问题,建议提 「SOR-版本升级」至 lumen 4.0.0.46 以上"
            fi
        fi

        # sdg web oom,修复版本 0.11.0.76 0.11.1.39 0.12.0.35
        sdg_version=$(python3 -c 'from hyperion_client.deploy_topo import DeployTopo;print(DeployTopo().get_product_full_version("sdg"))')
        sdg_0_11_0_version_check=$(echo $sdg_version | grep -w '0.11.0')
        sdg_0_11_1_version_check=$(echo $sdg_version | grep -w '0.11.1')
        sdg_0_12_0_version_check=$(echo $sdg_version | grep -w '0.12.0')
        sdg_fourth_version=$(echo $sdg_version | awk -F '.' '{print $NF}')
        # 0.11.0 检测
        if [[ $sdg_0_11_0_version_check ]]; then
            # 第四位版本号是否低于 76
            if [ $sdg_fourth_version -lt 76 ]; then
                echo -e "\t\t• ${err} sdg 版本 $sdg_version 存在已知的内存泄露问题,建议提 「SOR-版本升级」至 sdg 0.11.0.76 以上"
            fi
        # 0.11.1 检测
        elif [[ $sdg_0_11_1_version_check ]]; then
            # 第四位版本号是否低于 39
            if [ $sdg_fourth_version -lt 39 ]; then
                echo -e "\t\t• ${err} sdg 版本 $sdg_version 存在已知的内存泄露问题,建议提 「SOR-版本升级」至 sdg 0.11.1.39 以上"
            fi
        # 0.12.0 检测
        elif [[ $sdg_0_12_0_version_check ]]; then
            # 第四位版本号是否低于 35
            if [ $sdg_fourth_version -lt 35 ]; then
                echo -e "\t\t• ${err} sdg 版本 $sdg_version 存在已知的内存泄露问题,建议提 「SOR-版本升级」至 sdg 0.12.0.35 以上"
            fi
        fi
    }
    version_check >oom_version_check.txt
    if [ -s oom_version_check.txt ]; then
        cat oom_version_check.txt
    else
        echo -e "\t\t• ${info} 未检测到常见的内存泄露组件"
    fi
}

# 初始化相关参数的函数
function global_fun() {
    parameter_file_delete # 程序产生的中间文件清理,防止之前执行过有干扰
    color_theme           # 颜色文件
    help                  # 帮助提示
    get_cmd               # 获取系统指令集版本
    check                 # 程序执行用户和版本检测
    global_var            # 定义全局变量
    get_hostname          # 获取主机名
    get_ssh_port          # 获取 ssh 端口
    bookmark_python       # 概览书签中间脚本
}
global_fun

# -c 执行的主函数,调度采集数据的函数
function main() {
    # -c 执行 oom 检测,否则就是 -g 只获取配置
    if [[ "$input" = "-c" ]]; then
        oom_detail    # 获取各节点 oom 详情
        memory_detail # 环境运行内存的相关信息
    fi
    get_physical_memory     # 获取物理内存
    data_comparison         # 日导入和物理内存对比
    hadoop_memory_define    # 获取环境标准的大数据组件模块配置
    hadoop_memory_config    # 获取环境当前的大数据组件模块配置
    sensors_memory_define   # 获取环境标准的基础组件模块配置
    sensors_memory_config   # 获取环境当前的基础组件模块配置
    get_prometheus_jmv_used # 通过 promethues 获取组件过去七天的内存信息
    print_config            # 输出获取的配置
    memory_comparison       # 配置对比
    overlimit_suggestion    # 配置分析
    cat oom_checklog.txt    # 分析结果展示
    bug_version_check       # bug 版本检测
    parameter_file_delete   # 程序执行完再次对产生的中间文件清理
}
main | tee oom_result.log
