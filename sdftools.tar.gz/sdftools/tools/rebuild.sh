#!/bin/bash

REBUILD_FILES_COUNT=`ls *REBUILD.[0-9]*|wc -l`
if [ $REBUILD_FILES_COUNT -eq 0 ]; then
    echo "没找到 *REBUILD* 文件，退出！"
    exit 2
fi


for REBUILD_FILE in `ls *REBUILD.[0-9]*`
do
    CREATE_TABLE_SQL_FILE=`echo $REBUILD_FILE|awk -F '.' '{print $1}'`_CREATE_TABLE.sql
    cat $REBUILD_FILE|grep -v "ALTER TABLE"|grep -v "DROP TABLE" >$CREATE_TABLE_SQL_FILE
    ADD_PARTITION_SQL_FILE=`echo $REBUILD_FILE|awk -F '.' '{print $1}'`_ADD_PARTITION.sql
    cat $REBUILD_FILE|grep  "ALTER TABLE"|grep -v "RENAME TO" >$ADD_PARTITION_SQL_FILE
    DROP_AND_RENAME_SQL_FILE=`echo $REBUILD_FILE|awk -F '.' '{print $1}'`_DROP_AND_RENAME.sql
    cat $REBUILD_FILE|grep USE >$DROP_AND_RENAME_SQL_FILE
    cat $REBUILD_FILE|egrep  "DROP TABLE|RENAME TO" >>$DROP_AND_RENAME_SQL_FILE
done


for CREATE_TABLE_FILE in `ls *REBUILD_CREATE_TABLE*`
do
    impala-shell -f $CREATE_TABLE_FILE
    if [ $? -ne 0 ]; then
        echo "执行创建表失败，impala-shell -f $CREATE_TABLE_FILE，退出"
        exit 2
    fi

done


ADD_PARTITION_FAILED_FILE="ADD_PARTITION_FAILED.log"

SEND_THREAD_NUM=10   #设置进程数。
tmp_fifofile="/tmp/$$.fifo" # 脚本运行的当前进程ID号作为文件名
mkfifo "$tmp_fifofile" # 新建一个随机fifo管道文件
exec 6<>"$tmp_fifofile" # 定义文件描述符6指向这个fifo管道文件
rm "$tmp_fifofile"
for ((i=0;i<$SEND_THREAD_NUM;i++));do
  echo  # for循环 往 fifo管道文件中写入13个空行
done >&6

# 以下循环采用 while read 变量 的处理一行数据，看需要吧
for ADD_PARTITION_FILE in `ls *REBUILD_ADD_PARTITION*`
do
    cat $ADD_PARTITION_FILE | while read line;do
        read -u6 # 从文件描述符6中读取行（实际指向fifo管道)

    {
        impala-shell -d rawdata -q "$line" # 打印 i
        if [ $? -ne 0 ]; then
            echo """ 执行：impala-shell -d rawdata -q "$line" 失败""" >>$ADD_PARTITION_FAILED_FILE
        fi
        sleep 1 # 暂停3秒
        echo >&6 # 再次往fifo管道文件中写入一个空行。
    } &
    done

    # {}部分语句被放入后台作为一个子进程执行，所以不必每次等待3秒后执行
    #下一个,这部分的echo $i几乎是同时完成的，当fifo中13个空行读完后 for循环
    # 继续等待 read 中读取fifo数据，当后台的13个子进程等待3秒后，按次序
    # 排队往fifo输入空行，这样fifo中又有了数据，for语句继续执行
done
wait    #等到后台的进程都执行完毕。
exec 6>&- #删除文件描述符6

sleep 20
# 验证
for ADD_PARTITION_FILE1 in `ls *REBUILD_ADD_PARTITION*`
do
    CREATE_TABLE_FILE1=$(ls *`echo $ADD_PARTITION_FILE1|awk -F "_ADD_PARTITION" '{print $1}'`.[0-9]*)
    TABLE_NAME=`cat $CREATE_TABLE_FILE1|grep CREATE|awk  -F '.' '{print $2}'|awk '{print $1}' `
    USE_DB=`cat $CREATE_TABLE_FILE1|grep USE|awk -F '[ ;]' '{print $2}'`
    IMPALA_SQL="USE $USE_DB; show  partitions $TABLE_NAME"
    FILE_ADD_PARTITION_COUNT=`cat $ADD_PARTITION_FILE1|wc -l`
    TABLE_ADD_PARTITION_COUNT=`impala-shell -q "$IMPALA_SQL"|grep PARQUET|wc -l`
    if [ $FILE_ADD_PARTITION_COUNT -eq $TABLE_ADD_PARTITION_COUNT ];then
        echo "ADD PARTITION 正常"
    else
        echo "ADD PARTITION 不正常，$ADD_PARTITION_FILE1 ADD PARTITION 数量：$FILE_ADD_PARTITION_COUNT，impala 表：$TABLE_NAME ADD PARTITION 数量：$TABLE_ADD_PARTITION_COUNT"
        echo "验证不通过，退出，ADD PARTITION 添加失败项：请查看 $ADD_PARTITION_FAILED_FILE"
        exit 2
    fi
done


exit 0
