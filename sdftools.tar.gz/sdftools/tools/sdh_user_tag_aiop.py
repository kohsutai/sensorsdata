import subprocess
import sys,os,json
from prettytable import PrettyTable

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'common')))
from colored_logging import get_logger
logger = get_logger(__name__)


def convert_to_byte_unit(num):
    """
    byte 单位自动转换
    """
    units = ['bit','Byte','MB', 'GB', 'TB']
    unit_index = 0
    while num >= 1024 and unit_index < len(units) - 1:
        num /= 1024
        unit_index += 1
    return f'{num:.2f} {units[unit_index]}'
def cmd_run(cmd):
    """
    没有使用 云平台提供的 run_cmd 场景不适用，重写个
    """
    p = subprocess.Popen([cmd], stdout=subprocess.PIPE, stderr=subprocess.PIPE,shell=True)
    stdout, _ = p.communicate()
    stdout = stdout.strip()
    if p.returncode != 0:
        logger.info("execute command:%s failed" % cmd)
        exit(1)
    stdout = stdout.decode("utf-8", "ignore")
    return stdout

def get_mysql_res_to_json(res):
    # 获取列名
    rows = res.split('\n')
    column_names = rows[0].split('\t')

    # 将查询结果转换为JSON格式
    json_data = []
    for row in rows[1:]:
        if row:
            json_data.append(dict(zip(column_names, row.split('\t'))))

    # 输出JSON格式的查询结果
    return json_data

user_tag_stored_path_and_size_cmd= """hdfs dfs -du -s  /sa/sdw/condenast_prod/data/sdw_condenast_prod___horizon_private_production_2/*|sort -t ' ' -k1.1 -n |tail -30|sort -nr"""
user_tag_stored_path_and_size_cmd_res = cmd_run(cmd=user_tag_stored_path_and_size_cmd).split('\n')
data = []
for line in user_tag_stored_path_and_size_cmd_res:
    line_res = line.split('  ')
    user_tag_stored_size = convert_to_byte_unit(int(line_res[0]))
    user_tag_stored_name = line_res[-1].split('/')[-1].split('_store_ros')[0]
    # print("user_tag_stored_name:%s" %user_tag_stored_name)
    get_mysql_cmd = f""" metadb_cli -usc_dba horizon_db -e "select * from sdh_tag_definition where project_id = 2 and entity_name = 'user' and custom_param like '%{user_tag_stored_name}%'" """
    # print("get_mysql_cmd:%s"%get_mysql_cmd)
    # exit()
    get_project_info_sql = f""" metadb_cli -usc_dba horizon_db -e "select * from metadata.project where id =2" """
    get_mysql_cmd_res = cmd_run(cmd=get_mysql_cmd)
    # print(get_mysql_cmd_res,type(get_mysql_cmd_res))
    if  get_mysql_cmd_res != '':
        get_mysql_res = get_mysql_res_to_json(get_mysql_cmd_res)[0]
        # print(get_mysql_res,type(get_mysql_res))

        name = get_mysql_res["name"]
        display_name = get_mysql_res["display_name"]
        create_time = get_mysql_res["create_time"]
        update_time = get_mysql_res["update_time"]
        get_project_info_sql_res = cmd_run(cmd=get_project_info_sql)
        get_project_info_res = get_mysql_res_to_json(get_project_info_sql_res)[0]
        project_name = get_project_info_res["name"]
        project_cname = get_project_info_res["cname"]
        data.append([name,display_name,create_time,update_time,project_name,project_cname,user_tag_stored_size])



# exit()

table = PrettyTable(['分群/标签英文名称', '分群/标签中文名称', '创建时间', '编辑时间', '项目英文名', '项目中文名', '占用(G)'])
table.align = 'l'
for row in data:
    table.add_row(row)
print(table)