#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
from hyperion_client.config_manager import ConfigManager

import redis1
cm = ConfigManager()
redis_client_conf = cm.get_client_conf("sp", "redis")
redis_pw = redis_client_conf["password"]
redis_client_host = redis_client_conf["ext_config_list"][0]["redis_list"][0].split(":")[0]
redis_client_port = redis_client_conf["ext_config_list"][0]["redis_list"][0].split(":")[1]
redis_client = redis1.Redis(host=redis_client_host, port=redis_client_port, password=redis_pw, db=1)
begin_pos = 0
count = 0
while True:
    result = redis_client.scan(begin_pos, "ShiroCache*", 10000)
    return_pos, datalist = result
    begin_pos = return_pos
    count += len(datalist)
    if return_pos == 0:
        break
print(count)