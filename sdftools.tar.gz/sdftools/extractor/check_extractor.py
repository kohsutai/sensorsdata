# encoding: utf-8

# @File    : extractor.py
# @Date    : 2022年05月01日14:40:42
# @Author  : liuxiaopeng
# @Desc:

import os, sys, pathlib
import json
# import argparse
# import datetime

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'common')))
from date_tools import shuzi
from colored_logging import get_logger
from handle_json_data import PrintToScreen
logger = get_logger(__name__)

# from hyperion_client.deploy_topo import DeployTopo
# from hyperion_client.config_manager import ConfigManager
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'common')))
from get_mem_cpu_disk_info import sys_info
from get_mem_cpu_disk_info import disk_info
from check_services import optimizable_items
from sdf_utils import get_sdf_full_version,sdf_major_version
from ex_log_parser import ExtractorLogParser

def main():
    # 生成知识库 json 文件后存放位置
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    extractor_knowledge_path = BASE_DIR + "/extractor.json"
    # 参数解析
    # parser = argparse.ArgumentParser(
    #     description='诊断环境extractor问题',
    # )
    # parser.add_argument('-m', '--module',dest="module",type=str,default="extractor",help="排查 extractor 组件问题")

    # # 日期为datetime.datetime格式
    # parser.add_argument('-s', '--stime', dest="stime", metavar="YY-mm-dd HH:MM:SS",
    #                     type=lambda t: datetime.datetime.strptime(t, "%Y-%m-%d %H:%M:%S"),
    #                     help="指定开始日期，例如2000-01-01 10:00:00，诊断从该日期开始的最近日志。默认为现在")

    # parser.add_argument('-v', '--verbose',dest="verbose",type=str,default="simple",choices=["simple","detail"],help="-v simple 输出简单模式，-v detail 输出详细模式")
    # args = parser.parse_args()

    # 加载 extractor 问题库
    with open(extractor_knowledge_path, 'r') as f:
        data = json.load(f)
    keys = data["extractor"].keys()

    # 判断磁盘空间是否足够
    disk_path = "/tmp"
    if disk_info(disk_path):
        exit("剩余空间不足 1024M 或者使用空间大于 85% 退出！")

    # 创建依赖目录
    sdf_log_path = "/tmp/sdflogs"
    sdf_worker_jstack_log_path = sdf_log_path + "/jstack"
    pathlib.Path(sdf_log_path).mkdir(parents=True, exist_ok=True)
    pathlib.Path(sdf_worker_jstack_log_path).mkdir(parents=True, exist_ok=True)

    # 获取 extractor 日志
    if os.environ.get('SENSORS_DATAFLOW_LOG_DIR'):
        ex_logfile = os.environ.get('SENSORS_DATAFLOW_LOG_DIR') + "/extractor/extractor.log"
    else:
        ex_logfile = os.environ.get('SENSORS_PLATFORM_LOG_DIR') + "/extractor/extractor.log"

    # if args.stime:
    #     # 若指定了日期时间，则获取指定日期时间的ex日志
    #     stime2date = datetime.datetime.strftime(args.stime.date(), "%Y-%m-%d")
    #     ex_logfile += "." + stime2date
    #     log_files = os.popen("ls %s*" % ex_logfile).readlines()
    #     log_files = [log_file.strip("\n") for log_file in log_files]

    #     # 指定的日期时间，需在最后修改时间前(由于文件切分，日志创建时间可能与实际日志打印时间有出入)
    #     possible_log_file_list = []
    #     cannot_find_log_file = True
    #     for log_file in log_files:

    #         file_last_modified_time = os.path.getmtime(log_file)
    #         file_last_modified_time = datetime.datetime.fromtimestamp(file_last_modified_time)
    #         if args.stime <= file_last_modified_time:
    #             # 加入可能的日志文件
    #             possible_log_file_list.append(log_file)
    #             cannot_find_log_file = False
    #     if cannot_find_log_file:
    #         logger.warn("找不到该时间段的extractor日志")
    #         exit(1)
    #     possible_log_file_list = sorted(possible_log_file_list, key=lambda t: os.path.getctime(t))   # 可能的日志文件，按创建时间排序

    #     # 若最早创建的日志文件，创建时间在给定时间之后，则说明无符合要求的日志文件
    #     earlist_created_possible_log_file = possible_log_file_list[0]
    #     # earlist_created_possible_log_file_created_time = datetime.datetime.fromtimestamp(os.path.getctime(earlist_created_possible_log_file))
    #     # if earlist_created_possible_log_file_created_time > args.stime:
    #     #     print("找不到该时间段的extractor日志")
    #     #     exit(1)
    #     ex_logfile = earlist_created_possible_log_file
    #     logger.info("诊断日期为%s的日志" % stime2date)
    # else:
    #     logger.info("未指定日期，默认诊断今天日志")

    # 需要在 ex 节点运行
    get_sdf_full_version_res = get_sdf_full_version()
    if sdf_major_version() == "3.0":
        exit("SDF version: %s，SDF 3.0 没有 ex 组件，脚本暂不支持！" %get_sdf_full_version_res)
    if not os.path.isfile(ex_logfile):
        exit("不存在 %s 日志，需要在 ex 节点执行") % ex_logfile
    logger.info("extractor 日志路径：%s" %ex_logfile)


# def main():

    # if args.stime:
    #     log_time_pattern = r'(\d{4}-\d{2}-\d{2}).*?(\d{2}:\d{2}:\d{2})'
    #     extractor_log_parser = ExtractorLogParser(log_time_pattern)
    #     target_line_number = extractor_log_parser.parse_ex_log(args.stime, ex_logfile)

    #     line_start = target_line_number
    #     offset = 100000
    #     line_2 = line_start + offset

    #     # 截取 指定行后续的 10W 条日志数据
    #     cut_ex_log_cmd = "awk '{if(NR>=%s && NR<=%s) print $0}' %s > /tmp/extractor.log" % (line_start, line_2, ex_logfile)
    # else:
    cut_ex_log_cmd = "tail -100000 %s >/tmp/extractor.log" % ex_logfile
    lognewfile = "/tmp/extractor.log"
    os.popen(cut_ex_log_cmd).readlines()

    # 获取 ex 进程 jstack 信息
    logger.info("开始获取 ex 进程 jstack 信息")
    process_name = "ExtractorMain"
    process_time = shuzi()
    process_cmd = "pid=`jps -m |grep %s|head -1|awk '{print $1}'`;if [ -z $pid ];then pass;else jstack $pid >/tmp/sdflogs/jstack/jstack_%s_%s_${pid}.log;echo jstack_%s_%s_${pid}.log;fi" % (
        process_name, process_name, process_time, process_name, process_time)
    os.popen(process_cmd).readlines()

    total_info = {}
    index_count = 0
    worker_count = 0
    # 收集资源信息
    logger.info("开始收集系统资源信息")
    system_info = sys_info()
    total_info.update(system_info)

    # 调优项
    logger.info("开始收集调优项")
    optz_info = optimizable_items()
    if len(optz_info["Optimizable_items"].keys()) >=1:
        total_info.update(optz_info)

    #  判断 ex 的瓶颈
    logger.info("开始收集 ex worker 瓶颈信息")
    worker1 = {"Worker_info": {}}

    cmd1 = """ grep "input queue size:" %s|grep -v "input queue size: 0"|grep "output queue size: 0" |awk -F ' Worker ' '{print $2}'|awk '{print $1}'|sort|uniq -c |sort -nr|head -3 """ % lognewfile
    res1 = os.popen(cmd1).readlines()
    if len(res1) > 0:
        for n in range(len(res1)):
            worker_num = int(res1[n].split()[0])
            worker_name = res1[n].split()[1]
            worker_count += 1
            worker_index = worker_count
            worker_info = {worker_index: {}}
            worker_info[worker_index]["worker_name"] = worker_name
            worker_info[worker_index]["worker_num"] = worker_num
            worker1["Worker_info"][worker_index] = worker_info[worker_index]
            total_info.update(worker1)
    index1 = {"Problems": {}}
    
    #  根据问题记录循环遍历 extractor.log
    # TODO with the expansion of keys, this loop will consume more time in a liner manner.
    logger.info("开始遍历 ex 问题库")
    logger.info("SDF version: %s" %get_sdf_full_version_res)
    for key in keys:
        find_key_cmd = """cat %s|grep "%s"|wc -l""" % (lognewfile, key)
        target_line = os.popen(find_key_cmd).readlines()
        error_msgs_count = int(target_line[0].split()[0])
        if error_msgs_count > 0:
            index_count += 1
            index = index_count
            index_info = {index: {}}
            index_info[index]["ERROR"] = key
            index_info[index]["solution"] = data["extractor"][key]
            index_info[index]["occurrence number"] = error_msgs_count
            index1["Problems"][index] = index_info[index]
            total_info.update(index1)

    msg_log = json.dumps(total_info)
    shuzi1 = shuzi()
    file_name = sdf_log_path + "/op_check_extractor_" + shuzi1 + ".log"
    tmp_file_name = "/tmp/op_check_extractor_" + shuzi1 + ".log"
    tmp_file_detail_name = "/tmp/op_check_extractor_" + shuzi1 + "detail.log"
    file_detail_name = "/tmp/sdflogs/op_check_extractor_" + shuzi1 + "_detail.log"
    simple_or_detail = True
    PrintToScreen(file_name=file_name,tmp_file_detail_name=tmp_file_detail_name,tmp_file_name=tmp_file_name,file_detail_name=file_detail_name,msg_log=msg_log,total_info=total_info,simple_or_detail=simple_or_detail)
    logger.info("查看详细信息请执行：cat %s" %file_detail_name)


if __name__ == '__main__':
    main()

