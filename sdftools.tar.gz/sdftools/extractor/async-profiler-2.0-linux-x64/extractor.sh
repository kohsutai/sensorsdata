# 统计一分钟，wall 是指线程的执行的时候的所有时间都算，比如 Running, Sleeping，Blocking，比如 Redis Worker，它获取 SKV 的数据，从发送到接收，线程会 Sleeping。如果不算 Sleeping（不指定-e wall）那么就看不到发送到接收之间的时间。指定了就会计算发送到接收的时间
sh profiler.sh -e wall -t -i 10ms -f out.html `jps -m |grep ExtractorMain|awk '{print $1}'` && \
sh ufile.sh out.html
