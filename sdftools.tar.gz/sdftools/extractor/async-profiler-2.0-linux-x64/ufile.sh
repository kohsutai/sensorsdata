#!/usr/bin/env bash
#
# Author: Panda
# Update: 2019-07-18
 
version="0.7"
 
url="http://ufile.vip.sensorsdata.cn"
 
printHelp () {
    echo "Version: ${version}"
    echo "Usage: $0 {File} [Directory] [-C]"
    echo "  File: the abs path of the file"
    echo "  Directory: the directory you want to upload"
    echo "  -C: Continue/Resume a previous file transfer"
    echo "  -V/--version: Display verison"
    echo "  -h/--help: Usage help"
    exit 2
}
 
if [ $# -lt 1 ];then
    printHelp
fi
 
File=$1
Directory=$2
Continue=$3
 
[ ${File} == '-h' ] || [ ${File} == '--help' ] && printHelp
[ ${File} == '-V' ] || [ ${File} == '--version' ] && echo ${version} && exit 0
[ ! -f ${File} ] && echo "${File}: no such file" && printHelp
 
[ ! -z ${Directory} ] && [ ${Directory} == '-C' ] && Directory="${Continue}" && Continue='-C'
[ -z ${Continue} ] && Continue="LovePanda"
 
if [ -z $(echo ${Directory} | awk '{print $1}') ];then
    Directory="/"
else
    Directory="/${Directory}/"
fi
 
file_name=$(echo ${File} | awk -F'/' '{print $NF}')
 
# return download url
download_url="${url}/dl${Directory}${file_name}"
 
# upload
echo "Uploading ${File} to ${download_url} ..."
if [ ${Continue} == '-C' ];then
    curl -u pandau:nYvr7XDQx -T ${File} -a ${url}/ufile${Directory}${file_name} | tee /dev/null
else
    curl -u pandau:nYvr7XDQx -T ${File} ${url}/ufile${Directory}${file_name} | tee /dev/null
fi
 
if [ $? -ne 0 ];then
    echo "Failed!"
    exit 2
fi
 
echo "Succeed ~ Download it by:"
echo "  wget --http-user=pandag --http-passwd=z5lZiumYp ${download_url}"
