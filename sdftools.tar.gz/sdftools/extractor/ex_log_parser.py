import re
import datetime


class ExtractorLogParser(object):
    def __init__(self, log_time_pattern: str):
        self.log_time_pattern = log_time_pattern
        self.date_format_parsing_pattern = re.compile(self.log_time_pattern)

    def __parse_date_format(self, log_content: str) -> datetime.datetime:
        """
        从一行日志中提取时间
        :param log_content: 文本形式的日志内容
        :return: datetime.datetime类型的时间
        """

        res_group = re.search(self.date_format_parsing_pattern, log_content)
        if not res_group or len(res_group.groups()) < 2:
            return None
        log_time = res_group.group(1) + " " + res_group.group(2)
        log_time = datetime.datetime.strptime(log_time, "%Y-%m-%d %H:%M:%S")
        return log_time

    def parse_ex_log(self, stime: datetime.datetime, log_file: str) -> int:
        """
        根据给定的时间，在日志文件中进行二分查找，找到符合时间的行
        :param stime: 给定的时间，以该时间为开始
        :param log_file: 日志文件路径
        :return: 日志行
        """
        line_offset = []  # 索引为行数(从0开始)，值为偏移量
        f_log_file = open(log_file, "r+")

        line_offset.append(0)   # 第一行offset为0
        line = f_log_file.readline()
        while line:
            offset = f_log_file.tell()
            line_offset.append(offset)
            line = f_log_file.readline()
        line_number = len(line_offset)

        target_line = 0
        start_line, end_line = 0, line_number
        while start_line <= end_line:
            if end_line - start_line <= 1:
                # 未精确到匹配时间的情况
                target_line = start_line
                break
            mid_line = (start_line + end_line) // 2
            f_log_file.seek(line_offset[mid_line])
            mid_date_time = self.__parse_date_format(f_log_file.readline())

            # 未解析出时间的情况
            while mid_date_time is None and mid_line >= start_line:
                mid_line -= 1
                f_log_file.seek(line_offset[mid_line])
                mid_date_time = self.__parse_date_format(f_log_file.readline())

            if mid_line < start_line:
                print("未找到指定时间的日志")
                exit(1)

            if stime < mid_date_time:
                end_line = mid_line - 1
            elif stime > mid_date_time:
                start_line = mid_line + 1
            else:
                target_line = mid_line
                break
        f_log_file.close()

        return target_line
