import json
import os
import socket
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'common')))
from ssh_client import SSHClient
from colored_logging import get_logger
from multiprocessing import Pool

logger = get_logger(__name__)


class DataLoaderLogFilterAssigner:
    """
    用于分发日志过滤脚本data_loader_log_filter、触发各节点上的脚本执行
    """

    def __init__(self, host_set: set):
        """

        :param worker_host: 主机名
        :param log_file: 日志文件
        """
        try:
            from hyperion_client.node_info import NodeInfo
            self.ssh_port = NodeInfo().get_node_ssh_port(hostname=socket.getfqdn())
        except Exception:
            self.ssh_port = 22

        # self.ssh_client = SSHClient(hostname=self.worker_host, port=self.ssh_port)

        self.host_set = host_set
        # self.worker_host = worker_host
        # self.log_file = log_file

    def prepare_env(self) -> bool:

        # 分发日志过滤脚本
        analysis_tool = os.path.abspath(os.path.join(os.path.dirname(__file__), "data_loader_log_filter.py"))

        for hostname in self.host_set:
            res = os.popen(f"scp -P {self.ssh_port} {analysis_tool} {hostname}:/tmp/")
        # err = res["stderr"]
        # if err:
        #     print("分发日志过滤脚本时出错，异常信息：", err)
        #     return False
        return True

    def do_log_filter(self, hostname: str, log_type: str, stime: str, etime: str):
        cmd = f"python3 /tmp/data_loader_log_filter.py  {log_type} {stime} {etime}"

        # return {'host': self.params['hostname'], 'cmd': cmd, 'ret': ret, 'stdout': stdout, 'stderr': stderr}
        ssh_client = SSHClient(hostname=hostname, port=self.ssh_port)
        res = ssh_client.run_cmd(cmd)
        err = res["stderr"]
        if err:
            logger.error("问题检查脚本执行时出错，异常信息：", err)
            return json.loads("{}")
        return json.loads(res["stdout"])

    def run(self, *args):
        """
        触发各节点上的日志过滤脚本执行，并收集结果。
        :return:
        """
        with Pool(5) as p:
            log_filter_res = p.starmap(self.do_log_filter, *args)
        return log_filter_res
