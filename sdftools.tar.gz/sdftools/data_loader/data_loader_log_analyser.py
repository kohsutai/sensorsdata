import json
import os
from sys import argv
import time
# nyrsfm 年月日时分秒 格式
def nyrsfm(time1):
    return  time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time1))

# 各节点上进行日志分析的脚本，由data_loader_log_analyser_assigner分发。
class DataLoaderLogAnalyser:

    @staticmethod
    def analyse(hostname: str,log_mtime, log_file_path: str , knowledge_file: str):
        # 传入：日志名的路径，知识库的路径
        # 输出：JSON格式分析结果
        """
        :param log_file_path:
        :param knowledge_file:
        :return:
        {
            "hostname": "data01",
            "last_updated_time": "文件最后修改时间：2000-01-01 01:02:03",
            "java.lang.OutOfMemoryError:" : {
                "occurrence_number": 1,
                "solution": "xxx"
            }
        }
        """

        # 加载 dl 知识库
        data = json.load(open(knowledge_file, 'r'))
        keys = data["data_loader"].keys()
        def error_info_count(error_info_key, log_file_path):
            cmd = '''fgrep -- """%s""" %s |wc -l''' %(error_info_key,log_file_path)
            # print(cmd)
            line_count = os.popen(cmd).readlines()[0]
            return int(line_count)

        # 记录文件最后修改时间；问题名、问题出现次数、解决方案
        log_type = log_file_path.split("/")[-1]
        analysis_result = {log_type: {"hostname": hostname}}
        has_problem = False
        if os.path.exists(log_file_path) and os.path.getsize(log_file_path) > 0:
            problem_index = 0
            for key in keys:
                error_msgs_count = error_info_count(error_info_key=key, log_file_path=log_file_path)
                if error_msgs_count > 0:
                    if not has_problem:
                        analysis_result[log_type]["last_updated_time"] = nyrsfm(int(log_mtime))
                        has_problem = True
                    analysis_result[log_type][problem_index] = {}
                    analysis_result[log_type][problem_index]["ERROR"] = key
                    analysis_result[log_type][problem_index]["occurrence_number"] = error_msgs_count
                    analysis_result[log_type][problem_index]["solution"] = data["data_loader"][key]
                    problem_index += 1
        if len(analysis_result.get(log_type).keys()) == 1:
            # 未发现问题，则不输出该分析结果。
            if __name__ == "__main__":
                print(json.dumps({}))
            return json.dumps({})
        else:
            if __name__ == "__main__":
                print(json.dumps(analysis_result))
            return json.dumps(analysis_result)


if __name__ == "__main__":
    try:
        hostname, log_mtime,log_file_path, knowledge_file = argv[1], argv[2], argv[3] ,argv[4]
    except IndexError as ie:
        # print(ie)
        exit(1)
    except Exception as e:
        # print(e)
        exit(1)
    else:
        DataLoaderLogAnalyser().analyse(hostname,log_mtime,log_file_path, knowledge_file)
