# encoding: utf-8

# @File    : sdf_optimizing_configuration.py
# @Date    : 2024年04月02日18:49:12
# @Author  : liuxiaopeng
# @Desc:  优化 dl 配置
import asyncio
import os,sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'common')))
from config_get_set import ConfigGetSet
from get_yml_data import GetYmlData
from colored_logging import get_logger
from hyperion_client.deploy_info import DeployInfo
from get_prom_data import get_sdf_latency_min
from sdf_utils import sdf_major_version,get_sdf_full_version
from all_dl_info import enable_weak_uniform,k2p_running_set,get_event_avg_import_rate,get_profile_avg_import_rate,get_project_count
from all_kudu_info import KuduInfo
from distutils.version import LooseVersion
from yarn_info import yarn_totalMB,yarn_totalVirtualCores
from unit_conversion import convert_to_mb_unit

logger = get_logger(__name__)


def main():
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    opt_file = BASE_DIR + "/recommended_config.yml"

    # 不支持 sdf 3.0
    sdf_major_version_res = sdf_major_version()
    if sdf_major_version_res == "3.0" or not sdf_major_version_res:
        exit("本脚本暂不支持 sdf 3.0 版本 和 sa 301 版本，退出！")

    optimizing_config_info = {"base":{},"recommend":{},"warn":{}}
    get_enable_weak_uniform_res = enable_weak_uniform()
    get_sdf_full_version_res = get_sdf_full_version()
    logger.info(f"SDF 版本：{get_sdf_full_version_res}")

    def is_ge_sdf_version(target_sdf_version):
        if LooseVersion(get_sdf_full_version_res) >= LooseVersion(target_sdf_version):
            return True 

    # 集群还是单机，False 是集群，True 是单机
    is_simplified = DeployInfo().get_simplified_cluster()

    # 读取 yml 文件配置信息
    yml_data = GetYmlData(yaml_file_path=os.path.abspath(os.path.join(os.path.dirname(__file__), opt_file)))
    data=yml_data.load_yaml()
    product="sdf"
    namespace="data_loader"
    def ConfigData(product="sdf",namespace="data_loader"):
        config_data = data[product]["namespaces"][namespace]
        return config_data

    config_data = ConfigData()
    ex_config_data = ConfigData(product="sdf",namespace="extractor")


    profile_avg_import_rate_res = get_profile_avg_import_rate()
    event_avg_import_rate_res = get_event_avg_import_rate()
    remapping_latency_min_res = get_sdf_latency_min(data_type = "remapping")
    profile_latency_min_res = get_sdf_latency_min(data_type = "profile")
    event_latency_min_res = get_sdf_latency_min(data_type = "event")
    k2p_running_set_res = k2p_running_set()
    projects_count = get_project_count()
    logger.info(f"最近 7 天，事件数据导入 qps：{event_avg_import_rate_res}，用户数据导入 qps：{profile_avg_import_rate_res}，项目个数：{projects_count}")


    def config_desc(key):
        key_data = config_data.get(key)
        config_desc_res = key_data.get("description")
        return config_desc_res

    def config_desire_value(key):
        key_data = config_data.get(key)
        config_desire_value_res = key_data.get("desireValue")
        return config_desire_value_res

    def config_default_value(key):
        key_data = config_data.get(key)
        config_default_value_res = key_data.get("defaultValue")
        # print("test %s %s" %(config_default_value_res,type(config_default_value_res)))
        return config_default_value_res

    def config_key_type(key):
        key_data = config_data.get(key)
        config_key_type_res = key_data.get("type")
        return config_key_type_res

    def config_get_key(key,namespace=namespace,product=product):
        config_default_value_res = config_default_value(key=key)
        # print("test1 %s %s" %(config_default_value_res,type(config_default_value_res)))
        config_key_type_res = config_key_type(key=key)
        config_get_key_res = ConfigGetSet().confGet(key=key,namespace=namespace,product=product,default_value=config_default_value_res)
        if config_key_type_res == "int":
            return int(config_get_key_res)
        elif config_key_type_res == "string":
            return str(config_get_key_res)
        elif config_key_type_res == "bool":
            # print("test2 %s %s" %(config_get_key_res,type(config_get_key_res)))
            return "false" if config_get_key_res == "false" or config_get_key_res == 0 else "true"

    def get_dl_loader_mode(key):
        loader_mode_value = config_get_key(key=key)
        loader_mode = "batch" if "batch" in loader_mode_value else "stream"
        logger.info(f"导入模式 {loader_mode}")
        return loader_mode

    get_dl_loader_mode_res = get_dl_loader_mode(key="loader_mode")


    def compare(value1, value2, compare_operation):
        # print(value1,value2,type(value1),type(value2))
        if compare_operation == "=":
            return value1 == value2
        elif compare_operation == ">":
            return value1 > value2
        elif compare_operation == "<":
            return value1 < value2
        elif compare_operation == ">=":
            return value1 >= value2
        elif compare_operation == "<=":
            return value1 <= value2
        elif compare_operation == "!=":
            return value1 != value2

        
    def config_set_key(key,config_desire_value_res=None):
            config_set_res = True
            if config_desire_value_res is None:
                config_desire_value_res = config_desire_value(key=key)
                # print(config_desire_value_res,type(config_desire_value_res))
            config_desc_res = config_desc(key=key)
            get_key_res =  config_get_key(key=key)
            # print(get_key_res,type(get_key_res))
            #获取 recommended_config.yml data_loader 的配置信息
            if compare(get_key_res,config_desire_value_res,compare_operation="!="):
                config_set_res = ConfigGetSet().confSet(key=key,namespace=namespace,product=product,value=config_desire_value_res)

                logger.warning(f"当前环境配置：{key} 值：{get_key_res} 期望值：{config_desire_value_res}，如果仍需要调整，参数描述：{config_desc_res}，参数设置：\n{config_set_res}")
                return True
            else:
                logger.info(f"参数描述：{config_desc_res}，{key} 当前值：{get_key_res}")
                # logger.warning("\n" + str(config_set_res))   
                return True
            return False

    def is_ge_sdf_version(target_sdf_version):
        if LooseVersion(get_sdf_full_version_res) >= LooseVersion(target_sdf_version):
            return True 

    async def get_yarn_mem():
        yarn_mem_mb = yarn_totalMB()
        yarn_mem = convert_to_mb_unit(yarn_mem_mb)
        logger.info(f"yarn 资源池 mem 大小：{yarn_mem}")
        return yarn_mem_mb
    async def get_yarn_vc():
        yarn_vc = yarn_totalVirtualCores()
        logger.info(f"yarn 资源池 vc 大小：{yarn_vc}")
        return yarn_vc

    async def get_moved_out_tables_preserved_time_ms(key):
        if get_dl_loader_mode_res == "stream" and not is_simplified:
            config_set_key(key=key)

    async def get_snapshot_delete_cache_time(key):
        if not is_simplified:
            config_set_key(key=key)

    async def get_event_data_compression_codec_name(key):
        if not is_simplified:
            config_set_key(key=key)

    async def get_kafka_consumer_correction_event_max_flush_count_in_batch(key):
        if not is_simplified and event_avg_import_rate_res and event_avg_import_rate_res > 20000 and get_dl_loader_mode_res =="batch":
            config_set_key(key=key)

    async def get_enable_kafka_consumer_pre_compute(key):
        if not is_simplified and event_avg_import_rate_res and event_avg_import_rate_res > 15000 and get_dl_loader_mode_res == "batch" and is_ge_sdf_version("2.3.1.87"):
            config_set_key(key=key)

    async def get_enable_weak_uniform(key):
        if get_enable_weak_uniform_res:
            config_set_key(key=key)

    async def get_k2p_running_set():
        if k2p_running_set_res:
            cmd = k2p_running_set_res["cmd"]
            desc = k2p_running_set_res["desc"]
            logger.info(f"{desc}")
            logger.warning(f"{cmd}")

    async def get_one_mapper_read_event_kafka_partitions(key):
        if get_dl_loader_mode_res == "stream" and not is_simplified and event_avg_import_rate_res and event_avg_import_rate_res < 4000 and is_ge_sdf_version("2.3.0"):
            config_set_key(key=key)

    async def get_one_mapper_read_profile_kafka_partitions(key):
        if get_dl_loader_mode_res == "stream" and not is_simplified and profile_avg_import_rate_res and profile_avg_import_rate_res < 1000 and is_ge_sdf_version("2.3.0"):
            config_set_key(key=key)

    async def get_stream_remapping_merge_profile_parallel_num(key):
        if get_dl_loader_mode_res == "stream" and remapping_latency_min_res and remapping_latency_min_res >10  and event_latency_min_res<2  and profile_latency_min_res <2:
            config_set_key(key=key)

    async def get_batch_remapping_merge_profile_parallel_num(key):
        if get_dl_loader_mode_res =="batch" and remapping_latency_min_res and remapping_latency_min_res >50 and event_latency_min_res < 40 and profile_latency_min_res < 40:
            config_set_key(key=key)

    async def get_kafka_consumer_max_profile_flush_count(key):
        if profile_avg_import_rate_res >= 20000:
            config_set_key(key=key,config_desire_value_res=30000)
        elif 10000 <= profile_avg_import_rate_res < 20000:
            config_set_key(key=key,config_desire_value_res=20000)
        elif 2000 <= profile_avg_import_rate_res < 10000:
            config_set_key(key=key,config_desire_value_res=10000)
        else:
            config_set_key(key=key)

    async def get_kafka_consumer_profile_mapper_max_memory_mb(key):
        if not is_simplified:
            if profile_avg_import_rate_res:
                if profile_avg_import_rate_res >=20000:
                    config_set_key(key=key,config_desire_value_res=6144)
                elif 10000 <= profile_avg_import_rate_res < 20000:
                    config_set_key(key=key,config_desire_value_res=5120)
                elif 5000 <= profile_avg_import_rate_res < 10000:
                    config_set_key(key=key,config_desire_value_res=4096)
                elif 5000 <= profile_avg_import_rate_res < 10000:
                    config_set_key(key=key,config_desire_value_res=3072)
                else:
                    config_set_key(key=key)


    async def get_kafka_consumer_max_flush_count(key):
        if is_simplified:
            config_set_key(key=key,config_desire_value_res=2500)
        else:
            if event_avg_import_rate_res:
                if event_avg_import_rate_res >= 30000:
                    config_set_key(key=key,config_desire_value_res=20000)
                elif 20000 <= event_avg_import_rate_res < 30000:
                    config_set_key(key=key,config_desire_value_res=15000)
                elif 10000 <= event_avg_import_rate_res < 20000:
                    config_set_key(key=key,config_desire_value_res=10000)
                elif 5000 <= event_avg_import_rate_res < 10000:
                    config_set_key(key=key,config_desire_value_res=5000)
                else:
                    config_set_key(key=key,config_desire_value_res=3000)

        
    async def get_parquet_converter_reducer_max_memory_mb(key):
        if not is_simplified:
            if get_dl_loader_mode_res == "stream" and event_avg_import_rate_res:
                if event_avg_import_rate_res >= 30000:
                    config_set_key(key=key,config_desire_value_res=8192)
                elif 20000 <= event_avg_import_rate_res < 30000:
                    config_set_key(key=key,config_desire_value_res=6144)
                elif 10000 <= event_avg_import_rate_res < 20000:
                    config_set_key(key=key,config_desire_value_res=5120)
                else:
                    config_set_key(key=key,compare_operation="=")

    async def get_kafka_consumer_mapper_max_memory_mb(key):
        if not is_simplified:
            if event_avg_import_rate_res:
                if event_avg_import_rate_res >=30000:
                    config_set_key(key=key,config_desire_value_res=6144)
                elif 20000 <= event_avg_import_rate_res < 30000:
                    config_set_key(key=key,config_desire_value_res=5120)
                elif 10000 <= event_avg_import_rate_res < 20000:
                    config_set_key(key=key,config_desire_value_res=4096)
                elif 5000 <= event_avg_import_rate_res < 10000:
                    config_set_key(key=key,config_desire_value_res=3072)
                else:
                    config_set_key(key=key)


    async def get_kafka_consumer_batch_job_period(key):
        if get_dl_loader_mode_res == "batch":
            config_set_key(key=key)

    async def get_ignore_remapping_distinct_id_mismatch(key):
        config_set_key(key=key)

    async def get_kudu_full_table_exist_max_num(key):
        if get_dl_loader_mode_res == "stream" and event_avg_import_rate_res and not is_simplified:
            if event_avg_import_rate_res >=30000:
                config_set_key(key=key,config_desire_value_res=5)
            else:
                config_set_key(key=key)

    async def get_kudu_table_bucket_number(key):
        """
        stream 模式 + 项目数大于 3 个 + kudu tserver 个数大于 3 的时候在配置，是 tserver 个数的 2 倍
        """
        if get_dl_loader_mode_res == "stream":
            ts_count = KuduInfo().tserver_addresses_count()
            if projects_count > 3 or ts_count >3:
                config_bucket_num = ts_count 
                config_set_key(key=key,config_desire_value_res=config_bucket_num)

    async def get_wos_table_max_count(key):
        if get_dl_loader_mode_res == "stream" and event_avg_import_rate_res:
            if event_avg_import_rate_res >=30000:
                config_set_key(key=key,config_desire_value_res=120000000)
            elif 20000 <= event_avg_import_rate_res < 30000:
                config_set_key(key=key,config_desire_value_res=90000000)
            elif 10000 <= event_avg_import_rate_res < 20000:
                config_set_key(key=key,config_desire_value_res=60000000)
            else:
                config_set_key(key=key)

    async def get_kafka_request_fetch_size(key):
        if event_avg_import_rate_res and event_avg_import_rate_res >= 20000:
            config_set_key(key=key)

    async def get_kudu_to_parquet_running_concurrent(key):
        if get_dl_loader_mode_res == "stream"  and sdf_major_version_res != "3.0":
            k2p_running_concurrent = 0
            if (sdf_major_version_res == "2.2" and is_ge_sdf_version("2.2.12786")) or (sdf_major_version_res == "2.3" and is_ge_sdf_version("2.3.1.137")) or (sdf_major_version_res == "2.4" and is_ge_sdf_version("2.4.0")):
                if 2 < projects_count <= 5:
                    k2p_running_concurrent = 1
                elif 5 < projects_count <= 10:
                    k2p_running_concurrent = 2
                elif 10 < projects_count <= 20:
                    k2p_running_concurrent = 3
                elif 20 < projects_count <= 50:
                    k2p_running_concurrent = 5
                elif projects_count > 50:
                    k2p_running_concurrent = 10
            config_set_key(key=key,config_desire_value_res=k2p_running_concurrent)

    async def get_fixed_thread_pool_size_for_kudu_scan(key):
        if sdf_major_version_res == "2.4" and is_ge_sdf_version("2.4.0.4829"):
            config_set_key(key=key)          

    async def get_enable_kafka_data_check_sum(key):
        if (sdf_major_version_res == "2.3" and is_ge_sdf_version("2.3.1.4197")) or (sdf_major_version_res == "2.4" and is_ge_sdf_version("2.4.0.5144")) :
            config_set_key(key=key)


    loop = asyncio.get_event_loop()
    tasks = [
        loop.create_task(get_yarn_vc()),
        loop.create_task(get_yarn_mem()),
        loop.create_task(get_moved_out_tables_preserved_time_ms(key="moved_out_tables_preserved_time_ms")),
        loop.create_task(get_snapshot_delete_cache_time(key="snapshot_delete_cache_time")),
        loop.create_task(get_event_data_compression_codec_name(key="event_data_compression_codec_name")),
        loop.create_task(get_kafka_consumer_correction_event_max_flush_count_in_batch(key="kafka_consumer_correction_event_max_flush_count_in_batch")),
        loop.create_task(get_enable_kafka_consumer_pre_compute(key="enable_kafka_consumer_pre_compute")),
        loop.create_task(get_enable_weak_uniform(key="enable_weak_uniform")),
        loop.create_task(get_k2p_running_set()),
        loop.create_task(get_one_mapper_read_event_kafka_partitions(key="one_mapper_read_event_kafka_partitions")),
        loop.create_task(get_one_mapper_read_profile_kafka_partitions(key="one_mapper_read_profile_kafka_partitions")),
        loop.create_task(get_stream_remapping_merge_profile_parallel_num(key="remapping_merge_profile_parallel_num")),
        loop.create_task(get_batch_remapping_merge_profile_parallel_num(key="remapping_merge_profile_parallel_num")),
        loop.create_task(get_kafka_consumer_max_flush_count(key="kafka_consumer_max_flush_count")),
        loop.create_task(get_kafka_consumer_mapper_max_memory_mb(key="kafka_consumer_mapper_max_memory_mb")),
        loop.create_task(get_kafka_consumer_batch_job_period(key="kafka_consumer_batch_job_period")),
        loop.create_task(get_ignore_remapping_distinct_id_mismatch(key="ignore_remapping_distinct_id_mismatch")),
        loop.create_task(get_kudu_full_table_exist_max_num(key="kudu_full_table_exist_max_num")),
        loop.create_task(get_kudu_table_bucket_number(key="kudu_table_bucket_number")),
        loop.create_task(get_wos_table_max_count(key="wos_table_max_count")),
        loop.create_task(get_kafka_request_fetch_size(key="kafka_request_fetch_size")),
        loop.create_task(get_kafka_consumer_max_profile_flush_count(key="kafka_consumer_max_profile_flush_count")),
        # loop.create_task(get_kafka_consumer_profile_mapper_max_memory_mb(key="kafka_consumer_profile_mapper_max_memory_mb")),
        loop.create_task(get_kudu_to_parquet_running_concurrent(key="kudu_to_parquet_running_concurrent")),
        loop.create_task(get_fixed_thread_pool_size_for_kudu_scan(key="fixed_thread_pool_size_for_kudu_scan")),
        # 现在这个客户的 watermark 数据 check 失败，不能入 skv，影响到上游智能预警，已经适配了，添加了版本限制
        loop.create_task(get_enable_kafka_data_check_sum(key="enable_kafka_data_check_sum"))
    ]
    loop.run_until_complete(asyncio.wait(tasks))
    loop.close()

if __name__ == '__main__':
    main()