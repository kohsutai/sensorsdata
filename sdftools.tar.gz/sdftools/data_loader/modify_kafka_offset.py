#!/bin/env python3
# -*- coding: UTF-8 -*-
"""
Copyright (c) 2020 SensorsData, Inc. All Rights Reserved
@author liuxiaopeng@sernsorsdata.cn
@desc 查看 kafka offset 信息，dl 进度信息
"""
import os
import sys
import json

from hyperion_client.deploy_topo import DeployTopo
from hyperion_client.config_manager import ConfigManager
import utils.sa_utils
sys.path.append(os.path.abspath(os.path.dirname(__file__)))
# pycommon
sys.path.append(os.path.join(os.environ['SENSORS_PLATFORM_HOME'], 'pycommon'))
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'common')))
from ssh_client  import SSHClient
from check_services import is_ge_sp2_1_version

topic_name1 = sys.argv[1] if len(sys.argv) >= 2 else "event_topic"

def main(topic_name=topic_name1):
    get_min = "-2"
    get_max = "-1"
    cm = ConfigManager()
    kafka_client_conf = cm.get_client_conf("sp", "kafka")
    broker_list = kafka_client_conf['broker_list']
    print("kafka 集群 brokers：%s" %broker_list)
    broker_host=broker_list[0].split(':',1)[0]
    # 获取 ssh 端口
    try:
        from hyperion_client.node_info import NodeInfo
        ssh_port = NodeInfo().get_node_ssh_port(hostname=broker_host)
    except Exception:
        ssh_port = 22
    # 获取 topic 最大最小 offset
    #     show_partition_min_offset_cmd="""/sensorsdata/main/program/kafka/kafka/kafka_broker/bin/kafka-run-class.sh kafka.tools.GetOffsetShell --topic %s --time %s --broker-list %s 2>/dev/null | awk -F ':' '{print $2","$3}' | sort -t ',' -k1 -n""" %(topic_name,get_min,broker_list[0])
    show_partition_min_offset_cmd="""kafka-run-class kafka.tools.GetOffsetShell --topic %s --time %s --broker-list %s 2>/dev/null | awk -F ':' '{print $2","$3}' | sort -t ',' -k1 -n""" %(topic_name,get_min,broker_list[0])
    show_partition_max_offset_cmd="""kafka-run-class kafka.tools.GetOffsetShell --topic %s --time %s --broker-list %s 2>/dev/null | awk -F ':' '{print $2","$3}' | sort -t ',' -k1 -n""" %(topic_name,get_max,broker_list[0])
    ssh_client = SSHClient(hostname=broker_host,port=ssh_port)
    min_res = ssh_client.run_cmd(show_partition_min_offset_cmd)
    max_res = ssh_client.run_cmd(show_partition_max_offset_cmd)
    topic_min_list=min_res["stdout"].strip().split('\r\n')
    topic_max_list=max_res["stdout"].strip().split('\r\n')
    topic_info = {
        topic_name:{
            "min":{},
            "max":{}
        }
    }
    for line in topic_min_list:
        topic_info[topic_name]["min"][line.split(',')[0]]=line.split(',')[1]
    for line in topic_max_list:
        topic_info[topic_name]["max"][line.split(',')[0]]=line.split(',')[1]
    print(topic_info)
    distinct_kafka_partition_id=len(topic_info[topic_name]["min"])

    partition_num = len(topic_info[topic_name]["max"])
    def get_kafka_progress_from_skv(topic_name, partition_num):
        data_loader_skv_offset_info = {
            topic_name:{
            }
        }
        for partition_id in range(partition_num):
            hash_key = "{}_{}_kc_progress".format(topic_name, partition_id)
            value = int(skvApi.get_kv('sdf_meta_data', hash_key, 'end_offset'))

            data_loader_skv_offset_info[topic_name][partition_id]=value
        return data_loader_skv_offset_info

    # 获取 dl 消费进度
    # 判断版本
    local_version = DeployTopo().get_product_major_version('sdf')[:3]
    sp_local_version = DeployTopo().get_product_major_version('sp')[:3]

    # 版本是2.3的逻辑，dl 进度在 skv
    if "2.3" == local_version or "2.4" == local_version:
        # 判断 dl 消费进度和 kafka offset 对比
        # skv admin tool
        file_name, logger = utils.sa_utils.init_runtime_logger('sdf', 'get_data_loader_offset')
        if os.environ.get('SKV_HOME') and sp_local_version == "2.0":
            sys.path.append(os.path.join(os.environ['SKV_HOME'], 'admintools'))
            from skv_admin_api import SkvAdminApi
            skv_shell_cmd = """$SKV_HOME/skv_offline/tools/run.sh shell --cluster $(spadmin config get server -m skv_offline -n meta_server_list -p skv 2>&1 | grep "^ " | sed 's/"//g;s/ *$//g' | awk '{print $1}' | xargs | sed 's/ //g')"""
        elif os.environ.get('SKV_HOME') and float(sp_local_version) > 2.0:
            sys.path.append(os.path.join(os.environ['SENSORS_PLATFORM_HOME'], 'commlibs/inflibs'))
            from skv_api import SkvApi as SkvAdminApi
            skv_shell_cmd = """未提供"""
        else:
            sys.path.append(os.path.join(os.environ['SENSORS_PLATFORM_HOME'], 'admintools/skv_tools'))
            from skv_admin_api import SkvAdminApi
            skv_shell_cmd = """$SENSORS_PLATFORM_HOME/skv_offline/tools/run.sh shell --cluster $(spadmin config get server -m skv_offline -n meta_server_list -p sp 2>&1 | grep "^ " | sed 's/"//g;s/ *$//g' | awk '{print $1}' | xargs | sed 's/ //g')"""

        skvApi = SkvAdminApi(logger, 'skv_offline')
        kafka_conf = ConfigManager().get_client_conf("sp", "kafka")
        dl_skv_progress = get_kafka_progress_from_skv(topic_name, partition_num)
        max_miss_count = 0
        min_miss_count = 0
        ca = {}
        for key in dl_skv_progress[topic_name].keys():
            dl_skv_progress_offset = int(dl_skv_progress[topic_name][key])
            min_kafka_offset = int(topic_info[topic_name]["min"][str(key)])
            max_kafka_offset = int(topic_info[topic_name]["max"][str(key)])
            topic_partition_info="%s-%s" %(topic_name,key)
            step_info={topic_partition_info:{}}
            step_info[topic_partition_info]["dl_progress"] = dl_skv_progress_offset
            step_info[topic_partition_info]["kafka_max_offset"] = max_kafka_offset
            step_info[topic_partition_info]["update_sql"] = "multi_set %s_%s_kc_progress end_offset %s wal_offset %s" %(topic_name,key,max_kafka_offset,max_kafka_offset)
            max_miss_count += max_kafka_offset - dl_skv_progress_offset
            ca.update(step_info)
            if dl_skv_progress_offset < min_kafka_offset:
                min_miss_count += min_kafka_offset - dl_skv_progress_offset

        if min_miss_count > 0:
            config_set_cmd = "sbpadmin business_config -a set -p sdf -n data_loader -k kafka_auto_offset_reset_strategy -v earliest; aradmin restart -m data_loader -p sdf" if  is_ge_sp2_1_version() else "spadmin config set server -m data_loader -p sdf -n kafka_auto_offset_reset_strategy -v earliest; spadmin restart -m data_loader -p sdf"
            msg_log = '{"msg": "offset 超了需要跳 offset 预计丢失：%s 条数据，跟客户成功说明后在操作跳过！", "way":"%s ; 待延迟恢复后，删除该配置：spadmin config delete server -m data_loader -p sdf -n kafka_auto_offset_reset_strategy "}' %(min_miss_count,config_set_cmd)
        else:
            ca["msg"]="如需 offset 跳到最大，预计丢失：%s 条数据，跟客户成功说明后在操作！" %max_miss_count
            ca["step1"]="停 dl：spadmin stop -m data_loader -p sdf  注意：再次执行该脚本！！！"
            ca["step2"]="再次执行脚本：python3 modify_kafka_offset.py "
            ca["step3"]="""进入skv shell：%s""" %skv_shell_cmd
            ca["step4"]="切换到表：use sdf_meta_data"
            ca["step5"]="根据提示update sql 更新到最大进度"
            ca["step6"]="启动 dl：spadmin start -m data_loader -p sdf "
            msg_log = json.dumps(ca)
        print(json.dumps(json.loads(msg_log), indent=2,ensure_ascii=False))

    else:
        ca = {}
        min_miss_count = 0
        max_miss_count = 0
        get_data_loader_offset_cmd="""sa_mysql -B -N -e 'select topic,kafka_partition_id,end_offset, id from batch_loader_kafka_progress where id in (select max(id) as id from batch_loader_kafka_progress where topic = "%s" group by kafka_partition_id);' 2>/dev/null | sort -k1 -n | awk '{print $1","$2","$3","$4}'""" %(topic_name)
        get_data_loader_offset_res = ssh_client.run_cmd(get_data_loader_offset_cmd)
        get_data_loader_offset_data=get_data_loader_offset_res["stdout"].strip().split('\r\n')
        data_loader_offset_info = {
            topic_name:{
            }
        }
        for line in get_data_loader_offset_data:
            data_loader_offset_info[topic_name][line.split(',')[1]]=line.split(',')[2] + "_" + line.split(',')[3]
        print(data_loader_offset_info)
        # 判断 dl 消费进度和 kafka offset 对比
        for key in data_loader_offset_info[topic_name].keys():
            data_loader_offset = data_loader_offset_info[topic_name][key].split('_')[0]
            kc_dl_id = data_loader_offset_info[topic_name][key].split('_')[1]
            min_kafka_offset = topic_info[topic_name]["min"][key]
            max_kafka_offset = topic_info[topic_name]["max"][key]
            topic_partition_info="%s-%s" %(topic_name,key)
            step_info={topic_partition_info:{}}
            step_info[topic_partition_info]["dl_progress"] = data_loader_offset
            step_info[topic_partition_info]["kafka_max_offset"] = max_kafka_offset
            step_info[topic_partition_info]["update_sql"] = "update batch_loader_kafka_progress set start_offset=%s,end_offset=%s where id = %s;" %(max_kafka_offset,max_kafka_offset,kc_dl_id)
            max_miss_count += int(max_kafka_offset) - int(data_loader_offset)
            ca.update(step_info)
            if int(data_loader_offset) < int(min_kafka_offset):
                min_miss_count += int(min_kafka_offset) - int(data_loader_offset)
        if min_miss_count > 0:

            msg_log = '{"msg": "offset 超了需要跳 offset 预计丢失：%s 条数据，跟客户成功说明后在操作跳过！", "way":"spadmin config set server -m data_loader -p sdf -n kafka_auto_offset_reset_strategy -v earliest; spadmin restart -m data_loader -p sdf ; 待延迟恢复后，删除该配置：spadmin config delete server -m data_loader -p sdf -n kafka_auto_offset_reset_strategy ，然后重启 dl 生效"}' %(min_miss_count)
        else:
            ca["msg"]="如需 offset 跳到最大，预计丢失：%s 条数据，跟客户成功说明后在操作！" %max_miss_count
            ca["step1"]="停 dl：spadmin stop -m data_loader -p sdf "
            ca["step2"]="再次执行该脚本 python3 modify_kafka_offset.py" 
            ca["step3"]="注意根据需要选择执行，例如差异的分区，若不确定联系导入专项运维" 
            ca["step4"]="进入 mysql 终端：sa_mysql;然后执行对应topic-分区 update sql 语句"
            ca["step5"]="启动 dl：spadmin start -m data_loader -p sdf "
            msg_log = json.dumps(ca)
        print(json.dumps(json.loads(msg_log), indent=2,ensure_ascii=False))

if __name__ == '__main__':
    main()