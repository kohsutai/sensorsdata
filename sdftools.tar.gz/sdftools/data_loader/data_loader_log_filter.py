# 各节点上进行日志过滤的脚本，由data_loader_log_filter_assigner分发并进行调用。

# filter 传入日志类型，起始时间，结束时间 =》 将日志文件保存在指定路径
# python3 /tmp/data_loader_log_filter.py  {log_type} {stime} {etime}
import datetime
import json
import os
import re
import shlex
import subprocess
from sys import argv


class DataLoaderLogFilter:
    def __init__(self, log_type, stime: datetime.datetime, etime: datetime.datetime):
        self.log_type = log_type
        self.stime = stime
        self.etime = etime
        self.date_format_parsing_pattern = re.compile(r'(\d{4}-\d{2}-\d{2}).*?(\d{2}:\d{2}:\d{2})')

    def __parse_date_format(self, log_content: str) -> datetime.datetime:
        """
        从一行日志中提取时间
        :param log_content: 文本形式的日志内容
        :return: datetime.datetime类型的时间
        """

        res_group = re.search(self.date_format_parsing_pattern, log_content)
        if not res_group or len(res_group.groups()) < 2:
            return None
        log_time = res_group.group(1) + " " + res_group.group(2)
        log_time = datetime.datetime.strptime(log_time, "%Y-%m-%d %H:%M:%S")
        return log_time

    def parse_log(self, stime: datetime.datetime, log_file: str) -> int:
        """
        根据给定的时间，在日志文件中进行二分查找，找到符合时间的行
        :param stime: 给定的时间，以该时间为开始
        :param log_file: 日志文件路径
        :return: 日志行
        """
        line_offset = []  # 索引为行数(从0开始)，值为偏移量
        f_log_file = open(log_file, "r+")

        line_offset.append(0)  # 第一行offset为0
        line = f_log_file.readline()
        while line:
            offset = f_log_file.tell()
            line_offset.append(offset)
            line = f_log_file.readline()
        line_number = len(line_offset)

        target_line = 0
        start_line, end_line = 0, line_number
        while start_line <= end_line:
            if end_line - start_line <= 1:
                # 未精确到匹配时间的情况
                target_line = start_line
                break
            mid_line = (start_line + end_line) // 2
            f_log_file.seek(line_offset[mid_line])
            mid_date_time = self.__parse_date_format(f_log_file.readline())

            # 未解析出时间的情况
            while mid_date_time is None and mid_line >= start_line:
                mid_line -= 1
                f_log_file.seek(line_offset[mid_line])
                mid_date_time = self.__parse_date_format(f_log_file.readline())

            if mid_line < start_line:
                # print("未找到指定时间的日志")
                exit(1)

            if stime < mid_date_time:
                end_line = mid_line - 1
            elif stime > mid_date_time:
                start_line = mid_line + 1
            else:
                target_line = mid_line
                break
        f_log_file.close()

        return target_line

    def cmd_exec(self, cmd: str):
        if not isinstance(cmd, str):
            # print(f"ERR {__file__} {self.__class__.__name__} 执行命令传入的参数不为字符串。")
            return None

        # CompletedProcess(args=['whoami'], returncode=0, stdout=b'sa_cluster\n', stderr=b'')
        cmd_res = subprocess.run(shlex.split(cmd), capture_output=True)
        return cmd_res

    def run(self) -> json:
        exec_result = {"cmd_list": [], "cmd_return_code_status_list": [], "final_status": "SUCCESS"}
        """
            {"cmd_list": [cmd1, cmd2, cmd3, ...],
             "cmd_return_code_status_list": [0, -1, 0, ...], 
             "final_status": "SUCCESS",
            }
        """
        cmd_list = exec_result.get("cmd_list")
        cmd_return_code_status_list = exec_result.get("cmd_return_code_status_list")

        dl_log_path = os.environ.get('SENSORS_DATAFLOW_LOG_DIR') + "/data_loader/"
        cmd = f"ls {dl_log_path}|grep {self.log_type}"  # 获取路径下所有该日志类型的日志
        cmd_list.append(cmd)

        cmd_res = self.cmd_exec(cmd)
        cmd_return_code_status_list.append(cmd_res.returncode)
        log_type_files = cmd_res.stdout.decode("utf8").strip().split("\n")

        # 通过起始时间、结束时间，过滤出日志。基于理论上各日志的时间范围无交集
        log_type_files = sorted(log_type_files, key=lambda f: os.path.getmtime(f))

        specific_time_range_log_files = []  # 该时间范围内的日志文件列表
        for i in range(len(log_type_files)):
            file_create_time = os.path.getctime(log_type_files[i])
            file_last_modified_time = os.path.getmtime(log_type_files[i])
            if file_create_time <= self.stime.timestamp() <= file_last_modified_time:
                # 找到开始时间对应的日志文件
                specific_time_range_log_files.append(log_type_files[i])
                if self.etime.timestamp() > file_last_modified_time:
                    # 若结束时间超过了最后修改时间，说明还需要继续看后面的日志文件
                    j = i + 1
                    while j < len(log_type_files) and self.etime.timestamp() > os.path.getmtime(log_type_files[j]):
                        specific_time_range_log_files.append(log_type_files[j])

        store_dir = "/tmp/"
        log_line_number_threshhold = 100000
        if len(specific_time_range_log_files) == 1:
            log_file = specific_time_range_log_files[0]
            store_dir += log_file
            cmd = f"cp {dl_log_path}{log_file} {store_dir}"
            cmd_list.append(cmd)
            cmd_res = self.cmd_exec(cmd)
            cmd_return_code_status_list.append(cmd_res.returncode)
        else:
            # stime处于第一个日志文件时间区间，etime处于最后一个日志文件时间区间
            stime_log_file, etime_log_file = specific_time_range_log_files[0], specific_time_range_log_files[-1]
            stime_log_file_target_line = self.parse_log(self.stime, stime_log_file)
            etime_log_file_target_line = self.parse_log(self.etime, etime_log_file)

            cmd = "wc -l %s |awk '{print $1}'" % stime_log_file
            cmd_list.append(cmd)
            cmd_res = self.cmd_exec(cmd)
            cmd_return_code_status_list.append(cmd_res.returncode)
            stime_log_file_total_line = int(cmd_res.stdout.decode("utf8").strip())

            # current_line_numbers = (stime_log_file_total_line - stime_log_file_target_line + 1) + etime_log_file_target_line
            current_line_numbers = stime_log_file_total_line - stime_log_file_target_line + 1
            if current_line_numbers >= log_line_number_threshhold:
                # 仅从第一个日志文件的target_line向后取10w条日志即可
                cmd = f"tail -n {current_line_numbers} f{stime_log_file}| head -n 100000 > {store_dir + self.log_type}"
                cmd_list.append(cmd)
                cmd_res = self.cmd_exec(cmd)
                cmd_return_code_status_list.append(cmd_res.returncode)
                return exec_result

            # def cat_threshold_line_number_log():
            #     remained_line_numbers = log_line_number_threshhold - (
            #                 stime_log_file_total_line - stime_log_file_target_line + 1)
            #     index = 1
            #     # 首先将stime_log_file的对应日志取出
            #     cmd = f"tail -n {stime_log_file_total_line - stime_log_file_target_line + 1} {stime_log_file} > /tmp/{self.log_type}"
            #     cmd_list.append(cmd)
            #     cmd_res = self.cmd_exec(cmd)
            #     cmd_return_code_status_list.append(cmd_res.returncode)
            #     while remained_line_numbers > 0 and index < len(specific_time_range_log_files):
            #         cmd = "wc -l %s |awk '{print $1}'" % specific_time_range_log_files[index]
            #         cmd_list.append(cmd)
            #         cmd_res = self.cmd_exec(cmd)
            #         cmd_return_code_status_list.append(cmd_res.returncode)
            #         current_file_lines = int(cmd_res.stdout.decode("utf8").strip())
            #         if current_file_lines > remained_line_numbers:
            #             cmd = f"head -n {remained_line_numbers} {specific_time_range_log_files[i]} >> /tmp/{self.log_type}"
            #             cmd_list.append(cmd)
            #             cmd_res = self.cmd_exec(cmd)
            #             cmd_return_code_status_list.append(cmd_res.returncode)
            #             break
            #         else:
            #             cmd = f"cat {specific_time_range_log_files[i]} >> /tmp/{self.log_type}"
            #             cmd_list.append(cmd)
            #             cmd_res = self.cmd_exec(cmd)
            #             cmd_return_code_status_list.append(cmd_res.returncode)
            #             remained_line_numbers -= current_file_lines
            #         index += 1

            # if current_line_numbers > log_line_number_threshhold:
            #     # 超过阈值。仅取十万条
            #     cat_threshold_line_number_log()
            #     return

            cmd = f"tail -n {current_line_numbers} {stime_log_file} > {store_dir + self.log_type}"
            cmd_list.append(cmd)
            cmd_res = self.cmd_exec(cmd)
            cmd_return_code_status_list.append(cmd_res.returncode)

            # 依次向后遍历日志文件，判断目前行数是否超阈值10w条，超过则只取到10w条。
            for i in range(1, len(specific_time_range_log_files) - 1):
                cmd = "wc -l %s |awk '{print $1}'" % specific_time_range_log_files[i]
                cmd_list.append(cmd)
                cmd_res = self.cmd_exec(cmd)
                cmd_return_code_status_list.append(cmd_res.returncode)
                if current_line_numbers + int(cmd_res.stdout.decode("utf8").strip()) > log_line_number_threshhold:
                    # 超过阈值。仅取[到]十万条
                    # 更新
                    cmd = f"head -n {log_line_number_threshhold - current_line_numbers} >> {store_dir + self.log_type}"
                    cmd_list.append(cmd)
                    cmd_res = self.cmd_exec(cmd)
                    cmd_return_code_status_list.append(cmd_res.returncode)

                    # cat_threshold_line_number_log()
                    break
                else:
                    # 总行数未超过阈值。该文件全部取
                    cmd = f"cat {specific_time_range_log_files[i]} >> /tmp/{self.log_type}"
                    cmd_list.append(cmd)
                    cmd_res = self.cmd_exec(cmd)
                    cmd_return_code_status_list.append(cmd_res.returncode)
                    current_line_numbers += int(cmd_res.stdout.decode("utf8").strip())

            if current_line_numbers < log_line_number_threshhold:
                cmd = f"head -n {etime_log_file_target_line} >> {store_dir + self.log_type}"
                cmd_list.append(cmd)
                cmd_res = self.cmd_exec(cmd)
                cmd_return_code_status_list.append(cmd_res.returncode)
        if __name__ == "__main__":
            print(exec_result)
        return exec_result


if __name__ == "__main__":
    try:
        log_type, stime, etime = argv[1], argv[2], argv[3]
        stime = datetime.datetime.strptime(stime, "%Y-%m-%d %H:%M:%S")
        etime = datetime.datetime.strptime(etime, "%Y-%m-%d %H:%M:%S")
    except IndexError as ie:
        # print(ie)
        exit(1)
    except ValueError as ve:
        # print(ve)
        exit(1)
    except Exception as e:
        # print(e)
        exit(1)
    else:
        DataLoaderLogFilter(log_type, stime, etime).run()
