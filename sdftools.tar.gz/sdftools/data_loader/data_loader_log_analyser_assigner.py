import json
import os
import socket
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'common')))
from ssh_client import SSHClient
from colored_logging import get_logger
from multiprocessing import Pool

logger = get_logger(__name__)


class DataLoaderLogAnalyserAssigner:
    """
    用于分发问题检查脚本data_loader_log_analyser、触发各节点上的脚本执行
    """

    def __init__(self, host_set: set):
        """

        :param worker_host: 主机名
        :param log_file: 日志文件
        """

        # 获取 ssh 端口
        try:
            from hyperion_client.node_info import NodeInfo
            self.ssh_port = NodeInfo().get_node_ssh_port(hostname=socket.getfqdn())
        except Exception:
            self.ssh_port = 22

        self.host_set = host_set

    def prepare_env(self) -> bool:

        # 分发问题检查脚本
        data_loader_json = os.path.abspath(os.path.join(os.path.dirname(__file__), "data_loader.json"))
        analysis_tool = os.path.abspath(os.path.join(os.path.dirname(__file__), "data_loader_log_analyser.py"))

        for hostname in self.host_set:
            cmd = f"scp -P {self.ssh_port} {data_loader_json} {analysis_tool} {hostname}:/tmp/"
            res = os.popen(cmd)

        # err = res["stderr"]
        # if err:
        #     print("分发问题检查脚本时出错，异常信息：", err)
        #     return False
        return True

    def do_log_analyze(self, hostname: str, log_mtime,log_file: str):
        knowledge_file = "/tmp/data_loader.json"
        # print(hostname,log_mtime,log_file,knowledge_file)
        cmd = f"python3 /tmp/data_loader_log_analyser.py {hostname} {log_mtime} {log_file} {knowledge_file}"

        ssh_client = SSHClient(hostname=hostname, port=self.ssh_port)
        # return {'host': self.params['hostname'], 'cmd': cmd, 'ret': ret, 'stdout': stdout, 'stderr': stderr}
        res = ssh_client.run_cmd(cmd)
        err = res["stderr"]
        if err:
            logger.error("问题检查脚本执行时出错，异常信息：", err)
            return None
        if res["stdout"]:
            return json.loads(res["stdout"])
        else:
            return json.loads("{}")

    def run(self, *args):
        """
        触发各节点上的日志分析脚本执行
        :return:
        """
        with Pool(5) as p:
            log_analysis_res_list = p.starmap(self.do_log_analyze, *args)

        log_analysis_res = dict()
        for per_analysis_dict in log_analysis_res_list:
            for log_type in per_analysis_dict.keys():
                log_analysis_res[log_type] = per_analysis_dict[log_type]

        return log_analysis_res
