# encoding: utf-8

# @File    : data_loader.py
# @Date    : 2022年10月23日06:56:36
# @Author  : liuxiaopeng
# @Desc:   : data_loader 问题排查工具，输出更加详细，相比 op_check_data_loader 更加耗时是其 3 到 4 倍（30 ~ 60）s

import os,sys
import json
import socket
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'common')))
from colored_logging import get_logger
logger = get_logger(__name__)
import collect_sdf_log as collect
# import argparse
# import datetime
from all_dl_info import dl_info
from get_mem_cpu_disk_info import sys_info
from date_tools import shuzi,chuo
from sdf_utils import sdf_major_version
from all_dl_info import get_sdftools_version
from all_dl_info import optimizable_items
from handle_json_data import PrintToScreen
from data_loader_log_analyser_assigner import DataLoaderLogAnalyserAssigner
# from data_loader_log_filter_assigner import DataLoaderLogFilterAssigner
from ssh_client import SSHClient
from data_loader_log_analyser import DataLoaderLogAnalyser
import re

def main():
    # 生成知识库 json 文件后存放位置
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    # extractor_knowledge_path = BASE_DIR + "/../extractor/extractor.json"
    dl_knowledge_path = BASE_DIR + "/../data_loader/data_loader.json"
    # 参数解析
    # parser = argparse.ArgumentParser(
    #     description='诊断环境data_loader问题',
    # )
    # parser.add_argument('-m', '--module', dest="module", 
    #                     type=str,default="data_loader",
    #                     help="诊断 data_loader 问题")
    # # 日期为datetime.datetime格式
    # parser.add_argument('-s', '--stime', dest="stime", metavar="YY-mm-dd HH:MM:SS",
    #                     type=lambda t: datetime.datetime.strptime(t, "%Y-%m-%d %H:%M:%S"),
    #                     help="指定开始日期，例如2000-01-01 10:00:00，诊断从该日期开始的最近日志，默认为现在。")
    # parser.add_argument('-e', '--etime', dest="etime", metavar="YY-mm-dd HH:MM:SS",
    #                     type=lambda t: datetime.datetime.strptime(t, "%Y-%m-%d %H:%M:%S"),
    #                     help="指定结束日期，例如2000-01-02 10:00:00，诊断到该日期结束的最近日志，默认为现在。")
    # parser.add_argument('-v', '--verbose',dest="verbose",type=str,default="simple",choices=["simple","detail"],help="-v simple 输出简单模式，-v detail 输出详细模式")
    # args = parser.parse_args()

    # if args.module == "data_loader":
    #     logger.info("排查 data_loader 组件问题")
    # 打印 sdftools 版本
    logger.info("""sdftools version: "%s" """ %get_sdftools_version())

    # 将 dl 日志拉取到本地
    logger.info("将 dl 日志拉取到本地")
    # log_res = collect.collect()
    logtype2_host_and_logname = collect.collect()    # 映射关系。key为日志类型，value元组(日志所在的主机名，日志名称). E.g {'master.log': (data01, master.log_20000101)}
    total_info = {}

    # 获取系统资源信息
    logger.info("获取系统资源信息")
    sys_info1 = sys_info()
    total_info.update(sys_info1)

    # 获取优化信息
    logger.info("获取优化信息")
    optz_info = optimizable_items()
    if len(optz_info["Optimizable_items"].keys()) >=1:
        total_info.update(optz_info)

    # 获取 data_loader 相关信息
    logger.info("获取 data_loader 相关信息")
    dl_info1 = dl_info()
    total_info.update(dl_info1)


    # dl 日志路径定义，依赖于 collect.collect()
    sdf_log_path = "/tmp/sdflogs"

    if sdf_major_version() == "2.4":
        dl_log_info = ["master.log","master.out","worker_kafka_consumer.out","worker_kafka_consumer.log","worker_kudu_to_parquet.out","worker_kudu_to_parquet.log","worker_project_manager.out","worker_project_manager.log","worker_maintenance.out","worker_maintenance.log","event_kc_mr.log","item_kc_mr.log","profile_kc_mr.log","merge_mr.log","distinct_mr.log","delete_mr.log","k2p_mr.log","remapping_mr.log","command_mr.log"]
    else:
        dl_log_info = ["master.log","master.out","kafka_consumer.out","worker_kafka_consumer.log","kudu_to_parquet.out","worker_kudu_to_parquet.log","project_manager.out","worker_project_manager.log","maintenance.out","worker_maintenance.log","event_kc_mr.log","item_kc_mr.log","profile_kc_mr.log","merge_mr.log","distinct_mr.log","delete_mr.log","k2p_mr.log","remapping_mr.log","command_mr.log"]


    logger.info("解析日志数据")


    host_set = set()
    for hostname, _, __ in logtype2_host_and_logname.values():
        host_set.add(hostname)

    # 未指定开始时间，则对log日志取最后10w条日志，对out日志取最后50条日志。
    try:
        from hyperion_client.node_info import NodeInfo

        ssh_port = NodeInfo().get_node_ssh_port(hostname=socket.getfqdn())
    except Exception:
        ssh_port = 22

    for hostname, _,logname in logtype2_host_and_logname.values():
        ssh_client = SSHClient(hostname=hostname, port=ssh_port)
        if re.search(r'\w+\.log', logname):
            cmd = f"tail -n 100000 {logname} > /tmp/{logname.split('/')[-1]}"
        elif re.search(r'\w+\.out', logname):
            cmd = f"tail -n 50 {logname} > /tmp/{logname.split('/')[-1]}"
        else:
            cmd = f"tail -n 100000 {logname} > /tmp/{logname.split('/')[-1]}"
        ssh_client.run_cmd(cmd)

    # 日志分析
    data_log_log_analyzer_worker = DataLoaderLogAnalyserAssigner(host_set)
    data_log_log_analyzer_worker.prepare_env()

    args2 = []
    for hostname,log_mtime, logname in logtype2_host_and_logname.values():
        args2.append((hostname,log_mtime, "/tmp/" + logname.split("/")[-1]))

    analysis_result = data_log_log_analyzer_worker.run(args2)


    # YARN FAILED KILLED任务原因分析。日志已拉取到当前节点
    yarn_failed_killed_job_logs = ["sdw_input.log","event_kc_mr.log","item_kc_mr.log","profile_kc_mr.log","merge_mr.log","distinct_mr.log","delete_mr.log","k2p_mr.log","remapping_mr.log","command_mr.log","distcp_mr.log","mutable_mr.log","device_id_remapping_mr.log"]
    for yarn_failed_killed_job_log in yarn_failed_killed_job_logs:
        analyze_result = DataLoaderLogAnalyser.analyse(socket.getfqdn(),int(chuo()), "/tmp/sdflogs/"+ yarn_failed_killed_job_log, dl_knowledge_path)
        analyze_result = json.loads(analyze_result)
        if analyze_result.get(yarn_failed_killed_job_log):
            analyze_result[yarn_failed_killed_job_log].pop("hostname")
            analyze_result[yarn_failed_killed_job_log].pop("last_updated_time")
            total_info.update(analyze_result)

    total_info.update(analysis_result)

    msg_log = json.dumps(total_info)
    shuzi1 = shuzi()
    # msg_log = json.dumps(analysis_result)   # 传入字典，非列表
    file_name = "/tmp/sdflogs/op_check_data_loader_" + shuzi1 + ".log"
    tmp_file_name = "/tmp/op_check_data_loader_" + shuzi1 + ".log"
    tmp_file_detail_name = "/tmp/op_check_data_loader_" + shuzi1 + "detail.log"
    file_detail_name = "/tmp/sdflogs/op_check_data_loader_" + shuzi1 + "_detail.log"
    simple_or_detail = True
    PrintToScreen(file_name=file_name,tmp_file_name=tmp_file_name,tmp_file_detail_name=tmp_file_detail_name,file_detail_name=file_detail_name,msg_log=msg_log,total_info=total_info,simple_or_detail=simple_or_detail)
    logger.info("查看详细信息请执行：cat %s" %file_detail_name)

if __name__ == '__main__':
    main()

