# encoding: utf-8

# @File    : op_check_sdf.py
# @Date    : 2024年08月10日20:47:43
# @Author  : liuxiaopeng
# @desc    : sdf 问题排查工具

import os,sys
import argparse
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), 'common')))
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), 'data_loader')))
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), 'extractor')))
from extractor import check_extractor
from data_loader import check_data_loader
from data_loader import modify_kafka_offset
from data_loader import sdf_optimizing_configuration

from hyperion_client.config_manager import ConfigManager

topic_map={
    "event":"topic_name",
    "profile":"profile_topic_name",
    "remapping":"sdf_remapping_topic_name",
    "item":"item_topic_name",
    "command":"sdf_id_mapping_v3_command_topic_name",
    "mutable":"sdf_mutable_event_topic_name"
           }

usage = """
- - - - - - - - - - - - - - - sdftools 常用场景 - - - - - - - - - - - - - - - 

1. 检查 data_loader 问题
python3 op_check_sdf.py -m dl/data_loader

2. 检查 extractor 问题，注意在校验异常节点执行！！！
python3 op_check_sdf.py -m ex/extractor

3. dl 组件参数调优
python3 op_check_sdf.py -m opt

4. 查看 topic offset 信息和 dl 进度信息
python3 op_check_sdf.py -m kafka -t event/profile/item/remapping/command/mutable

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -"""
parser = argparse.ArgumentParser(
        description=usage, formatter_class=argparse.RawTextHelpFormatter)

# 创建一个参数组
group = parser.add_argument_group('Options')

group.add_argument('-m', '--module', dest="module", type=str, default="data_loader",choices=["data_loader","extractor","opt","kafka","dl","ex"], help="指定类型: 1、data_loader 检测 data_loader 问题 2、extractor 检测 extractor 问题 3、opt 参数优化，目前仅支持 dl 参数优化")
# 添加第二个参数，根据第一个参数值的不同而限定取值范围
if parser.parse_known_args()[0].module == 'kafka':
    group.add_argument('-t', '--type', dest="type", type=str, default="event",choices=["event","profile","item","remapping","command","mutable"], help="指定 topic 类型")


args = parser.parse_args()

module1 = args.module

if module1 == "data_loader" or module1 == "dl":
    check_data_loader.main()
elif module1 == "extractor" or module1 == "ex":
    check_extractor.main()
elif module1 == "kafka":
    type1 = args.type
    topic_name = ConfigManager().get_client_conf("sp", "kafka")[topic_map[type1]]
    modify_kafka_offset.main(topic_name=topic_name)
elif module1 == "opt":
    sdf_optimizing_configuration.main()