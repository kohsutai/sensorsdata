#!/bin/sh

export target_hdfs_path=/etl_sa/etl/etl_sa/uetl_sa/repartition

export kinit_kt=/data/keytabs/sensors.keytab

export kinit_user=sensors@ITRD.RD








