package com.sensorsdata.etl.utils;

import junit.framework.TestCase;

import java.util.List;

public class SQLUtilTest extends TestCase {

    public void testGetCreateSql() {
        String sql = FileHandleUtil.readFile("D:\\ProgectRepertory\\taiwan\\bank_sinopac_data_repartition\\src\\main\\resources\\sql");
        List<String> list = SQLUtil.getRepartitionCreateSqlParams(sql);
        System.out.println(list);
    }
}