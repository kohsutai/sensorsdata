package com.sensorsdata.etl.utils;

import junit.framework.TestCase;

import java.util.List;

public class FileHandleUtilTest extends TestCase {

    public void testReadFile() {
        String sql = FileHandleUtil.readFile("D:\\ProgectRepertory\\taiwan\\bank_sinopac_data_repartition\\src\\main\\resources\\sql");
    }
}