package com.sensorsdata.etl.enums;

import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author tangchun
 * @version 1.0.0
 * @since 2022/10/25 16:37
 */
public enum VerifyEnum {

  DATE_FORMAT_VERIFY_Y_M_D(o -> {
    String format = "yyyy-MM-dd";
    if(o == null || o.toString().length() != format.length()){
      return false;
    }
    String dateRegex = "((19|20)[0-9]{2})-(0?[1-9]|1[012])-(0?[1-9]|[12][0-9]|3[01])";
    Pattern pattern = Pattern.compile(dateRegex) ;
    Matcher matcher = pattern.matcher(o.toString()) ;
    if(matcher.matches() ) {
      pattern = Pattern.compile("(\\d{4})-(\\d{2})-(\\d{2}).*" ) ;
      matcher = pattern.matcher(o.toString()) ;
      if(matcher.matches() ) {
        int y = Integer.parseInt(matcher.group(1 ) ) ;
        int m = Integer.parseInt(matcher.group(2 ) ) ;
        int d = Integer.parseInt(matcher.group(3 ) ) ;
        if(d > 28 ) {
          Calendar c = Calendar.getInstance() ;
          c.set(y , m - 1 , 1 ) ;
          int lastDay = c.getActualMaximum(Calendar.DAY_OF_MONTH ) ;
          return(lastDay >= d ) ;
        }
      }
      return true ;
    }
    return false ;
  },"校验日期格式，yyyy-MM-dd"),

  DATE_FORMAT_VERIFY_YMD(o -> {
    String format = "yyyyMMdd";
    if(o == null || o.toString().length() != format.length()){
      return false;
    }
    String dateRegex = "((19|20)[0-9]{2})(0?[1-9]|1[012])(0?[1-9]|[12][0-9]|3[01])";
    Pattern pattern = Pattern.compile(dateRegex) ;
    Matcher matcher = pattern.matcher(o.toString()) ;
    if(matcher.matches() ) {
      pattern = Pattern.compile("(\\d{4})(\\d{2})(\\d{2}).*" ) ;
      matcher = pattern.matcher(o.toString()) ;
      if(matcher.matches() ) {
        int y = Integer.parseInt(matcher.group(1 ) ) ;
        int m = Integer.parseInt(matcher.group(2 ) ) ;
        int d = Integer.parseInt(matcher.group(3 ) ) ;
        if(d > 28 ) {
          Calendar c = Calendar.getInstance() ;
          c.set(y , m - 1 , 1 ) ;
          int lastDay = c.getActualMaximum(Calendar.DAY_OF_MONTH ) ;
          return(lastDay >= d ) ;
        }
      }
      return true ;
    }
    return false ;
  },"校验日期格式，yyyyMMdd");

  private MathOperation mathOperation;

  private String msg;

  VerifyEnum(MathOperation mathOperation, String msg) {
    this.mathOperation = mathOperation;
    this.msg = msg;
  }

  interface MathOperation {
     boolean operation(Object o);
  }

  public  boolean operate(Object o){
    return this.mathOperation.operation(o);
  }

  public  String getMsg(){
    return this.msg;
  }

}
