package com.sensorsdata.etl.utils;

import com.alibaba.fastjson.JSON;
import com.sensorsdata.etl.exception.ShellExecuteException;
import lombok.extern.slf4j.Slf4j;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

@Slf4j
public class ShellCommandUtil {

    ShellCommandUtil(){}

    /**
     * @param pathOrCommand ：脚本路径
     * @param param      脚本参数
     * @Description: 执行shell
     * @Return: 控制台输出
     * @Date: 2022/05/30
     */
    public static List<String> execShell(String pathOrCommand, String... param) {
        List<String> result = new ArrayList<>();
        try {

            String[] cmd = new String[]{"sh", pathOrCommand};
            //为了解决参数中包含空格
            cmd = concat(cmd, param);

            log.info("---shell command:{}", JSON.toJSONString(cmd));
            ProcessBuilder builder = new ProcessBuilder(cmd);
            //错误流重定向，合并到输出，避免阻塞
            builder.redirectErrorStream(true);
            Process ps = builder.start();
            log.info("---shell log start---");
            readProcessInputStream(ps,result);
            log.info("---shell log end---");
            int exitValue = ps.waitFor();
            if (0 != exitValue) {
                log.error("call shell failed. shell path is "+pathOrCommand+",error code is :" + exitValue);
                throw new ShellExecuteException();
            }
        }catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            log.error("exec shell interrupt. shell path is "+pathOrCommand, e);
        } catch (Exception e) {
            log.error("exec shell error. shell path is "+pathOrCommand, e);
            throw new ShellExecuteException();
        }
        return result;
    }

    private static void readProcessInputStream(Process ps,List<String> lists){
        try (BufferedInputStream is = new BufferedInputStream(ps.getInputStream());BufferedReader br = new BufferedReader(new InputStreamReader(is))){
            String line;
            while ((line = br.readLine()) != null) {
                lists.add(line);
                log.info(line);
            }
        } catch (IOException e) {
            log.error("exec shell Read Process InputStream.", e);
        }
    }

    private static String[] concat(String[] a,String[] b){
        String[] c = new String[a.length + b.length];
        System.arraycopy(a, 0, c, 0, a.length);
        System.arraycopy(b, 0, c, a.length, b.length);
        return c;
    }

    /**
     * @param command ：脚本路径
     * @Description: 执行shell
     * @Return: 控制台输出
     * @Date: 2022/05/30
     */
    public static List<String> execCommand(List<String> command,String sshIp) {
        List<String> result = new ArrayList<>();
        List<String> commandList = new ArrayList<>();
        commandList .add("/bin/bash");
        commandList .add("-c");
        if(sshIp != null){
            commandList.add("ssh " + sshIp);
            commandList.add("'");
            commandList.addAll(command);
            commandList.add("'");
        }else {
            commandList .addAll(command);
        }
        try {
            log.info("开始执行:{}", JSON.toJSONString(commandList));
            ProcessBuilder builder = new ProcessBuilder(commandList);
            //错误流重定向，合并到输出，避免阻塞
            builder.redirectErrorStream(true);
            Process ps = builder.start();
            log.info("把缓冲区读出来打log  start");
            readProcessInputStream(ps,result);
            int exitValue = ps.waitFor();
            if (0 != exitValue) {
                log.error("call shell failed. shell path is "+JSON.toJSONString(commandList)+",error code is :" + exitValue);
                return new ArrayList<>();
            }
        }catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            log.error("exec shell interrupt. shell path is "+JSON.toJSONString(commandList), e);
        } catch (Exception e) {
            log.error("exec shell error. shell path is "+JSON.toJSONString(commandList), e);
        }
        return result;
    }

}
