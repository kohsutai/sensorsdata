package com.sensorsdata.etl.exception;

public class FileParseException extends RuntimeException{

    public FileParseException() {
        super();
    }

    public FileParseException(String message) {
        super(message);
    }
}
