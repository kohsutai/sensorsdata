package com.sensorsdata.etl.utils;

import lombok.extern.slf4j.Slf4j;

import java.io.File;

@Slf4j
public class BaseFileUtil {
    BaseFileUtil(){}

    /**
     *  获取shell脚本目录（{jar包目录}../script/tool）
     * @return shell脚本目录
     */
    public static String getToolShellDir() {
        return getProjectDir() + "script" + File.separator + "tool" + File.separator;
    }

    /**
     *  获取项目data目录（{jar包目录}../data）
     * @return 项目data目录
     */
    public static String getDataDir() {
        return getProjectDir() + "data" + File.separator;
    }

    /**
     *  获取项目目录（{jar包目录}../）
     * @return 项目目录
     */
    private static String getProjectDir() {
        String path = BaseFileUtil.class.getProtectionDomain().getCodeSource().getLocation().getPath();
        int firstIndex = path.lastIndexOf(System.getProperty("path.separator")) + 1;
        int lastIndex = path.lastIndexOf(File.separator);
        path = path.substring(firstIndex, lastIndex);
        lastIndex = path.lastIndexOf(File.separator) + 1;
        path = path.substring(0,lastIndex);
        return path;
    }
}
