package com.sensorsdata.etl.service.impl;

import com.sensorsdata.etl.enums.AffixEnum;
import com.sensorsdata.etl.enums.ShellNameEnum;
import com.sensorsdata.etl.service.ETLService;
import com.sensorsdata.etl.utils.BaseFileUtil;
import com.sensorsdata.etl.utils.FileHandleUtil;
import com.sensorsdata.etl.utils.SQLUtil;
import com.sensorsdata.etl.utils.ShellCommandUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Service(value = "etl_etl_server_impl")
@Slf4j
public class ETLServiceImpl implements ETLService {

    @Value("#{'${etl.tableInfoList}'.split(',')}")
    private List<String> tableInfoList;

    @Value("${etl.retainedMonths}")
    private Long retainedMonths;

    @Value("${etl.dataMoveMonths}")
    private Long dataMoveMonths;

    @Value("${etl.databasesName}")
    private String databasesName;

    @Override
    public void etlExcuse(String date) {
        for (String tableInfo : tableInfoList){
            String[] tableInfoArray = tableInfo.split("\\.");
            String sourceDatabasesName = tableInfoArray[0];
            String sourceTableName = tableInfoArray[1];
            String repartitionTableName = sourceTableName + AffixEnum.REPARTITION_TABLE_NAME_SUFFIX.getName();
            log.info("------------------------------------------repartition table {} start------------------------------------------",tableInfo);
            String shellDir = BaseFileUtil.getToolShellDir();
            log.info("------------------------------------------init------------------------------------------");
            ShellCommandUtil.execShell(shellDir+ ShellNameEnum.INIT.getName(),repartitionTableName);

            log.info("------------------------------------------select source table create  sql------------------------------------------");
            String sourceCreateSqlFileName = AffixEnum.CREATE_SOURCE_TABLE_SQL.getName() + sourceTableName;
            ShellCommandUtil.execShell(shellDir+ ShellNameEnum.HIVE_SELECT_CREATE_SQL.getName(),sourceDatabasesName,sourceTableName,sourceCreateSqlFileName);

            log.info("------------------------------------------create repartition table------------------------------------------");
            log.info("------------------------------------------repartition table name:{}------------------------------------------",repartitionTableName);
            String dataDir = BaseFileUtil.getDataDir();
            String sourceTableCreateSql = FileHandleUtil.readFile(dataDir + sourceCreateSqlFileName);
            if(sourceTableCreateSql.isEmpty()){
                log.error("source table not exist,source table {}",tableInfo);
                continue;
            }
            List<String> paramList = SQLUtil.getRepartitionCreateSqlParams(sourceTableCreateSql);
            if(paramList.isEmpty()){
                log.error("source table create sql parse error,sql {}",sourceTableCreateSql);
                continue;
            }
            String sourceTableHdfsPath = SQLUtil.locationPathExtract(sourceTableCreateSql);

            ShellCommandUtil.execShell(shellDir+ ShellNameEnum.HIVE_CREATE.getName(),databasesName,repartitionTableName,paramList.get(0),paramList.get(1));

            log.info("------------------------------------------select repartition table create  sql------------------------------------------");
            String repartitionCreateSqlFileName = AffixEnum.CREATE_REPARTITION_TABLE_SQL.getName() + repartitionTableName;
            ShellCommandUtil.execShell(shellDir+ ShellNameEnum.HIVE_SELECT_CREATE_SQL.getName(),databasesName,repartitionTableName,repartitionCreateSqlFileName);

            log.info("------------------------------------------diff columns------------------------------------------");
            String repartitionTableCreateSql = FileHandleUtil.readFile(dataDir + repartitionCreateSqlFileName);
            String diffField = SQLUtil.getDiffFields(sourceTableCreateSql,repartitionTableCreateSql);
            if(diffField.isEmpty()){
                log.info("field no change");
            }else {
                log.info("------------------------------------------alter table,changed field {}------------------------------------------",diffField);
                ShellCommandUtil.execShell(shellDir+ ShellNameEnum.HIVE_ALTER_TABLE.getName(),databasesName,repartitionTableName,diffField);
            }

            log.info("------------------------------------------move data------------------------------------------");
            List<String> dateStrList = getDateStr(date,shellDir,sourceTableHdfsPath);
            ShellCommandUtil.execShell(shellDir+ ShellNameEnum.MOVE_DATA.getName(),sourceTableHdfsPath,repartitionTableName,AffixEnum.NEW_PARTITION.getName(),dateStrList.get(0),dateStrList.get(1));

            log.info("------------------------------------------mask table------------------------------------------");
            ShellCommandUtil.execShell(shellDir+ ShellNameEnum.HIVE_MASK.getName(),databasesName,repartitionTableName);

            log.info("------------------------------------------repartition table {} end------------------------------------------",tableInfo);
        }
    }

    private List<String> getDateStr(String date,String shellDir,String sourceTableHdfsPath){
        List<String> result = new ArrayList<>(2);
        String dateStr;
        String endDate;
        if(date != null && !date.isEmpty()){
            dateStr = date;
            endDate = date;
        }else {
            DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            dateStr = df.format(LocalDate.now().minusMonths(retainedMonths - 1).withDayOfMonth(1));
            List<String> minDateContent = ShellCommandUtil.execShell(shellDir+ ShellNameEnum.GET_MIN_DATA_DATE.getName(),sourceTableHdfsPath);
            String minDate = minDateContent.isEmpty()?dateStr:minDateContent.get(0);
            endDate = df.format(LocalDate.parse(minDate,df).plusMonths(dataMoveMonths).withDayOfMonth(1));
        }
        result.add(dateStr);
        result.add(endDate);
        log.info("dead line {},end date {}",dateStr,endDate);
        return result;
    }

}
