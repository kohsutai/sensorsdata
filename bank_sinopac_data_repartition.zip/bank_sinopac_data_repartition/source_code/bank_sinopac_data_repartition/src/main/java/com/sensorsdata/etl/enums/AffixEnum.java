package com.sensorsdata.etl.enums;

public enum AffixEnum {
    /**
     * 重分区表，表明后缀
     */
    REPARTITION_TABLE_NAME_SUFFIX("_repartition"),
    /**
     * 新分区前缀
     */
    NEW_PARTITION("month"),
    /**
     * 原表建表sql前缀
   */
    CREATE_SOURCE_TABLE_SQL("create_source_table_sql_"),
    /**
     * 重分区表建表sql前缀
     */
    CREATE_REPARTITION_TABLE_SQL("create_repartition_table_sql_");

  private String name;

  AffixEnum(String name) {
    this.name = name;
  }

  public String getName() {
    return name;
  }
}
