package com.sensorsdata.etl.enums;

public enum ShellNameEnum {
    INIT("init","init.sh","初始化环境"),
    HIVE_SELECT_CREATE_SQL("hive_select_create_sql","hive_select_create_sql.sh","hive查询建表语句"),
    HIVE_CREATE("hive_create","hive_create_table.sh","hive建表"),
    HIVE_MASK("hive_mask","hive_mask_table.sh","hive刷新分区"),
    MOVE_DATA("move_data","move_data.sh","移动数据文件"),
    GET_MIN_DATA_DATE("get_min_data_date","get_min_data_date.sh","獲取數據文件的最小日期"),
    HIVE_DROP_PARTITION("hive_drop_partition","hive_drop_partition.sh","hive删除分区"),
    HIVE_ALTER_TABLE("hive_alter_table","hive_alter_table.sh","hive改变表结构（添加字段）");

    private String code;
    private String name;
    private String describe;

    ShellNameEnum(String code, String name, String describe) {
        this.code = code;
        this.name = name;
        this.describe = describe;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescribe() {
        return describe;
    }

    public void setDescribe(String cname) {
        this.describe = cname;
    }

    public static String getNameByCode(String code){
        for (ShellNameEnum eventEnum : ShellNameEnum.values()) {
            if (eventEnum.code.equals(code)){
                return eventEnum.getName();
            }
        }
        return null;
    }
}
