package com.sensorsdata.etl.utils;

import lombok.extern.slf4j.Slf4j;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

@Slf4j
public class FileHandleUtil {
    FileHandleUtil(){}

    public static String readFile(String path){
       String result = "";
        File file = new File(path);
        if(file.exists() && file.isFile()){
            try (BufferedReader input = new BufferedReader (new FileReader(file))){
                StringBuffer buffer = new StringBuffer();
                String text;
                while((text = input.readLine()) != null)
                    buffer.append(text);
                result = buffer.toString();
            }catch (Exception e){
                log.error("read file error", e);
            }
            }
        return result;
    }

}
