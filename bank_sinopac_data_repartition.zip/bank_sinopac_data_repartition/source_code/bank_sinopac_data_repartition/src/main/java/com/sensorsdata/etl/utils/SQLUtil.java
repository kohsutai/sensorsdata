package com.sensorsdata.etl.utils;

import com.sensorsdata.etl.enums.AffixEnum;
import lombok.extern.slf4j.Slf4j;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Slf4j
public class SQLUtil {
    private SQLUtil(){}

    public static String getDiffFields(String sourceTableCreateSql,String repartitionTableCreateSql){
        String result = "";
        List<String> sourceTableFieldList = paramSplit(paramExtract(sourceTableCreateSql).get(0));
        List<String> repartitionTableFieldList = paramSplit(paramExtract(repartitionTableCreateSql).get(0));
        sourceTableFieldList.removeAll(repartitionTableFieldList);
        if(!sourceTableFieldList.isEmpty()){
            result = String.join(",",sourceTableFieldList);
        }
        return result;
    }

    public static List<String> getRepartitionCreateSqlParams(String sql){
        List<String> paramList = paramExtract(sql);
        if(paramList.size() < 2){
            return Collections.emptyList();
        }
        List<String> result = new ArrayList<>(2);
        result.add(jointParamSql(paramSplit(paramList.get(0))));
        result.add(jointParamSql(paramSplit(AffixEnum.NEW_PARTITION.getName()+" STRING,"+paramList.get(1))));
        return result;
    }

    private static String jointParamSql(List<String> paramList){
        StringBuilder sql = new StringBuilder();
        Iterator<String> iterator = paramList.iterator();
        while (iterator.hasNext()){
            String param = iterator.next();
            String[] paramArray = param.trim().split(" ");
            sql.append("`");
            sql.append(paramArray[0]);
            sql.append("` ");
            sql.append(paramArray[1]);

            if(iterator.hasNext()){
                sql.append(",");
            }
        }
        return sql.toString();
    }

    private static List<String> paramExtract(String sql){

        // 定义正则表达式模式
        String regex = "\\((.*?)\\)";

        // 创建 Pattern 对象
        Pattern pattern = Pattern.compile(regex);

        // 创建 Matcher 对象
        Matcher matcher = pattern.matcher(sql);

        // 存储匹配到的结果
        List<String> matches = new ArrayList<>();

        // 查找并提取匹配的内容
        while (matcher.find()) {
            String match = matcher.group(1); // 获取捕获组1的内容
            matches.add(match);
        }
        return matches;
    }

    private static Map<String, String> getParamMap(List<String> paramList){
        Map<String, String> result = new HashMap<>(paramList.size());
        for(String param : paramList){
            String[] paramArray = param.trim().split(" ");
            result.put(paramArray[0],paramArray[1]);
        }
        return result;
    }

    private static List<String> paramSplit(String paramStr){
        if(paramStr == null || paramStr.isEmpty()){
            return Collections.emptyList();
        }
        return Arrays.stream(paramStr.split(",")).collect(Collectors.toList());
    }

    public static String locationPathExtract(String sql){

        // 定义正则表达式模式
        String regex = "'hdfs://(.*?)'";

        // 创建 Pattern 对象
        Pattern pattern = Pattern.compile(regex);

        // 创建 Matcher 对象
        Matcher matcher = pattern.matcher(sql);

        // 存储匹配到的结果
        String match = "";

        // 查找并提取匹配的内容
        while (matcher.find()) {
            match = matcher.group(1); // 获取捕获组1的内容
        }
        return match.substring(match.indexOf('/'));
    }
}
