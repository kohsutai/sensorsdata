package com.sensorsdata.etl;

import com.sensorsdata.etl.enums.VerifyEnum;
import com.sensorsdata.etl.service.ETLService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Slf4j
public class EtlApplicationRunner implements ApplicationRunner {

    @Autowired
    private ETLService etlService;

    @Override
    public void run(ApplicationArguments args) throws Exception {

        List<String> etlDateArgsList = args.getOptionValues("etlDate");
        String date = null;
        if(etlDateArgsList != null && !etlDateArgsList.isEmpty()){
            date = etlDateArgsList.stream().findFirst().orElse(null);
            if(!VerifyEnum.DATE_FORMAT_VERIFY_Y_M_D.operate(date)){
                log.error("date format illegal,allow format: yyyy-MM-dd");
                return;
            }
        }
        etlService.etlExcuse(date);
    }
}
