package com.sensorsdata.etl.exception;

public class ShellExecuteException extends RuntimeException{

    public ShellExecuteException() {
        super();
    }

    public ShellExecuteException(String message) {
        super(message);
    }
}
