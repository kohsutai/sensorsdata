package com.sensorsdata.etl.service;


/**
 *
 * @author zhangshihao
 * @version 1.0.0
 * @since 2023/02/09 10:15
 */
public interface ETLService {

    void etlExcuse(String date);

}
