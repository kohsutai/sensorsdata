#!/bin/bash

SOURCE=$0 # $0 is the shell name， maybe absolute path, relative path or symbolic link
while [ -h "$SOURCE" ]; do # resolve $SOURCE until the file is no longer a symlink
  SCRIPT_DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"
  SOURCE="$(readlink "$SOURCE")"
  [[ $SOURCE != /* ]] && SOURCE="$SCRIPT_DIR/$SOURCE" # if $SOURCE was a relative symlink, we need to resolve it relative to the path where the symlink file was located
done
SCRIPT_DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"  # script absolute path
#引入配置
source "${SCRIPT_DIR}"/../../conf/config.sh

data_dir="${SCRIPT_DIR}"/../../data

database_name=$1

table_name=$2

field_sql=$3

partitioned_sql=$4

cat  << EOF > "${data_dir}"/hive_create_table_"${table_name}"_sql
SET hive.create.as.external.legacy=true;
create table if not exists ${database_name}.${table_name} (
${field_sql}
)
partitioned by (${partitioned_sql})
STORED AS PARQUET
LOCATION "hdfs://${target_hdfs_path}/${table_name}" ;
EOF

hive -f "${data_dir}"/hive_create_table_"${table_name}"_sql
