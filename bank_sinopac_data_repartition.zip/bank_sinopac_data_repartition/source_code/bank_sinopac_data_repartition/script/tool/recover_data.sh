#!/bin/bash

SOURCE=$0 # $0 is the shell name， maybe absolute path, relative path or symbolic link
while [ -h "$SOURCE" ]; do # resolve $SOURCE until the file is no longer a symlink
  SCRIPT_DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"
  SOURCE="$(readlink "$SOURCE")"
  [[ $SOURCE != /* ]] && SOURCE="$SCRIPT_DIR/$SOURCE" # if $SOURCE was a relative symlink, we need to resolve it relative to the path where the symlink file was located
done
SCRIPT_DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"  # script absolute path
#引入配置
source "${SCRIPT_DIR}"/../../conf/config.sh

# 源目录路径
source_dir=$1

table_name=$2

# 目标目录路径
target_dir="${target_hdfs_path}"/"${table_name}"

# 获取源目录下的所有年月日命名的目录
directories=$(hadoop fs -ls $target_dir | awk '/^d/ {print $NF}')

# 遍历每个目录
for dir in $directories; do
    # 获取目录的年份和月份
    affix=$(basename $dir | cut -c 1-5)

    if [ "${affix}" = 'month' ]; then
      hadoop fs -mv "${dir}"/* "${source_dir}"
    fi

done
