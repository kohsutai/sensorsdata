#!/bin/bash
# data 文件目录 以脚本位置为定位
SOURCE=$0 # $0 is the shell name， maybe absolute path, relative path or symbolic link
while [ -h "$SOURCE" ]; do # resolve $SOURCE until the file is no longer a symlink
  SCRIPT_DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"
  SOURCE="$(readlink "$SOURCE")"
  [[ $SOURCE != /* ]] && SOURCE="$SCRIPT_DIR/$SOURCE" # if $SOURCE was a relative symlink, we need to resolve it relative to the path where the symlink file was located
done
SCRIPT_DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"  # script absolute path
CODE_ROOT_DIR="$(dirname "${SCRIPT_DIR}")"
PROGRAM_DIR="$(dirname "${CODE_ROOT_DIR}")"

BIN_PATH="${CODE_ROOT_DIR}"/bin

START_SCRIPT=run.sh

CRONTAB_CONF_FILE=${SCRIPT_DIR}/crontab_conf

function log_info() {
  DATE=`date "+%Y-%m-%d %H:%M:%s"`
  echo -e "\033[32m $DATE [INFO]: $1 \033[0m"
}


function log_err() {
  DATE=`date "+%Y-%m-%d %H:%M:%s"`
  echo -e "\033[31m $DATE [ERROR]: $1 \033[0m"
}


function deploy() {
  log_info "deploy start"
  creat_conf
  add_crontab
  sleep 2
  delete_conf
  log_info "deploy end"
}


function creat_conf() {
  crontab -l > "${CRONTAB_CONF_FILE}"
}


function add_crontab() {
  if [ -f "${CRONTAB_CONF_FILE}" ]; then
    cron='0 4 * * * '
    com='/bin/sh '"${BIN_PATH}"/"${START_SCRIPT}"' consumer'
    result=$(grep "${com}" "${CRONTAB_CONF_FILE}")
    if [ -n "$result" ];then
        log_info "crontab text exists"
    else
        log_info "start write crontab text"
        echo "${cron}${com}" >> "${CRONTAB_CONF_FILE}"
        crontab "${CRONTAB_CONF_FILE}"
        log_info "write crontab text end"
    fi
  fi
}


function  delete_conf() {
  if [ -f "${CRONTAB_CONF_FILE}" ]; then
    rm "${CRONTAB_CONF_FILE}" -f;
  fi
}


deploy
